import subprocess,pathlib,time,json,shutil,sys
root=pathlib.Path(__file__).resolve().parent
web=root/'src/web'
cli=['node','../../node_modules/@playwright/test/cli.js','test']
cases=[('shared-build',['npm','run','build','-w','@orbit/shared'],root),
 ('list-choices',cli+['--config','ui-migration/choices.config.mjs','--list'],web),
 ('choices-entry',cli+['--config','ui-migration/choices.config.mjs','--grep','Dialog owns choices|Dialog keeps composition|Dialog Popover Select exits'],web),
 ('choices-reduced-repeat',cli+['--config','ui-migration/choices.config.mjs','--grep','reduce Dialog Popover Select exits restore one layer at a time','--repeat-each','5'],web),
 ('negative-controls',cli+['--config',str(root/'docs/evidence/base-ui-migration/p2.2/revision-4/scroll-negative-control-standard.config.mjs')],web)]
results=[]
for name,argv,cwd in cases:
 start=time.time()
 with (root/('coordinator-'+name+'.log')).open('w') as log:
  p=subprocess.run(argv,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'argv':argv,'exitCode':p.returncode,'seconds':round(time.time()-start,3)}
 if name not in ['shared-build','list-choices']:
  output=web/'.choices-results'
  if output.exists():
   dest=root/('coordinator-'+name+'-results')
   shutil.copytree(output,dest)
   report=dest/'report.json'
   if report.exists(): record['stats']=json.loads(report.read_text()).get('stats')
 results.append(record)
 (root/'coordinator-browser-checks.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(record),flush=True)
 if name=='shared-build' and p.returncode: sys.exit(p.returncode)
sys.exit(0 if all(x['exitCode']==0 for x in results) else 1)
