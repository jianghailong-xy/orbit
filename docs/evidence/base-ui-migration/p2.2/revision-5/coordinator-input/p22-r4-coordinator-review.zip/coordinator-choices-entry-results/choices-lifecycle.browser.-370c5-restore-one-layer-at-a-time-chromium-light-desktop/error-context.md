# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices-lifecycle.browser.mjs >> no-preference Dialog Popover Select exits restore one layer at a time
- Location: ui-migration/choices-lifecycle.browser.mjs:51:51

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 100
Received:    105.7000000178814
```

# Page snapshot

```yaml
- main [ref=e4]:
  - status [ref=e5]: light
  - button "Switch theme" [ref=e6] [cursor=pointer]
  - button "Open Dialog" [active] [ref=e8] [cursor=pointer]
  - button "Open legacy Modal" [ref=e10] [cursor=pointer]
  - region "Standalone choices" [ref=e12]:
    - generic [ref=e13]:
      - generic [ref=e14]:
        - combobox "Expires" [ref=e15] [cursor=pointer]:
          - generic [ref=e16]: Never
        - button "Clear selection" [ref=e20] [cursor=pointer]
      - textbox [aria-hidden] [ref=e24]: never
      - generic [ref=e25]:
        - generic: Orbit workspace
        - combobox "Workspace" [ref=e26]
        - button "Show options" [ref=e27] [cursor=pointer]
        - button "Clear selection" [ref=e31] [cursor=pointer]
      - textbox [aria-hidden] [ref=e35]: orbit
      - combobox "Disabled select" [disabled] [ref=e37]:
        - generic [ref=e38]: Never
      - textbox [disabled] [aria-hidden] [ref=e42]: never
      - generic [ref=e43]:
        - generic: Never
        - combobox "Disabled search" [disabled] [ref=e44]
        - button "Show options" [disabled] [ref=e45] [cursor=pointer]
      - textbox [disabled] [aria-hidden] [ref=e49]: never
      - combobox "Empty select" [ref=e51] [cursor=pointer]:
        - generic [ref=e52]: No accounts
      - textbox [aria-hidden] [ref=e56]
      - combobox "Automatic account" [ref=e58] [cursor=pointer]:
        - generic [ref=e59]: Automatic
      - textbox [aria-hidden] [ref=e63]
      - button "Session actions" [ref=e64] [cursor=pointer]
      - button "Add attachment" [ref=e66] [cursor=pointer]
      - button "Open context" [ref=e68] [cursor=pointer]
      - button "Account usage" [ref=e70] [cursor=pointer]
      - button "Unavailable action" [disabled] [ref=e73]
      - button "After choices" [ref=e75] [cursor=pointer]
      - status "Expiry value" [ref=e77]: never
      - status "Workspace value" [ref=e78]: orbit
      - status "Action" [ref=e79]: none
      - status "Tag" [ref=e80]: "false"
    - generic [ref=e81]:
      - combobox "Add prerequisite" [ref=e82]
      - button "Show options" [ref=e83] [cursor=pointer]
    - textbox [aria-hidden] [ref=e87]
    - status "Prerequisite" [ref=e88]: none
  - region "Multiple choices" [ref=e89]:
    - generic [ref=e90]:
      - generic [ref=e91]:
        - toolbar [ref=e92]:
          - generic [ref=e93]:
            - generic [ref=e94]: Bug
            - button "Remove Bug" [ref=e95] [cursor=pointer]
          - combobox "Labels" [ref=e100]
        - button "Show options" [ref=e101] [cursor=pointer]
        - button "Clear selection" [ref=e105] [cursor=pointer]
      - textbox [aria-hidden] [ref=e109]
      - generic [ref=e110]:
        - toolbar [ref=e111]:
          - generic [ref=e112]: Bug
          - combobox "Disabled labels" [disabled] [ref=e115]
        - button "Show options" [disabled] [ref=e116] [cursor=pointer]
      - textbox [disabled] [aria-hidden] [ref=e120]
      - generic [ref=e121]:
        - toolbar [ref=e122]:
          - generic [ref=e123]:
            - generic [ref=e124]: owner@orbit.test
            - button "Remove owner@orbit.test" [ref=e125] [cursor=pointer]
          - combobox "People to add" [ref=e130]
        - button "Show options" [ref=e131] [cursor=pointer]
        - button "Clear selection" [ref=e135] [cursor=pointer]
      - textbox [aria-hidden] [ref=e139]
      - button "After tags" [ref=e140] [cursor=pointer]
      - status "Labels value" [ref=e142]: "[\"bug\"]"
      - status "People value" [ref=e143]: "[\"owner@orbit.test\"]"
      - status "People query"
    - button "Open multi Dialog" [ref=e144] [cursor=pointer]
    - group "Clickable row" [ref=e146]:
      - button "Open row" [ref=e147] [cursor=pointer]
      - button "Row actions" [ref=e149] [cursor=pointer]
    - status "Row clicks" [ref=e151]: "0"
    - status "Row actions" [ref=e152]: "0"
    - button "Long help" [ref=e153] [cursor=pointer]
    - button "Plan usage panel" [ref=e156] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import { armScrollUnlock, readScrollUnlock, scrollPage } from './choices-scroll-observation.mjs';
  3   | 
  4   | const fixture = '/ui-migration/choices.html';
  5   | const errors = new WeakMap();
  6   | test.beforeEach(async ({ page }) => {
  7   |   errors.set(page, []);
  8   |   page.on('pageerror', (error) => errors.get(page).push(error.message));
  9   | });
  10  | test.afterEach(async ({ page }) => { expect(errors.get(page)).toEqual([]); });
  11  | 
  12  | async function settle(locator) {
  13  |   await expect(locator).toBeVisible();
  14  |   await locator.evaluate(async (element) => {
  15  |     await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  16  |     await Promise.all(element.getAnimations().map((animation) => animation.finished.catch(() => {})));
  17  |   });
  18  | }
  19  | 
  20  | async function activate(locator, info) {
  21  |   if (info.project.use.hasTouch) await locator.tap();
  22  |   else await locator.click();
  23  | }
  24  | 
  25  | async function watchExit(locator) {
  26  |   await locator.evaluate((node) => {
  27  |     const record = { frames: [], active: true };
  28  |     window.choiceExit = record;
  29  |     const frame = () => {
  30  |       if (node.hasAttribute('data-closed')) {
  31  |         const style = getComputedStyle(node);
  32  |         record.frames.push({ connected: node.isConnected, opacity: Number(style.opacity), pointerEvents: style.pointerEvents,
  33  |           visible: !!node.getClientRects().length && style.visibility !== 'hidden' });
  34  |       }
  35  |       if (record.active) requestAnimationFrame(frame);
  36  |     };
  37  |     requestAnimationFrame(frame);
  38  |   });
  39  | }
  40  | 
  41  | async function closed(page, locator, motion) {
  42  |   await expect(locator).not.toBeVisible();
  43  |   const frames = await page.evaluate(() => { window.choiceExit.active = false; return window.choiceExit.frames; });
  44  |   if (motion === 'no-preference') {
  45  |     expect(frames.some((frame) => frame.connected && frame.visible && frame.opacity > 0 && frame.opacity < 1)).toBe(true);
  46  |     expect(frames.filter((frame) => frame.visible).every((frame) => frame.pointerEvents === 'none')).toBe(true);
  47  |   }
  48  |   return frames;
  49  | }
  50  | 
  51  | for (const motion of ['no-preference', 'reduce']) test(`${motion} Dialog Popover Select exits restore one layer at a time`, async ({ page }, info) => {
  52  |   await page.emulateMedia({ reducedMotion: motion });
  53  |   await page.goto(fixture);
  54  |   const trigger = page.getByRole('button', { name: 'Open Dialog', exact: true });
  55  |   await activate(trigger, info);
  56  |   const dialog = page.getByRole('dialog', { name: 'Share workspace', exact: true });
  57  |   await settle(dialog);
  58  |   const context = dialog.getByRole('button', { name: 'Open context', exact: true });
  59  |   await activate(context, info);
  60  |   const popover = page.getByRole('dialog', { name: 'Context', exact: true });
  61  |   await settle(popover);
  62  |   const select = popover.getByRole('combobox', { name: 'Context expiry', exact: true });
  63  |   await activate(select, info);
  64  |   const popup = page.locator('.orbit-select-popup:visible');
  65  |   await settle(popup);
  66  |   const geometry = await popup.evaluate((node) => {
  67  |     const box = node.getBoundingClientRect();
  68  |     const points = [[box.x + 8, box.y + 8], [box.right - 8, box.bottom - 8]];
  69  |     return { box: box.toJSON(), inPopover: !!node.closest('.orbit-popover'), inDialog: !!node.closest('.orbit-dialog'),
  70  |       cornersHitPopup: points.every(([x, y]) => node.contains(document.elementFromPoint(x, y))),
  71  |       animationName: getComputedStyle(node).animationName };
  72  |   });
  73  |   expect(geometry.inPopover).toBe(true);
  74  |   expect(geometry.inDialog).toBe(true);
  75  |   expect(geometry.cornersHitPopup).toBe(true);
  76  |   if (motion === 'reduce') expect(geometry.animationName).toBe('none');
  77  |   await info.attach('nested-open', { body: await page.screenshot(), contentType: 'image/png' });
  78  |   // Select may retain its hidden positioner after exit; assert visibility as well as focus.
  79  |   const selectPopup = page.locator('.orbit-select-popup');
  80  |   await watchExit(selectPopup);
  81  |   await page.keyboard.press('Escape');
  82  |   const selectExit = await closed(page, selectPopup, motion);
  83  |   await expect(select).toBeFocused();
  84  |   await expect(popover).toBeVisible();
  85  |   await expect(dialog).toBeVisible();
  86  |   await watchExit(popover);
  87  |   await page.keyboard.press('Escape');
  88  |   const popoverExit = await closed(page, popover, motion);
  89  |   await expect(context).toBeFocused();
  90  |   await expect(dialog).toBeVisible();
  91  |   expect(await page.evaluate(() => [document.body, document.documentElement].some((node) => /hidden|clip/.test(getComputedStyle(node).overflowY)))).toBe(true);
  92  |   await armScrollUnlock(page);
  93  |   await page.keyboard.press('Escape');
  94  |   await expect(dialog).not.toBeVisible();
  95  |   await expect(trigger).toBeFocused();
  96  |   const unlock = await readScrollUnlock(page);
  97  |   await info.attach('scroll-unlock', { body: JSON.stringify(unlock, null, 2), contentType: 'application/json' });
  98  |   expect(unlock.unlockedAfterMs).not.toBeNull();
> 99  |   expect(unlock.unlockedAfterMs).toBeLessThanOrEqual(unlock.limitMs);
      |                                  ^ Error: expect(received).toBeLessThanOrEqual(expected)
  100 |   expect(unlock.finalRead.locked).toBe(false);
  101 |   const scroll = await scrollPage(page, info);
  102 |   await info.attach('page-scroll', { body: JSON.stringify(scroll, null, 2), contentType: 'application/json' });
  103 |   expect(scroll.scrollHeight).toBeGreaterThan(scroll.viewportHeight);
  104 |   expect(scroll.input?.trusted).toBe(true);
  105 |   expect(scroll.input?.kind).toBe(info.project.use.isMobile ? 'PageDown' : 'wheel');
  106 |   expect(scroll.movedAfterMs).not.toBeNull();
  107 |   expect(scroll.movedAfterMs).toBeLessThanOrEqual(scroll.limitMs);
  108 |   expect(scroll.after).toBeGreaterThan(scroll.before);
  109 |   await expect(trigger).toBeFocused();
  110 |   await info.attach('nested-lifecycle', { body: JSON.stringify({ motion, geometry, selectExit, popoverExit, focusReturned: true, scrollUnlocked: true }, null, 2), contentType: 'application/json' });
  111 | });
  112 | 
  113 | for (const kind of ['attachment', 'expiry', 'search', 'multiple', 'popover', 'tooltip']) test(`reduced motion ${kind} has no transition and dismisses cleanly`, async ({ page }, info) => {
  114 |   await page.emulateMedia({ reducedMotion: 'reduce' });
  115 |   await page.goto(`${fixture}?sample=${kind}&system=orbit`);
  116 |   const trigger = page.getByRole('region', { name: 'Appearance sample' }).getByRole(['expiry', 'search', 'multiple'].includes(kind) ? 'combobox' : 'button');
  117 |   if (kind === 'tooltip') await trigger.focus();
  118 |   else await activate(trigger, info);
  119 |   const popup = page.locator('.sample-surface');
  120 |   await settle(popup);
  121 |   const styles = await popup.evaluate((node) => ({ animation: getComputedStyle(node).animationName,
  122 |     transitionDuration: getComputedStyle(node).transitionDuration, running: node.getAnimations().length }));
  123 |   expect(styles).toEqual({ animation: 'none', transitionDuration: '0s', running: 0 });
  124 |   await page.keyboard.press('Escape');
  125 |   await expect(popup).not.toBeVisible();
  126 |   await expect(trigger).toBeFocused();
  127 |   await info.attach('reduced-motion', { body: JSON.stringify({ kind, styles, dismissed: true, focusReturned: true }), contentType: 'application/json' });
  128 | });
  129 | 
  130 | for (const kind of ['attachment', 'expiry', 'search', 'popover']) test(`normal ${kind} can reopen during exit without stale unmount`, async ({ page }, info) => {
  131 |   await page.emulateMedia({ reducedMotion: 'no-preference' });
  132 |   await page.goto(`${fixture}?sample=${kind}&system=orbit`);
  133 |   const trigger = page.getByRole('region', { name: 'Appearance sample' }).getByRole(['expiry', 'search'].includes(kind) ? 'combobox' : 'button');
  134 |   await activate(trigger, info);
  135 |   const popup = page.locator('.sample-surface');
  136 |   await settle(popup);
  137 |   await page.keyboard.press('Escape');
  138 |   await expect(popup).toHaveAttribute('data-closed', '');
  139 |   await activate(trigger, info);
  140 |   await expect(popup).toHaveAttribute('data-open', '');
  141 |   await settle(popup);
  142 |   await expect(popup).toBeVisible();
  143 |   if (kind === 'attachment') await activate(page.getByRole('menuitem', { name: 'File', exact: true }), info);
  144 |   else if (['expiry', 'search'].includes(kind)) {
  145 |     await activate(page.getByRole('option', { name: '7 days', exact: true }), info);
  146 |     if (kind === 'expiry') await expect(trigger).toHaveText('7 days');
  147 |     else {
  148 |       await expect(trigger).toHaveAccessibleDescription('7 days');
  149 |       await expect(page.locator('.orbit-combobox-value')).toHaveText('7 days');
  150 |       await expect(trigger).toHaveValue('');
  151 |     }
  152 |   } else if (info.project.use.hasTouch) await page.touchscreen.tap(3, 60);
  153 |   else await page.mouse.click(3, 60);
  154 |   await expect(popup).not.toBeVisible();
  155 |   await info.attach('reopen', { body: JSON.stringify({ kind, input: info.project.use.hasTouch ? 'touch' : 'mouse', reopenedDuringExit: true, subsequentActionClosed: true }), contentType: 'application/json' });
  156 | });
  157 | 
```