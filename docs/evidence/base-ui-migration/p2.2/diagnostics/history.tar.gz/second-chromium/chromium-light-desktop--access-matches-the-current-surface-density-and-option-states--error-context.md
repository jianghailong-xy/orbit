# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> access matches the current surface, density and option states
- Location: ui-migration/choices.browser.mjs:45:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

@@ -1,10 +1,10 @@
  Object {
    "popup": Object {
      "rows": Array [
        Object {
-         "backgroundColor": "rgb(240, 247, 255)",
+         "backgroundColor": "rgb(214, 232, 255)",
          "borderColor": "rgb(51, 112, 255)",
          "borderRadius": "4px",
          "borderStyle": "none",
          "borderWidth": "0px",
          "boxShadow": "none",
```

# Page snapshot

```yaml
- main [ref=f2e4]:
  - status [ref=f2e5]: light
  - button "Switch theme" [ref=f2e6] [cursor=pointer]
  - region "Appearance sample" [ref=f2e8]:
    - generic [ref=f2e9]:
      - button "Access" [expanded] [ref=f2e11] [cursor=pointer]
      - menu "Access" [active] [ref=f2e16]:
        - menuitem "Only you Turns the link off." [ref=f2e17] [cursor=pointer]:
          - generic [ref=f2e23]:
            - text: Only you
            - generic [ref=f2e24]: Turns the link off.
        - menuitem "Anyone with the link No sign-in needed to view." [ref=f2e25] [cursor=pointer]:
          - generic [ref=f2e31]:
            - text: Anyone with the link
            - generic [ref=f2e32]: No sign-in needed to view.
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | const fixture = '/ui-migration/choices.html';
  4   | const errors = new WeakMap();
  5   | test.beforeEach(async ({ page }, info) => {
  6   |   errors.set(page, []);
  7   |   page.on('pageerror', (error) => errors.get(page).push(error.message));
  8   |   await page.goto(fixture);
  9   |   await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  10  |   await page.evaluate(() => document.fonts.ready);
  11  | });
  12  | test.afterEach(async ({ page }) => { expect(errors.get(page)).toEqual([]); });
  13  | const attach = (info, name, value) => info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  14  | const shot = (info, name, locator) => locator.screenshot({ animations: 'disabled' }).then((body) => info.attach(name, { body, contentType: 'image/png' }));
  15  | async function settle(locator) {
  16  |   await expect(locator).toBeVisible();
  17  |   await locator.evaluate(async (el) => {
  18  |     const animations = new Set(el.getAnimations({ subtree: true }));
  19  |     for (let node = el.parentElement; node; node = node.parentElement) for (const animation of node.getAnimations()) animations.add(animation);
  20  |     await Promise.all([...animations].filter((a) => a.effect?.getComputedTiming().iterations !== Infinity).map((a) => a.finished.catch(() => {})));
  21  |     await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  22  |   });
  23  | }
  24  | async function tap(page, info, locator) {
  25  |   if (info.project.use.hasTouch) await locator.tap();
  26  |   else await locator.click();
  27  | }
  28  | async function outside(page, info) {
  29  |   if (info.project.use.hasTouch) await page.touchscreen.tap(3, 60);
  30  |   else await page.mouse.click(3, 60);
  31  | }
  32  | async function measure(locator) {
  33  |   return locator.evaluate((el) => {
  34  |     const root = el.getBoundingClientRect();
  35  |     const metrics = (node) => {
  36  |       const r = node.getBoundingClientRect(), s = getComputedStyle(node);
  37  |       const keys = ['fontFamily', 'fontSize', 'lineHeight', 'fontWeight', 'color', 'backgroundColor', 'borderRadius', 'borderColor', 'borderWidth', 'borderStyle', 'padding', 'boxShadow'];
  38  |       return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, ...Object.fromEntries(keys.map((key) => [key, s[key]])) };
  39  |     };
  40  |     return { surface: metrics(el), rows: [...el.querySelectorAll('[role="menuitem"], [role="option"]')].map((row) => ({ label: row.textContent, ...metrics(row) })) };
  41  |   });
  42  | }
  43  | 
  44  | for (const kind of ['attachment', 'access', 'expiry', 'account', 'search', 'popover', 'tooltip']) {
  45  |   test(`${kind} matches the current surface, density and option states`, async ({ page }, info) => {
  46  |     const measurements = {};
  47  |     for (const system of ['antd', 'orbit']) {
  48  |       await page.goto(`${fixture}?sample=${kind}&system=${system}`);
  49  |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  50  |       const region = page.getByRole('region', { name: 'Appearance sample' });
  51  |       const choice = region.getByRole('combobox');
  52  |       if (['expiry', 'account', 'search'].includes(kind)) {
  53  |         await page.mouse.move(0, 0);
  54  |         await page.getByTestId('neutral').focus();
  55  |         measurements[system] = { control: await measure(page.locator('.sample-choice')) };
  56  |         await shot(info, `${system}-${kind}-closed`, page.locator('.sample-choice'));
  57  |         await choice.click();
  58  |       } else if (kind === 'tooltip') await region.getByRole('button').hover();
  59  |       else await region.getByRole('button').click();
  60  |       const surface = page.locator('.sample-surface:visible');
  61  |       await settle(surface);
  62  |       if (kind !== 'tooltip') await page.mouse.move(0, 0);
  63  |       await settle(surface);
  64  |       measurements[system] = { ...measurements[system], popup: await measure(surface) };
  65  |       await shot(info, `${system}-${kind}-open`, surface);
  66  |     }
  67  |     await attach(info, 'appearance', measurements);
> 68  |     expect(measurements.orbit).toEqual(measurements.antd);
      |                                ^ Error: expect(received).toEqual(expected) // deep equality
  69  |   });
  70  | }
  71  | 
  72  | test('menu arrows, disabled items, submenu, checkbox and focus return work', async ({ page }, info) => {
  73  |   const trigger = page.getByRole('button', { name: 'Session actions', exact: true });
  74  |   await trigger.focus();
  75  |   await page.keyboard.press('ArrowDown');
  76  |   const first = page.getByRole('menuitem', { name: 'Default model', exact: true });
  77  |   await expect(first).toBeFocused();
  78  |   await page.keyboard.press('ArrowDown');
  79  |   const provider = page.getByRole('menuitem', { name: 'Provider', exact: true });
  80  |   await expect(provider).toBeFocused();
  81  |   await page.keyboard.press('ArrowRight');
  82  |   await expect(page.getByRole('menuitem', { name: 'Codex', exact: true })).toBeFocused();
  83  |   await page.keyboard.press('Escape');
  84  |   await expect(provider).toBeFocused();
  85  |   await expect(page.getByRole('menu')).toHaveCount(1);
  86  |   await page.keyboard.press('ArrowRight');
  87  |   await page.keyboard.press('ArrowDown');
  88  |   await page.keyboard.press('Enter');
  89  |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('claude');
  90  |   await expect(trigger).toBeFocused();
  91  |   await trigger.click();
  92  |   const tag = page.getByRole('menuitemcheckbox', { name: 'Important tag' });
  93  |   await tag.click();
  94  |   await expect(tag).toHaveAttribute('aria-checked', 'true');
  95  |   await expect(page.getByRole('status', { name: 'Tag', exact: true })).toHaveText('true');
  96  |   await tag.press('Space');
  97  |   await expect(tag).toHaveAttribute('aria-checked', 'false');
  98  |   await page.keyboard.press('Escape');
  99  |   await expect(trigger).toBeFocused();
  100 |   await attach(info, 'keyboard-menu', { disabledSkipped: true, submenuOnlyEscape: true, selection: 'claude', checkboxStaysOpen: true, focusReturned: true });
  101 | });
  102 | 
  103 | test('touch or pointer menus dismiss outside, fit viewport and open a dialog with stable return focus', async ({ page }, info) => {
  104 |   const trigger = page.getByRole('button', { name: 'Add attachment', exact: true });
  105 |   await tap(page, info, trigger);
  106 |   const menu = page.getByRole('menu');
  107 |   const box = await menu.boundingBox();
  108 |   expect(box.x).toBeGreaterThanOrEqual(0);
  109 |   expect(box.x + box.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  110 |   await tap(page, info, page.getByRole('menuitem', { name: 'Image', exact: true }));
  111 |   await expect(menu).not.toBeVisible();
  112 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('image');
  113 |   await tap(page, info, trigger);
  114 |   await outside(page, info);
  115 |   await expect(menu).not.toBeVisible();
  116 |   const actions = page.getByRole('button', { name: 'Session actions', exact: true });
  117 |   await tap(page, info, actions);
  118 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  119 |   const sub = page.getByRole('menu').filter({ has: page.getByRole('menuitem', { name: 'Codex', exact: true }) });
  120 |   await expect(sub).toBeVisible();
  121 |   const subBox = await sub.boundingBox();
  122 |   expect(subBox.x).toBeGreaterThanOrEqual(0);
  123 |   expect(subBox.x + subBox.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  124 |   await page.keyboard.press('Escape');
  125 |   await tap(page, info, page.getByRole('menuitem', { name: 'Edit details', exact: true }));
  126 |   const dialog = page.getByRole('dialog', { name: 'Edit details', exact: true });
  127 |   await expect(dialog).toBeVisible();
  128 |   await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  129 |   await page.keyboard.press('Escape');
  130 |   await expect(actions).toBeFocused();
  131 |   await attach(info, 'pointer-menu', { input: info.project.use.hasTouch ? 'touch' : 'mouse', outside: true, menuBounds: box, submenuBounds: subBox, dialogReturn: true });
  132 | });
  133 | 
  134 | test('select supports arrows, Enter, clear, empty, disabled and empty-string account values', async ({ page }, info) => {
  135 |   const select = page.getByRole('combobox', { name: 'Expires', exact: true });
  136 |   await select.focus();
  137 |   await page.keyboard.press('ArrowDown');
  138 |   await page.keyboard.press('ArrowDown');
  139 |   await page.keyboard.press('Enter');
  140 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('7');
  141 |   await expect(select).toBeFocused();
  142 |   await select.click();
  143 |   await expect(page.getByRole('option', { name: '7 days', exact: true })).toHaveAttribute('aria-selected', 'true');
  144 |   await expect(page.getByRole('option', { name: '30 days', exact: true })).toHaveAttribute('aria-disabled', 'true');
  145 |   await page.keyboard.press('Escape');
  146 |   await page.getByRole('button', { name: 'Clear selection' }).first().click();
  147 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('null');
  148 |   await expect(select).toBeFocused();
  149 |   await expect(page.getByRole('combobox', { name: 'Disabled select', exact: true })).toBeDisabled();
  150 |   await expect(page.getByRole('combobox', { name: 'Disabled search', exact: true })).toBeDisabled();
  151 |   await page.getByRole('combobox', { name: 'Empty select', exact: true }).click();
  152 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  153 |   await page.keyboard.press('Escape');
  154 |   const automatic = page.getByRole('combobox', { name: 'Automatic account', exact: true });
  155 |   await expect(automatic).toContainText('Automatic');
  156 |   await automatic.click();
  157 |   await expect(page.getByRole('option', { name: /Automatic/ })).toHaveAttribute('aria-selected', 'true');
  158 |   await outside(page, info);
  159 |   await expect(automatic).toHaveAttribute('aria-expanded', 'false');
  160 |   await attach(info, 'select', { selected: '7', cleared: true, disabled: true, empty: true, emptyStringIsSelection: true });
  161 | });
  162 | 
  163 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  164 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  165 |   await input.click();
  166 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  167 |   await input.fill('docs');
  168 |   await expect(page.getByRole('option')).toHaveCount(1);
```