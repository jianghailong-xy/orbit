# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover
- Location: ui-migration/choices.browser.mjs:247:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('tooltip')
Expected: "Usage from this account"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" getByRole('tooltip') with timeout 15000ms
  - waiting for getByRole('tooltip')

```

```yaml
- main:
  - status: dark
  - button "Switch theme"
  - button "Open Dialog"
  - button "Open legacy Modal"
  - region "Standalone choices":
    - combobox "Expires": Never
    - button "Clear selection"
    - combobox "Workspace"
    - button "Show options"
    - button "Clear selection"
    - combobox "Disabled select" [disabled]: Never
    - combobox "Disabled search" [disabled]
    - button "Show options" [disabled]
    - combobox "Empty select": No accounts
    - combobox "Automatic account": Automatic
    - button "Session actions"
    - button "Add attachment"
    - button "Open context"
    - button "Account usage"
    - button "Unavailable action" [disabled]
    - button "After choices"
    - status "Expiry value": never
    - status "Workspace value": orbit
    - status "Action": none
    - status "Tag": "false"
    - combobox "Add prerequisite"
    - button "Show options"
    - status "Prerequisite": none
- text: Usage from this account
```

# Test source

```ts
  164 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  165 |   await input.click();
  166 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  167 |   await input.fill('docs');
  168 |   await expect(page.getByRole('option')).toHaveCount(1);
  169 |   await page.keyboard.press('Enter');
  170 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  171 |   await expect(input).toBeFocused();
  172 |   await input.fill('missing');
  173 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  174 |   await page.keyboard.press('Escape');
  175 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  176 |   await input.click();
  177 |   await input.dispatchEvent('compositionstart');
  178 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  179 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  180 |   await expect(input).toHaveAttribute('aria-expanded', 'true');
  181 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  182 |   await input.dispatchEvent('compositionend', { data: '文档' });
  183 |   await input.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  184 |   await input.fill('文档');
  185 |   await expect(page.getByRole('option')).toHaveCount(1);
  186 |   await page.keyboard.press('Enter');
  187 |   await page.getByRole('button', { name: 'Clear selection' }).nth(1).click();
  188 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  189 |   await expect(input).toBeFocused();
  190 |   await attach(info, 'search', { grouping: true, chinese: true, syntheticCompositionIgnored: true, escapePreservesValue: true, explicitClear: true });
  191 | });
  192 | 
  193 | test('remote search accepts server labels and resets an action picker without local filtering', async ({ page }, info) => {
  194 |   let release;
  195 |   const gate = new Promise((resolve) => { release = resolve; });
  196 |   await page.route('**/__choices-search?*', async (route) => {
  197 |     await gate;
  198 |     await route.fulfill({ json: [{ value: 'task-1', label: 'Server ranked result' }] });
  199 |   });
  200 |   const input = page.getByRole('combobox', { name: 'Add prerequisite', exact: true });
  201 |   await input.fill('query');
  202 |   await expect(input).toHaveAttribute('aria-busy', 'true');
  203 |   release();
  204 |   const option = page.getByRole('option', { name: 'Server ranked result', exact: true });
  205 |   await expect(option).toBeVisible();
  206 |   await option.click();
  207 |   await expect(page.getByRole('status', { name: 'Prerequisite', exact: true })).toHaveText('task-1');
  208 |   await expect(input).toHaveValue('');
  209 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  210 |   await attach(info, 'remote-search', { loadingExposed: true, filterDisabled: true, valueNullResetsQuery: true });
  211 | });
  212 | 
  213 | for (const legacy of [false, true]) test(`${legacy ? 'legacy Modal' : 'Dialog'} owns choices, top-layer Escape, Tab and theme`, async ({ page }, info) => {
  214 |   const trigger = page.getByRole('button', { name: legacy ? 'Open legacy Modal' : 'Open Dialog', exact: true });
  215 |   await tap(page, info, trigger);
  216 |   const dialog = page.getByRole('dialog', { name: legacy ? 'Legacy share' : 'Share workspace', exact: true });
  217 |   await settle(dialog);
  218 |   const input = dialog.getByRole('combobox', { name: 'Workspace', exact: true });
  219 |   await tap(page, info, input);
  220 |   const list = page.getByRole('listbox');
  221 |   await expect(list).toBeVisible();
  222 |   expect(await list.evaluate((el) => !!el.closest('[role="dialog"]'))).toBe(true);
  223 |   await page.keyboard.press('Escape');
  224 |   await expect(list).not.toBeVisible();
  225 |   await expect(dialog).toBeVisible();
  226 |   await expect(input).toBeFocused();
  227 |   await tap(page, info, dialog.getByRole('combobox', { name: 'Expires', exact: true }));
  228 |   await page.keyboard.press('Escape');
  229 |   await expect(dialog).toBeVisible();
  230 |   const actions = dialog.getByRole('button', { name: 'Session actions', exact: true });
  231 |   await tap(page, info, actions);
  232 |   await page.keyboard.press('Escape');
  233 |   await expect(dialog).toBeVisible();
  234 |   await expect(actions).toBeFocused();
  235 |   for (const key of ['Tab', 'Shift+Tab']) for (let i = 0; i < 12; i++) {
  236 |     await page.keyboard.press(key);
  237 |     await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  238 |   }
  239 |   expect(await page.evaluate(() => [document.body, document.documentElement].some((el) => /hidden|clip/.test(getComputedStyle(el).overflowY)))).toBe(true);
  240 |   await shot(info, 'choices-in-dialog', dialog);
  241 |   await page.keyboard.press('Escape');
  242 |   await expect(dialog).not.toBeVisible();
  243 |   await expect(trigger).toBeFocused();
  244 |   await attach(info, 'nested-choices', { legacy, topLayerOnly: true, portalInsideOwner: true, tabBothDirections: true, scrollLocked: true, returned: true });
  245 | });
  246 | 
  247 | test('popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover', async ({ page }, info) => {
  248 |   const trigger = page.getByRole('button', { name: 'Open context', exact: true });
  249 |   await tap(page, info, trigger);
  250 |   const popover = page.getByRole('dialog', { name: 'Context', exact: true });
  251 |   await expect(popover).toBeVisible();
  252 |   const select = popover.getByRole('combobox', { name: 'Context expiry', exact: true });
  253 |   await select.click();
  254 |   await page.keyboard.press('Escape');
  255 |   await expect(popover).toBeVisible();
  256 |   await expect(select).toBeFocused();
  257 |   await page.keyboard.press('Escape');
  258 |   await expect(popover).not.toBeVisible();
  259 |   await expect(trigger).toBeFocused();
  260 |   const usage = page.getByRole('button', { name: 'Account usage', exact: true });
  261 |   await page.keyboard.press('Tab');
  262 |   await usage.focus();
  263 |   const tooltip = page.getByRole('tooltip');
> 264 |   await expect(tooltip).toHaveText('Usage from this account');
      |                         ^ Error: expect(locator).toHaveText(expected) failed
  265 |   await expect(usage).toHaveAttribute('aria-describedby', /.+/);
  266 |   await page.keyboard.press('Escape');
  267 |   await expect(tooltip).not.toBeVisible();
  268 |   await usage.blur();
  269 |   await usage.hover();
  270 |   await expect(tooltip).toBeVisible();
  271 |   await page.mouse.move(0, 0);
  272 |   await expect(tooltip).not.toBeVisible();
  273 |   await tap(page, info, trigger);
  274 |   await outside(page, info);
  275 |   await expect(popover).not.toBeVisible();
  276 |   await attach(info, 'popover-tooltip', { nestedSelect: true, sequentialEscape: true, focusReturn: true, tooltipFocusHoverEscape: true });
  277 | });
  278 | 
```