# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> legacy Modal owns choices, top-layer Escape, Tab and theme
- Location: ui-migration/choices.browser.mjs:213:37

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- main [ref=e4]:
  - status [ref=e5]: dark
  - button "Switch theme" [ref=e6] [cursor=pointer]
  - button "Open Dialog" [ref=e8] [cursor=pointer]
  - button "Open legacy Modal" [active] [ref=e10] [cursor=pointer]
  - region "Standalone choices" [ref=e12]:
    - generic [ref=e13]:
      - generic [ref=e14]:
        - combobox "Expires" [ref=e15] [cursor=pointer]:
          - generic [ref=e16]: Never
        - button "Clear selection" [ref=e20] [cursor=pointer]
      - textbox [aria-hidden] [ref=e24]: never
      - generic [ref=e25]:
        - generic [aria-hidden]: Orbit workspace
        - combobox "Workspace" [ref=e26]
        - button "Show options" [ref=e27] [cursor=pointer]
        - button "Clear selection" [ref=e31] [cursor=pointer]
      - textbox [aria-hidden] [ref=e35]: orbit
      - combobox "Disabled select" [disabled] [ref=e37]:
        - generic [ref=e38]: Never
      - textbox [disabled] [aria-hidden] [ref=e42]: never
      - generic [ref=e43]:
        - generic [aria-hidden]: Never
        - combobox "Disabled search" [disabled] [ref=e44]
        - button "Show options" [disabled] [ref=e45] [cursor=pointer]
      - textbox [disabled] [aria-hidden] [ref=e49]: never
      - combobox "Empty select" [ref=e51] [cursor=pointer]:
        - generic [ref=e52]: No accounts
      - textbox [aria-hidden] [ref=e56]
      - combobox "Automatic account" [ref=e58] [cursor=pointer]:
        - generic [ref=e59]: Automatic
      - textbox [aria-hidden] [ref=e63]
      - button "Session actions" [ref=e64] [cursor=pointer]
      - button "Add attachment" [ref=e66] [cursor=pointer]
      - button "Open context" [ref=e68] [cursor=pointer]
      - button "Account usage" [ref=e70] [cursor=pointer]
      - button "Unavailable action" [disabled] [ref=e73]
      - button "After choices" [ref=e75] [cursor=pointer]
      - status "Expiry value" [ref=e77]: never
      - status "Workspace value" [ref=e78]: orbit
      - status "Action" [ref=e79]: none
      - status "Tag" [ref=e80]: "false"
    - generic [ref=e81]:
      - combobox "Add prerequisite" [ref=e82]
      - button "Show options" [ref=e83] [cursor=pointer]
    - textbox [aria-hidden] [ref=e87]
    - status "Prerequisite" [ref=e88]: none
```

# Test source

```ts
  137 |   await page.keyboard.press('ArrowDown');
  138 |   await page.keyboard.press('ArrowDown');
  139 |   await page.keyboard.press('Enter');
  140 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('7');
  141 |   await expect(select).toBeFocused();
  142 |   await select.click();
  143 |   await expect(page.getByRole('option', { name: '7 days', exact: true })).toHaveAttribute('aria-selected', 'true');
  144 |   await expect(page.getByRole('option', { name: '30 days', exact: true })).toHaveAttribute('aria-disabled', 'true');
  145 |   await page.keyboard.press('Escape');
  146 |   await page.getByRole('button', { name: 'Clear selection' }).first().click();
  147 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('null');
  148 |   await expect(select).toBeFocused();
  149 |   await expect(page.getByRole('combobox', { name: 'Disabled select', exact: true })).toBeDisabled();
  150 |   await expect(page.getByRole('combobox', { name: 'Disabled search', exact: true })).toBeDisabled();
  151 |   await page.getByRole('combobox', { name: 'Empty select', exact: true }).click();
  152 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  153 |   await page.keyboard.press('Escape');
  154 |   const automatic = page.getByRole('combobox', { name: 'Automatic account', exact: true });
  155 |   await expect(automatic).toContainText('Automatic');
  156 |   await automatic.click();
  157 |   await expect(page.getByRole('option', { name: /Automatic/ })).toHaveAttribute('aria-selected', 'true');
  158 |   await outside(page, info);
  159 |   await expect(automatic).toHaveAttribute('aria-expanded', 'false');
  160 |   await attach(info, 'select', { selected: '7', cleared: true, disabled: true, empty: true, emptyStringIsSelection: true });
  161 | });
  162 | 
  163 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  164 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  165 |   await input.click();
  166 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  167 |   await input.fill('docs');
  168 |   await expect(page.getByRole('option')).toHaveCount(1);
  169 |   await page.keyboard.press('Enter');
  170 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  171 |   await expect(input).toBeFocused();
  172 |   await input.fill('missing');
  173 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  174 |   await page.keyboard.press('Escape');
  175 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  176 |   await input.click();
  177 |   await input.dispatchEvent('compositionstart');
  178 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  179 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  180 |   await expect(input).toHaveAttribute('aria-expanded', 'true');
  181 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  182 |   await input.dispatchEvent('compositionend', { data: '文档' });
  183 |   await input.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  184 |   await input.fill('文档');
  185 |   await expect(page.getByRole('option')).toHaveCount(1);
  186 |   await page.keyboard.press('Enter');
  187 |   await page.getByRole('button', { name: 'Clear selection' }).nth(1).click();
  188 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  189 |   await expect(input).toBeFocused();
  190 |   await attach(info, 'search', { grouping: true, chinese: true, syntheticCompositionIgnored: true, escapePreservesValue: true, explicitClear: true });
  191 | });
  192 | 
  193 | test('remote search accepts server labels and resets an action picker without local filtering', async ({ page }, info) => {
  194 |   let release;
  195 |   const gate = new Promise((resolve) => { release = resolve; });
  196 |   await page.route('**/__choices-search?*', async (route) => {
  197 |     await gate;
  198 |     await route.fulfill({ json: [{ value: 'task-1', label: 'Server ranked result' }] });
  199 |   });
  200 |   const input = page.getByRole('combobox', { name: 'Add prerequisite', exact: true });
  201 |   await input.fill('query');
  202 |   await expect(input).toHaveAttribute('aria-busy', 'true');
  203 |   release();
  204 |   const option = page.getByRole('option', { name: 'Server ranked result', exact: true });
  205 |   await expect(option).toBeVisible();
  206 |   await option.click();
  207 |   await expect(page.getByRole('status', { name: 'Prerequisite', exact: true })).toHaveText('task-1');
  208 |   await expect(input).toHaveValue('');
  209 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  210 |   await attach(info, 'remote-search', { loadingExposed: true, filterDisabled: true, valueNullResetsQuery: true });
  211 | });
  212 | 
  213 | for (const legacy of [false, true]) test(`${legacy ? 'legacy Modal' : 'Dialog'} owns choices, top-layer Escape, Tab and theme`, async ({ page }, info) => {
  214 |   const trigger = page.getByRole('button', { name: legacy ? 'Open legacy Modal' : 'Open Dialog', exact: true });
  215 |   await tap(page, info, trigger);
  216 |   const dialog = page.getByRole('dialog', { name: legacy ? 'Legacy share' : 'Share workspace', exact: true });
  217 |   await settle(dialog);
  218 |   const input = dialog.getByRole('combobox', { name: 'Workspace', exact: true });
  219 |   await tap(page, info, input);
  220 |   const list = page.getByRole('listbox');
  221 |   await expect(list).toBeVisible();
  222 |   expect(await list.evaluate((el) => !!el.closest('[role="dialog"]'))).toBe(true);
  223 |   await page.keyboard.press('Escape');
  224 |   await expect(list).not.toBeVisible();
  225 |   await expect(dialog).toBeVisible();
  226 |   await expect(input).toBeFocused();
  227 |   await tap(page, info, dialog.getByRole('combobox', { name: 'Expires', exact: true }));
  228 |   await page.keyboard.press('Escape');
  229 |   await expect(dialog).toBeVisible();
  230 |   const actions = dialog.getByRole('button', { name: 'Session actions', exact: true });
  231 |   await tap(page, info, actions);
  232 |   await page.keyboard.press('Escape');
  233 |   await expect(dialog).toBeVisible();
  234 |   await expect(actions).toBeFocused();
  235 |   for (const key of ['Tab', 'Shift+Tab']) for (let i = 0; i < 12; i++) {
  236 |     await page.keyboard.press(key);
> 237 |     await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
      |                                                                                           ^ Error: expect(received).toBe(expected) // Object.is equality
  238 |   }
  239 |   expect(await page.evaluate(() => [document.body, document.documentElement].some((el) => /hidden|clip/.test(getComputedStyle(el).overflowY)))).toBe(true);
  240 |   await shot(info, 'choices-in-dialog', dialog);
  241 |   await page.keyboard.press('Escape');
  242 |   await expect(dialog).not.toBeVisible();
  243 |   await expect(trigger).toBeFocused();
  244 |   await attach(info, 'nested-choices', { legacy, topLayerOnly: true, portalInsideOwner: true, tabBothDirections: true, scrollLocked: true, returned: true });
  245 | });
  246 | 
  247 | test('popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover', async ({ page }, info) => {
  248 |   const trigger = page.getByRole('button', { name: 'Open context', exact: true });
  249 |   await tap(page, info, trigger);
  250 |   const popover = page.getByRole('dialog', { name: 'Context', exact: true });
  251 |   await expect(popover).toBeVisible();
  252 |   const select = popover.getByRole('combobox', { name: 'Context expiry', exact: true });
  253 |   await select.click();
  254 |   await page.keyboard.press('Escape');
  255 |   await expect(popover).toBeVisible();
  256 |   await expect(select).toBeFocused();
  257 |   await page.keyboard.press('Escape');
  258 |   await expect(popover).not.toBeVisible();
  259 |   await expect(trigger).toBeFocused();
  260 |   const usage = page.getByRole('button', { name: 'Account usage', exact: true });
  261 |   await page.keyboard.press('Tab');
  262 |   await usage.focus();
  263 |   const tooltip = page.getByRole('tooltip');
  264 |   await expect(tooltip).toHaveText('Usage from this account');
  265 |   await expect(usage).toHaveAttribute('aria-describedby', /.+/);
  266 |   await page.keyboard.press('Escape');
  267 |   await expect(tooltip).not.toBeVisible();
  268 |   await usage.blur();
  269 |   await usage.hover();
  270 |   await expect(tooltip).toBeVisible();
  271 |   await page.mouse.move(0, 0);
  272 |   await expect(tooltip).not.toBeVisible();
  273 |   await tap(page, info, trigger);
  274 |   await outside(page, info);
  275 |   await expect(popover).not.toBeVisible();
  276 |   await attach(info, 'popover-tooltip', { nestedSelect: true, sequentialEscape: true, focusReturn: true, tooltipFocusHoverEscape: true });
  277 | });
  278 | 
```