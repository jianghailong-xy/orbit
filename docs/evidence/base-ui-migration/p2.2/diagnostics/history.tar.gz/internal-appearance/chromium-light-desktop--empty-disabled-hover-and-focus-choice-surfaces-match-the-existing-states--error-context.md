# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> empty, disabled, hover and focus choice surfaces match the existing states
- Location: ui-migration/choices.browser.mjs:127:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 15

@@ -52,10 +52,17 @@
          "height": 12,
          "width": 12,
          "x": 226,
          "y": 10,
        },
+       Object {
+         "color": "rgba(0, 0, 0, 0.25)",
+         "height": 12,
+         "width": 12,
+         "x": 226,
+         "y": 10,
+       },
      ],
      "origin": Object {
        "x": 24,
        "y": 148,
      },
@@ -78,11 +85,11 @@
        "x": 0,
        "y": 0,
      },
      "texts": Array [
        Object {
-         "color": "rgb(31, 35, 41)",
+         "color": "rgba(0, 0, 0, 0.25)",
          "fontSize": "14px",
          "fontWeight": "400",
          "height": 16,
          "text": "Never",
          "width": 37.359375,
@@ -91,10 +98,17 @@
        },
      ],
    },
    "hover": Object {
      "icons": Array [
+       Object {
+         "color": "rgba(0, 0, 0, 0.25)",
+         "height": 12,
+         "width": 12,
+         "x": 226,
+         "y": 10,
+       },
        Object {
          "color": "rgba(0, 0, 0, 0.25)",
          "height": 12,
          "width": 12,
          "x": 226,
```

# Page snapshot

```yaml
- main [ref=f12e4]:
  - status [ref=f12e5]: light
  - button "Switch theme" [ref=f12e6] [cursor=pointer]
  - region "Appearance sample" [ref=f12e8]:
    - generic [ref=f12e9]:
      - generic [ref=f12e10]:
        - generic: Never
        - combobox "Sample choice" [active] [ref=f12e11]
        - button "Show options" [ref=f12e12] [cursor=pointer]
        - button "Clear selection" [ref=f12e16] [cursor=pointer]
      - textbox [aria-hidden] [ref=f12e20]: never
```

# Test source

```ts
  64  |       result.icons = [...el.querySelectorAll('svg')].filter(visible).map((svg) => {
  65  |         const r = svg.getBoundingClientRect();
  66  |         return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, color: getComputedStyle(svg).color };
  67  |       });
  68  |     }
  69  |     return result;
  70  |   }, contents);
  71  | }
  72  | 
  73  | for (const kind of ['attachment', 'access', 'expiry', 'account', 'search', 'popover', 'tooltip']) {
  74  |   test(`${kind} matches the current surface, density and option states`, async ({ page }, info) => {
  75  |     const measurements = {};
  76  |     for (const system of ['antd', 'orbit']) {
  77  |       await page.goto(`${fixture}?sample=${kind}&system=${system}`);
  78  |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  79  |       const region = page.getByRole('region', { name: 'Appearance sample' });
  80  |       const choice = region.getByRole('combobox');
  81  |       if (['expiry', 'account', 'search'].includes(kind)) {
  82  |         await page.mouse.move(0, 0);
  83  |         await page.getByTestId('neutral').focus();
  84  |         await settle(page.locator('.sample-choice'));
  85  |         measurements[system] = { control: await measure(page.locator('.sample-choice'), true) };
  86  |         await shot(info, `${system}-${kind}-closed`, page.locator('.sample-choice'));
  87  |         await choice.click();
  88  |       } else if (kind === 'tooltip') await region.getByRole('button').hover();
  89  |       else await region.getByRole('button').click();
  90  |       const surface = page.locator('.sample-surface:visible');
  91  |       await settle(surface);
  92  |       if (kind !== 'tooltip') await page.mouse.move(0, 0);
  93  |       await settle(surface);
  94  |       measurements[system] = { ...measurements[system], popup: await measure(surface) };
  95  |       await shot(info, `${system}-${kind}-open`, surface);
  96  |       if (['popover', 'tooltip'].includes(kind)) {
  97  |         const arrow = page.locator(system === 'antd' ? '.sample-arrow:visible' : '.orbit-floating-arrow:visible');
  98  |         const box = await surface.boundingBox();
  99  |         const arrowBox = await arrow.boundingBox();
  100 |         measurements[system].callout = {
  101 |           arrow: { x: arrowBox.x - box.x, y: arrowBox.y - box.y, width: arrowBox.width, height: arrowBox.height },
  102 |           shape: await arrow.evaluate((el) => ({ fill: getComputedStyle(el, '::before').backgroundColor, clipPath: getComputedStyle(el, '::before').clipPath })),
  103 |           filter: await page.locator(system === 'antd' ? '.sample-floating-root:visible' : '.orbit-callout-positioner:visible').evaluate((el) => getComputedStyle(el).filter),
  104 |         };
  105 |         const x = Math.max(0, box.x - 40), y = Math.max(0, box.y - 40);
  106 |         await info.attach(`${system}-${kind}-context`, { body: await page.screenshot({ animations: 'disabled', clip: { x, y, width: Math.min(box.width + 80, info.project.use.viewport.width - x), height: box.height + 80 } }), contentType: 'image/png' });
  107 |       }
  108 |     }
  109 |     await attach(info, 'appearance', measurements);
  110 |     if (kind === 'attachment' && info.project.use.hasTouch) {
  111 |       // P0's original phone sample also measured 14px items: AntD's generated
  112 |       // selector overrides the existing 17px rule. The task explicitly requires
  113 |       // the confirmed 17px/42.4px/26px design. Retain both raw samples; assert the
  114 |       // requested differences exactly, and every other measured property unchanged.
  115 |       const expected = structuredClone(measurements.antd);
  116 |       expected.popup.surface.height = 40 + 5 * 42.390625;
  117 |       expected.popup.rows.forEach((row, i) => Object.assign(row, {
  118 |         fontSize: '17px', borderRadius: '0px', padding: '0px 0px 0px 31px',
  119 |         lineHeight: info.project.use.browserName === 'webkit' ? '26.714285px' : '26.7143px',
  120 |         y: 10 + i * 42.390625 + (i >= 2 ? 20 : 0),
  121 |       }));
  122 |       expect(measurements.orbit).toEqual(expected);
  123 |     } else expect(measurements.orbit).toEqual(measurements.antd);
  124 |   });
  125 | }
  126 | 
  127 | test('empty, disabled, hover and focus choice surfaces match the existing states', async ({ page }, info) => {
  128 |   const measurements = {};
  129 |   for (const kind of ['expiry', 'search']) for (const state of ['disabled', 'empty', 'default']) {
  130 |     const values = {};
  131 |     for (const system of ['antd', 'orbit']) {
  132 |       await page.goto(`${fixture}?sample=${kind}&system=${system}&state=${state}`);
  133 |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  134 |       const control = page.locator('.sample-choice');
  135 |       const input = page.getByRole('combobox', { name: 'Sample choice' });
  136 |       await page.mouse.move(0, 0);
  137 |       await page.getByTestId('neutral').focus();
  138 |       await settle(control);
  139 |       values[system] = { control: await measure(control, true) };
  140 |       if (state === 'disabled') {
  141 |         await expect(input).toBeDisabled();
  142 |         await shot(info, `${system}-${kind}-disabled`, control);
  143 |       } else if (state === 'empty') {
  144 |         await input.click();
  145 |         const surface = page.locator('.sample-surface:visible');
  146 |         await settle(surface);
  147 |         await expect(surface.getByText('No data', { exact: true }).and(surface.locator('div'))).toBeVisible();
  148 |         values[system].popup = await measure(surface);
  149 |         await shot(info, `${system}-${kind}-empty`, surface);
  150 |       } else {
  151 |         await control.hover();
  152 |         await settle(control);
  153 |         values[system].hover = await measure(control, true);
  154 |         await input.focus();
  155 |         await page.mouse.move(0, 0);
  156 |         await settle(control);
  157 |         values[system].focus = await measure(control, true);
  158 |         await shot(info, `${system}-${kind}-focus`, control);
  159 |       }
  160 |     }
  161 |     measurements[`${kind}-${state}`] = values;
  162 |   }
  163 |   await attach(info, 'choice-states', measurements);
> 164 |   for (const values of Object.values(measurements)) expect(values.orbit).toEqual(values.antd);
      |                                                                          ^ Error: expect(received).toEqual(expected) // deep equality
  165 | });
  166 | 
  167 | test('menu arrows, disabled items, submenu, checkbox and focus return work', async ({ page }, info) => {
  168 |   const trigger = page.getByRole('button', { name: 'Session actions', exact: true });
  169 |   await trigger.focus();
  170 |   await page.keyboard.press('ArrowDown');
  171 |   const first = page.getByRole('menuitem', { name: 'Default model', exact: true });
  172 |   await expect(first).toBeFocused();
  173 |   await page.keyboard.press('ArrowDown');
  174 |   const provider = page.getByRole('menuitem', { name: 'Provider', exact: true });
  175 |   await expect(provider).toBeFocused();
  176 |   await page.keyboard.press('ArrowRight');
  177 |   await expect(page.getByRole('menuitem', { name: 'Codex', exact: true })).toBeFocused();
  178 |   await page.keyboard.press('Escape');
  179 |   await expect(provider).toBeFocused();
  180 |   await expect(page.getByRole('menu')).toHaveCount(1);
  181 |   await page.keyboard.press('ArrowRight');
  182 |   await page.keyboard.press('ArrowDown');
  183 |   await page.keyboard.press('Enter');
  184 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('claude');
  185 |   await expect(trigger).toBeFocused();
  186 |   await trigger.click();
  187 |   const tag = page.getByRole('menuitemcheckbox', { name: 'Important tag' });
  188 |   await tag.click();
  189 |   await expect(tag).toHaveAttribute('aria-checked', 'true');
  190 |   await expect(page.getByRole('status', { name: 'Tag', exact: true })).toHaveText('true');
  191 |   await tag.press('Space');
  192 |   await expect(tag).toHaveAttribute('aria-checked', 'false');
  193 |   await page.keyboard.press('Escape');
  194 |   await expect(trigger).toBeFocused();
  195 |   await attach(info, 'keyboard-menu', { disabledSkipped: true, submenuOnlyEscape: true, selection: 'claude', checkboxStaysOpen: true, focusReturned: true });
  196 | });
  197 | 
  198 | test('touch or pointer menus dismiss outside, fit viewport and open a dialog with stable return focus', async ({ page }, info) => {
  199 |   const trigger = page.getByRole('button', { name: 'Add attachment', exact: true });
  200 |   await tap(page, info, trigger);
  201 |   const menu = page.getByRole('menu');
  202 |   const box = await menu.boundingBox();
  203 |   expect(box.x).toBeGreaterThanOrEqual(0);
  204 |   expect(box.x + box.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  205 |   await tap(page, info, page.getByRole('menuitem', { name: 'Image', exact: true }));
  206 |   await expect(menu).not.toBeVisible();
  207 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('image');
  208 |   await tap(page, info, trigger);
  209 |   await outside(page, info);
  210 |   await expect(menu).not.toBeVisible();
  211 |   const actions = page.getByRole('button', { name: 'Session actions', exact: true });
  212 |   await tap(page, info, actions);
  213 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  214 |   const sub = page.getByRole('menu').filter({ has: page.getByRole('menuitem', { name: 'Codex', exact: true }) });
  215 |   await expect(sub).toBeVisible();
  216 |   const subBox = await sub.boundingBox();
  217 |   expect(subBox.x).toBeGreaterThanOrEqual(0);
  218 |   expect(subBox.x + subBox.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  219 |   await page.keyboard.press('Escape');
  220 |   await tap(page, info, page.getByRole('menuitem', { name: 'Edit details', exact: true }));
  221 |   const dialog = page.getByRole('dialog', { name: 'Edit details', exact: true });
  222 |   await expect(dialog).toBeVisible();
  223 |   await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  224 |   await page.keyboard.press('Escape');
  225 |   await expect(actions).toBeFocused();
  226 |   await attach(info, 'pointer-menu', { input: info.project.use.hasTouch ? 'touch' : 'mouse', outside: true, menuBounds: box, submenuBounds: subBox, dialogReturn: true });
  227 | });
  228 | 
  229 | test('select supports arrows, Enter, clear, empty, disabled and empty-string account values', async ({ page }, info) => {
  230 |   const select = page.getByRole('combobox', { name: 'Expires', exact: true });
  231 |   await select.focus();
  232 |   await page.keyboard.press('ArrowDown');
  233 |   await page.keyboard.press('ArrowDown');
  234 |   await page.keyboard.press('Enter');
  235 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('7');
  236 |   await expect(select).toBeFocused();
  237 |   await select.click();
  238 |   await expect(page.getByRole('option', { name: '7 days', exact: true })).toHaveAttribute('aria-selected', 'true');
  239 |   await expect(page.getByRole('option', { name: '30 days', exact: true })).toHaveAttribute('aria-disabled', 'true');
  240 |   await page.keyboard.press('Escape');
  241 |   await page.getByRole('button', { name: 'Clear selection' }).first().click();
  242 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('null');
  243 |   await expect(select).toBeFocused();
  244 |   await expect(page.getByRole('combobox', { name: 'Disabled select', exact: true })).toBeDisabled();
  245 |   await expect(page.getByRole('combobox', { name: 'Disabled search', exact: true })).toBeDisabled();
  246 |   await page.getByRole('combobox', { name: 'Empty select', exact: true }).click();
  247 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  248 |   await page.keyboard.press('Escape');
  249 |   const automatic = page.getByRole('combobox', { name: 'Automatic account', exact: true });
  250 |   await expect(automatic).toContainText('Automatic');
  251 |   await automatic.click();
  252 |   await expect(page.getByRole('option', { name: /Automatic/ })).toHaveAttribute('aria-selected', 'true');
  253 |   await outside(page, info);
  254 |   await expect(automatic).toHaveAttribute('aria-expanded', 'false');
  255 |   await attach(info, 'select', { selected: '7', cleared: true, disabled: true, empty: true, emptyStringIsSelection: true });
  256 | });
  257 | 
  258 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  259 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  260 |   await expect(input).toHaveAccessibleDescription('Orbit workspace');
  261 |   await input.click();
  262 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  263 |   await input.fill('docs');
  264 |   await expect(page.getByRole('option')).toHaveCount(1);
```