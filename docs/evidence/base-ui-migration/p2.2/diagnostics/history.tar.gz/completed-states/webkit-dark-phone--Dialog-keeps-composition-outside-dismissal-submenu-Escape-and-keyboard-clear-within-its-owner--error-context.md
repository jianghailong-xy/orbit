# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> Dialog keeps composition, outside dismissal, submenu Escape and keyboard clear within its owner
- Location: ui-migration/choices.browser.mjs:390:1

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: locator.tap: Test timeout of 90000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: 'Share workspace', exact: true }).getByRole('heading', { name: 'Share workspace' })

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main [ref=e4]:
    - status [ref=e5]: dark
    - button [ref=e6] [cursor=pointer]:
      - generic [ref=e7]: Switch theme
    - button [ref=e8] [cursor=pointer]:
      - generic [ref=e9]: Open Dialog
    - button [ref=e10] [cursor=pointer]:
      - generic [ref=e11]: Open legacy Modal
    - region [ref=e12]:
      - generic [ref=e13]:
        - generic [ref=e14]:
          - combobox [ref=e15] [cursor=pointer]:
            - generic [ref=e16]: Never
          - button [ref=e20] [cursor=pointer]
        - textbox [aria-hidden] [ref=e24]: never
        - generic [ref=e25]:
          - generic: Orbit workspace
          - combobox [ref=e26]
          - button [ref=e27] [cursor=pointer]
          - button [ref=e31] [cursor=pointer]
        - textbox [aria-hidden] [ref=e35]: orbit
        - combobox [disabled] [ref=e37]:
          - generic [ref=e38]: Never
        - textbox [disabled] [aria-hidden] [ref=e42]: never
        - generic [ref=e43]:
          - generic: Never
          - combobox [disabled] [ref=e44]
          - button [disabled] [ref=e45] [cursor=pointer]
        - textbox [disabled] [aria-hidden] [ref=e49]: never
        - combobox [ref=e51] [cursor=pointer]:
          - generic [ref=e52]: No accounts
        - textbox [aria-hidden] [ref=e56]
        - combobox [ref=e58] [cursor=pointer]:
          - generic [ref=e59]: Automatic
        - textbox [aria-hidden] [ref=e63]
        - button [ref=e64] [cursor=pointer]:
          - generic [ref=e65]: Session actions
        - button [ref=e66] [cursor=pointer]:
          - generic [ref=e67]: Add attachment
        - button [ref=e68] [cursor=pointer]:
          - generic [ref=e69]: Open context
        - button [ref=e70] [cursor=pointer]:
          - generic [ref=e71]: Account usage
        - button [disabled] [ref=e73]:
          - generic [ref=e74]: Unavailable action
        - button [ref=e75] [cursor=pointer]:
          - generic [ref=e76]: After choices
        - status [ref=e77]: never
        - status [ref=e78]: orbit
        - status [ref=e79]: none
        - status [ref=e80]: "false"
      - generic [ref=e81]:
        - combobox [ref=e82]
        - button [ref=e83] [cursor=pointer]
      - textbox [aria-hidden] [ref=e87]
      - status [ref=e88]: none
  - dialog [ref=e92]:
    - generic [aria-hidden] [ref=e93]:
      - button [ref=e94] [cursor=pointer]
      - heading [level=2] [ref=e98]: Share workspace
    - generic [ref=e100]:
      - generic [aria-hidden] [ref=e101]:
        - combobox [ref=e102] [cursor=pointer]:
          - generic [ref=e103]: Never
        - button [ref=e107] [cursor=pointer]
      - textbox [aria-hidden] [ref=e111]: never
      - generic [ref=e112]:
        - generic [aria-hidden]: Orbit workspace
        - button "Dismiss" [ref=e113]
        - combobox "Workspace" [expanded] [active] [ref=e114]
        - button [expanded] [aria-hidden] [ref=e115] [cursor=pointer]
        - button [aria-hidden] [ref=e119] [cursor=pointer]
      - textbox [aria-hidden] [ref=e123]: orbit
      - combobox [disabled] [ref=e125]:
        - generic [ref=e126]: Never
      - textbox [disabled] [aria-hidden] [ref=e130]: never
      - generic [aria-hidden] [ref=e131]:
        - generic: Never
        - combobox [disabled] [ref=e132]
        - button [disabled] [ref=e133] [cursor=pointer]
      - textbox [disabled] [aria-hidden] [ref=e137]: never
      - combobox [ref=e139] [cursor=pointer]:
        - generic [ref=e140]: No accounts
      - textbox [aria-hidden] [ref=e144]
      - combobox [ref=e146] [cursor=pointer]:
        - generic [ref=e147]: Automatic
      - textbox [aria-hidden] [ref=e151]
      - button [aria-hidden] [ref=e152] [cursor=pointer]:
        - generic [ref=e153]: Session actions
      - button [aria-hidden] [ref=e154] [cursor=pointer]:
        - generic [ref=e155]: Add attachment
      - button [aria-hidden] [ref=e156] [cursor=pointer]:
        - generic [ref=e157]: Open context
      - button [aria-hidden] [ref=e158] [cursor=pointer]:
        - generic [ref=e159]: Account usage
      - button [disabled] [ref=e161]:
        - generic [ref=e162]: Unavailable action
      - button [aria-hidden] [ref=e163] [cursor=pointer]:
        - generic [ref=e164]: After choices
      - status [aria-hidden] [ref=e165]: never
      - status [aria-hidden] [ref=e166]: orbit
      - status [aria-hidden] [ref=e167]: none
      - status [aria-hidden] [ref=e168]: "false"
    - generic:
      - generic:
        - generic [ref=e169]:
          - status
          - listbox [ref=e170]:
            - group "Local" [ref=e171]:
              - generic [aria-hidden] [ref=e172]: Local
              - option "Orbit workspace" [selected] [ref=e173] [cursor=pointer]
              - option "文档 Docs" [ref=e174] [cursor=pointer]
              - option "Offline workspace" [disabled] [ref=e175]
            - group "Remote" [ref=e176]:
              - generic [aria-hidden] [ref=e177]: Remote
              - option "Runner workspace" [ref=e178] [cursor=pointer]
        - button "Dismiss" [ref=e179]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | const fixture = '/ui-migration/choices.html';
  4   | const errors = new WeakMap();
  5   | test.beforeEach(async ({ page }, info) => {
  6   |   errors.set(page, []);
  7   |   page.on('pageerror', (error) => errors.get(page).push(error.message));
  8   |   await page.goto(fixture);
  9   |   await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  10  |   await page.evaluate(() => document.fonts.ready);
  11  | });
  12  | test.afterEach(async ({ page }) => { expect(errors.get(page)).toEqual([]); });
  13  | const attach = (info, name, value) => info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  14  | const shot = (info, name, locator) => locator.screenshot({ animations: 'disabled' }).then((body) => info.attach(name, { body, contentType: 'image/png' }));
  15  | async function settle(locator) {
  16  |   await expect(locator).toBeVisible();
  17  |   await locator.evaluate(async (el) => {
  18  |     const animations = new Set(el.getAnimations({ subtree: true }));
  19  |     for (let node = el.parentElement; node; node = node.parentElement) for (const animation of node.getAnimations()) animations.add(animation);
  20  |     await Promise.all([...animations].filter((a) => a.effect?.getComputedTiming().iterations !== Infinity).map((a) => a.finished.catch(() => {})));
  21  |     await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  22  |   });
  23  | }
  24  | async function tap(page, info, locator) {
> 25  |   if (info.project.use.hasTouch) await locator.tap();
      |                                                ^ Error: locator.tap: Test timeout of 90000ms exceeded.
  26  |   else await locator.click();
  27  | }
  28  | async function outside(page, info) {
  29  |   if (info.project.use.hasTouch) await page.touchscreen.tap(3, 60);
  30  |   else await page.mouse.click(3, 60);
  31  | }
  32  | async function measure(locator) {
  33  |   return locator.evaluate((el) => {
  34  |     const root = el.getBoundingClientRect();
  35  |     const metrics = (node) => {
  36  |       const r = node.getBoundingClientRect(), s = getComputedStyle(node);
  37  |       const keys = ['fontFamily', 'fontSize', 'lineHeight', 'fontWeight', 'color', 'backgroundColor', 'borderRadius', 'borderColor', 'borderWidth', 'borderStyle', 'padding', 'boxShadow'];
  38  |       return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, ...Object.fromEntries(keys.map((key) => [key, s[key]])) };
  39  |     };
  40  |     return { surface: metrics(el), rows: [...el.querySelectorAll('[role="menuitem"], [role="option"]')].map((row) => ({ label: row.textContent, ...metrics(row) })) };
  41  |   });
  42  | }
  43  | 
  44  | for (const kind of ['attachment', 'access', 'expiry', 'account', 'search', 'popover', 'tooltip']) {
  45  |   test(`${kind} matches the current surface, density and option states`, async ({ page }, info) => {
  46  |     const measurements = {};
  47  |     for (const system of ['antd', 'orbit']) {
  48  |       await page.goto(`${fixture}?sample=${kind}&system=${system}`);
  49  |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  50  |       const region = page.getByRole('region', { name: 'Appearance sample' });
  51  |       const choice = region.getByRole('combobox');
  52  |       if (['expiry', 'account', 'search'].includes(kind)) {
  53  |         await page.mouse.move(0, 0);
  54  |         await page.getByTestId('neutral').focus();
  55  |         await settle(page.locator('.sample-choice'));
  56  |         measurements[system] = { control: await measure(page.locator('.sample-choice')) };
  57  |         await shot(info, `${system}-${kind}-closed`, page.locator('.sample-choice'));
  58  |         await choice.click();
  59  |       } else if (kind === 'tooltip') await region.getByRole('button').hover();
  60  |       else await region.getByRole('button').click();
  61  |       const surface = page.locator('.sample-surface:visible');
  62  |       await settle(surface);
  63  |       if (kind !== 'tooltip') await page.mouse.move(0, 0);
  64  |       await settle(surface);
  65  |       measurements[system] = { ...measurements[system], popup: await measure(surface) };
  66  |       await shot(info, `${system}-${kind}-open`, surface);
  67  |       if (['popover', 'tooltip'].includes(kind)) {
  68  |         const arrow = page.locator(system === 'antd' ? '.sample-arrow:visible' : '.orbit-floating-arrow:visible');
  69  |         const box = await surface.boundingBox();
  70  |         const arrowBox = await arrow.boundingBox();
  71  |         measurements[system].callout = {
  72  |           arrow: { x: arrowBox.x - box.x, y: arrowBox.y - box.y, width: arrowBox.width, height: arrowBox.height },
  73  |           shape: await arrow.evaluate((el) => ({ fill: getComputedStyle(el, '::before').backgroundColor, clipPath: getComputedStyle(el, '::before').clipPath })),
  74  |           filter: await page.locator(system === 'antd' ? '.sample-floating-root:visible' : '.orbit-callout-positioner:visible').evaluate((el) => getComputedStyle(el).filter),
  75  |         };
  76  |         const x = Math.max(0, box.x - 40), y = Math.max(0, box.y - 40);
  77  |         await info.attach(`${system}-${kind}-context`, { body: await page.screenshot({ animations: 'disabled', clip: { x, y, width: Math.min(box.width + 80, info.project.use.viewport.width - x), height: box.height + 80 } }), contentType: 'image/png' });
  78  |       }
  79  |     }
  80  |     await attach(info, 'appearance', measurements);
  81  |     if (kind === 'attachment' && info.project.use.hasTouch) {
  82  |       // P0's original phone sample also measured 14px items: AntD's generated
  83  |       // selector overrides the existing 17px rule. The task explicitly requires
  84  |       // the confirmed 17px/42.4px/26px design. Retain both raw samples; assert the
  85  |       // requested differences exactly, and every other measured property unchanged.
  86  |       const expected = structuredClone(measurements.antd);
  87  |       expected.popup.surface.height = 40 + 5 * 42.390625;
  88  |       expected.popup.rows.forEach((row, i) => Object.assign(row, {
  89  |         fontSize: '17px', borderRadius: '0px', padding: '0px 0px 0px 31px',
  90  |         lineHeight: info.project.use.browserName === 'webkit' ? '26.714285px' : '26.7143px',
  91  |         y: 10 + i * 42.390625 + (i >= 2 ? 20 : 0),
  92  |       }));
  93  |       expect(measurements.orbit).toEqual(expected);
  94  |     } else expect(measurements.orbit).toEqual(measurements.antd);
  95  |   });
  96  | }
  97  | 
  98  | test('empty, disabled, hover and focus choice surfaces match the existing states', async ({ page }, info) => {
  99  |   const measurements = {};
  100 |   for (const kind of ['expiry', 'search']) for (const state of ['disabled', 'empty', 'default']) {
  101 |     const values = {};
  102 |     for (const system of ['antd', 'orbit']) {
  103 |       await page.goto(`${fixture}?sample=${kind}&system=${system}&state=${state}`);
  104 |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  105 |       const control = page.locator('.sample-choice');
  106 |       const input = page.getByRole('combobox', { name: 'Sample choice' });
  107 |       await page.mouse.move(0, 0);
  108 |       await page.getByTestId('neutral').focus();
  109 |       await settle(control);
  110 |       values[system] = { control: await measure(control) };
  111 |       if (state === 'disabled') {
  112 |         await expect(input).toBeDisabled();
  113 |         await shot(info, `${system}-${kind}-disabled`, control);
  114 |       } else if (state === 'empty') {
  115 |         await input.click();
  116 |         const surface = page.locator('.sample-surface:visible');
  117 |         await settle(surface);
  118 |         await expect(surface.getByText('No data')).toBeVisible();
  119 |         values[system].popup = await measure(surface);
  120 |         await shot(info, `${system}-${kind}-empty`, surface);
  121 |       } else {
  122 |         await control.hover();
  123 |         await settle(control);
  124 |         values[system].hover = await measure(control);
  125 |         await input.focus();
```