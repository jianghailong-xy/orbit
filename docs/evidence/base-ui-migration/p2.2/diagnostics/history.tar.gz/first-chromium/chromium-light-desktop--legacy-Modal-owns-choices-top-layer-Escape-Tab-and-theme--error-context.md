# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> legacy Modal owns choices, top-layer Escape, Tab and theme
- Location: ui-migration/choices.browser.mjs:211:37

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: locator.click: Test timeout of 90000ms exceeded.
Call log:
  - waiting for getByRole('dialog', { name: 'Legacy share', exact: true }).getByRole('button', { name: 'Session actions', exact: true })
    - locator resolved to <button tabindex="0" type="button" id="base-ui-_r_25_" aria-haspopup="menu" aria-expanded="false" class="orbit-button orbit-button-default orbit-button-middle">…</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not stable
    - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting 100ms
    - waiting for element to be visible, enabled and stable
  - element was detached from the DOM, retrying

```

# Page snapshot

```yaml
- main [ref=e4]:
  - status [ref=e5]: light
  - button "Switch theme" [ref=e6] [cursor=pointer]
  - button "Open Dialog" [ref=e8] [cursor=pointer]
  - button "Open legacy Modal" [active] [ref=e10] [cursor=pointer]
  - region "Standalone choices" [ref=e12]:
    - generic [ref=e13]:
      - generic [ref=e14]:
        - combobox "Expires" [ref=e15] [cursor=pointer]:
          - generic [ref=e16]: Never
        - button "Clear selection" [ref=e20] [cursor=pointer]
      - textbox [aria-hidden] [ref=e24]: never
      - generic [ref=e25]:
        - generic [aria-hidden]: Orbit workspace
        - combobox "Workspace" [ref=e26]
        - button "Show options" [ref=e27] [cursor=pointer]
        - button "Clear selection" [ref=e31] [cursor=pointer]
      - textbox [aria-hidden] [ref=e35]: orbit
      - combobox "Disabled select" [disabled] [ref=e37]:
        - generic [ref=e38]: Never
      - textbox [disabled] [aria-hidden] [ref=e42]: never
      - generic [ref=e43]:
        - generic [aria-hidden]: Never
        - combobox "Disabled search" [disabled] [ref=e44]
        - button "Show options" [disabled] [ref=e45] [cursor=pointer]
      - textbox [disabled] [aria-hidden] [ref=e49]: never
      - combobox "Empty select" [ref=e51] [cursor=pointer]:
        - generic [ref=e52]: No accounts
      - textbox [aria-hidden] [ref=e56]
      - combobox "Automatic account" [ref=e58] [cursor=pointer]:
        - generic [ref=e59]: Automatic
      - textbox [aria-hidden] [ref=e63]
      - button "Session actions" [ref=e64] [cursor=pointer]
      - button "Add attachment" [ref=e66] [cursor=pointer]
      - button "Open context" [ref=e68] [cursor=pointer]
      - button "Account usage" [ref=e70] [cursor=pointer]
      - button "Unavailable action" [disabled] [ref=e73]
      - button "After choices" [ref=e75] [cursor=pointer]
      - status "Expiry value" [ref=e77]: never
      - status "Workspace value" [ref=e78]: orbit
      - status "Action" [ref=e79]: none
      - status "Tag" [ref=e80]: "false"
    - generic [ref=e81]:
      - combobox "Add prerequisite" [ref=e82]
      - button "Show options" [ref=e83] [cursor=pointer]
    - textbox [aria-hidden] [ref=e87]
    - status "Prerequisite" [ref=e88]: none
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | const fixture = '/ui-migration/choices.html';
  4   | const errors = new WeakMap();
  5   | test.beforeEach(async ({ page }, info) => {
  6   |   errors.set(page, []);
  7   |   page.on('pageerror', (error) => errors.get(page).push(error.message));
  8   |   await page.goto(fixture);
  9   |   await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  10  |   await page.evaluate(() => document.fonts.ready);
  11  | });
  12  | test.afterEach(async ({ page }) => { expect(errors.get(page)).toEqual([]); });
  13  | const attach = (info, name, value) => info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  14  | const shot = (info, name, locator) => locator.screenshot({ animations: 'disabled' }).then((body) => info.attach(name, { body, contentType: 'image/png' }));
  15  | async function settle(locator) {
  16  |   await expect(locator).toBeVisible();
  17  |   await locator.evaluate(async (el) => {
  18  |     await Promise.all(el.getAnimations({ subtree: true }).filter((a) => a.effect?.getComputedTiming().iterations !== Infinity).map((a) => a.finished.catch(() => {})));
  19  |     await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  20  |   });
  21  | }
  22  | async function tap(page, info, locator) {
  23  |   if (info.project.use.hasTouch) await locator.tap();
> 24  |   else await locator.click();
      |                      ^ Error: locator.click: Test timeout of 90000ms exceeded.
  25  | }
  26  | async function outside(page, info) {
  27  |   if (info.project.use.hasTouch) await page.touchscreen.tap(3, 60);
  28  |   else await page.mouse.click(3, 60);
  29  | }
  30  | async function measure(locator) {
  31  |   return locator.evaluate((el) => {
  32  |     const root = el.getBoundingClientRect();
  33  |     const metrics = (node) => {
  34  |       const r = node.getBoundingClientRect(), s = getComputedStyle(node);
  35  |       const keys = ['fontFamily', 'fontSize', 'lineHeight', 'fontWeight', 'color', 'backgroundColor', 'borderRadius', 'borderColor', 'borderWidth', 'borderStyle', 'padding', 'boxShadow'];
  36  |       return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, ...Object.fromEntries(keys.map((key) => [key, s[key]])) };
  37  |     };
  38  |     return { surface: metrics(el), rows: [...el.querySelectorAll('[role="menuitem"], [role="option"]')].map((row) => ({ label: row.textContent, ...metrics(row) })) };
  39  |   });
  40  | }
  41  | 
  42  | for (const kind of ['attachment', 'access', 'expiry', 'account', 'search', 'popover', 'tooltip']) {
  43  |   test(`${kind} matches the current surface, density and option states`, async ({ page }, info) => {
  44  |     const measurements = {};
  45  |     for (const system of ['antd', 'orbit']) {
  46  |       await page.goto(`${fixture}?sample=${kind}&system=${system}`);
  47  |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  48  |       const region = page.getByRole('region', { name: 'Appearance sample' });
  49  |       const choice = region.getByRole('combobox');
  50  |       if (['expiry', 'account', 'search'].includes(kind)) {
  51  |         await page.mouse.move(0, 0);
  52  |         await page.getByTestId('neutral').focus();
  53  |         measurements[system] = { control: await measure(page.locator('.sample-choice')) };
  54  |         await shot(info, `${system}-${kind}-closed`, page.locator('.sample-choice'));
  55  |         await choice.click();
  56  |       } else if (kind === 'tooltip') await region.getByRole('button').hover();
  57  |       else await region.getByRole('button').click();
  58  |       const surface = page.locator('.sample-surface:visible');
  59  |       await settle(surface);
  60  |       if (kind !== 'tooltip') await page.mouse.move(0, 0);
  61  |       await settle(surface);
  62  |       measurements[system] = { ...measurements[system], popup: await measure(surface) };
  63  |       await shot(info, `${system}-${kind}-open`, surface);
  64  |     }
  65  |     await attach(info, 'appearance', measurements);
  66  |     expect(measurements.orbit).toEqual(measurements.antd);
  67  |   });
  68  | }
  69  | 
  70  | test('menu arrows, disabled items, submenu, checkbox and focus return work', async ({ page }, info) => {
  71  |   const trigger = page.getByRole('button', { name: 'Session actions', exact: true });
  72  |   await trigger.focus();
  73  |   await page.keyboard.press('ArrowDown');
  74  |   const first = page.getByRole('menuitem', { name: 'Default model', exact: true });
  75  |   await expect(first).toBeFocused();
  76  |   await page.keyboard.press('ArrowDown');
  77  |   const provider = page.getByRole('menuitem', { name: 'Provider', exact: true });
  78  |   await expect(provider).toBeFocused();
  79  |   await page.keyboard.press('ArrowRight');
  80  |   await expect(page.getByRole('menuitem', { name: 'Codex', exact: true })).toBeFocused();
  81  |   await page.keyboard.press('Escape');
  82  |   await expect(provider).toBeFocused();
  83  |   await expect(page.getByRole('menu')).toHaveCount(1);
  84  |   await page.keyboard.press('ArrowRight');
  85  |   await page.keyboard.press('ArrowDown');
  86  |   await page.keyboard.press('Enter');
  87  |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('claude');
  88  |   await expect(trigger).toBeFocused();
  89  |   await trigger.click();
  90  |   const tag = page.getByRole('menuitemcheckbox', { name: 'Important tag' });
  91  |   await tag.click();
  92  |   await expect(tag).toHaveAttribute('aria-checked', 'true');
  93  |   await expect(page.getByRole('status', { name: 'Tag', exact: true })).toHaveText('true');
  94  |   await tag.press('Space');
  95  |   await expect(tag).toHaveAttribute('aria-checked', 'false');
  96  |   await page.keyboard.press('Escape');
  97  |   await expect(trigger).toBeFocused();
  98  |   await attach(info, 'keyboard-menu', { disabledSkipped: true, submenuOnlyEscape: true, selection: 'claude', checkboxStaysOpen: true, focusReturned: true });
  99  | });
  100 | 
  101 | test('touch or pointer menus dismiss outside, fit viewport and open a dialog with stable return focus', async ({ page }, info) => {
  102 |   const trigger = page.getByRole('button', { name: 'Add attachment', exact: true });
  103 |   await tap(page, info, trigger);
  104 |   const menu = page.getByRole('menu');
  105 |   const box = await menu.boundingBox();
  106 |   expect(box.x).toBeGreaterThanOrEqual(0);
  107 |   expect(box.x + box.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  108 |   await tap(page, info, page.getByRole('menuitem', { name: 'Image', exact: true }));
  109 |   await expect(menu).not.toBeVisible();
  110 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('image');
  111 |   await tap(page, info, trigger);
  112 |   await outside(page, info);
  113 |   await expect(menu).not.toBeVisible();
  114 |   const actions = page.getByRole('button', { name: 'Session actions', exact: true });
  115 |   await tap(page, info, actions);
  116 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  117 |   const sub = page.getByRole('menu').filter({ has: page.getByRole('menuitem', { name: 'Codex', exact: true }) });
  118 |   await expect(sub).toBeVisible();
  119 |   const subBox = await sub.boundingBox();
  120 |   expect(subBox.x).toBeGreaterThanOrEqual(0);
  121 |   expect(subBox.x + subBox.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  122 |   await page.keyboard.press('Escape');
  123 |   await tap(page, info, page.getByRole('menuitem', { name: 'Edit details', exact: true }));
  124 |   const dialog = page.getByRole('dialog', { name: 'Edit details', exact: true });
```