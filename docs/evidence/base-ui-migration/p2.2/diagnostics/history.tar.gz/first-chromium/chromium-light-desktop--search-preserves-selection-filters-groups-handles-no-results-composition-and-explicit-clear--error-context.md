# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> search preserves selection, filters groups, handles no results, composition and explicit clear
- Location: ui-migration/choices.browser.mjs:161:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('status', { name: 'Workspace value', exact: true })
Expected: "docs"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" getByRole('status', { name: 'Workspace value', exact: true }) with timeout 15000ms
  - waiting for getByRole('status', { name: 'Workspace value', exact: true })

```

```yaml
- main:
  - region "Standalone choices":
    - button "Dismiss"
    - combobox "Workspace" [expanded]
- status
- listbox:
  - group "Local":
    - option "Orbit workspace"
    - option "文档 Docs" [selected]
    - option "Offline workspace" [disabled]
  - group "Remote":
    - option "Runner workspace"
- button "Dismiss"
```

# Test source

```ts
  79  |   await page.keyboard.press('ArrowRight');
  80  |   await expect(page.getByRole('menuitem', { name: 'Codex', exact: true })).toBeFocused();
  81  |   await page.keyboard.press('Escape');
  82  |   await expect(provider).toBeFocused();
  83  |   await expect(page.getByRole('menu')).toHaveCount(1);
  84  |   await page.keyboard.press('ArrowRight');
  85  |   await page.keyboard.press('ArrowDown');
  86  |   await page.keyboard.press('Enter');
  87  |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('claude');
  88  |   await expect(trigger).toBeFocused();
  89  |   await trigger.click();
  90  |   const tag = page.getByRole('menuitemcheckbox', { name: 'Important tag' });
  91  |   await tag.click();
  92  |   await expect(tag).toHaveAttribute('aria-checked', 'true');
  93  |   await expect(page.getByRole('status', { name: 'Tag', exact: true })).toHaveText('true');
  94  |   await tag.press('Space');
  95  |   await expect(tag).toHaveAttribute('aria-checked', 'false');
  96  |   await page.keyboard.press('Escape');
  97  |   await expect(trigger).toBeFocused();
  98  |   await attach(info, 'keyboard-menu', { disabledSkipped: true, submenuOnlyEscape: true, selection: 'claude', checkboxStaysOpen: true, focusReturned: true });
  99  | });
  100 | 
  101 | test('touch or pointer menus dismiss outside, fit viewport and open a dialog with stable return focus', async ({ page }, info) => {
  102 |   const trigger = page.getByRole('button', { name: 'Add attachment', exact: true });
  103 |   await tap(page, info, trigger);
  104 |   const menu = page.getByRole('menu');
  105 |   const box = await menu.boundingBox();
  106 |   expect(box.x).toBeGreaterThanOrEqual(0);
  107 |   expect(box.x + box.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  108 |   await tap(page, info, page.getByRole('menuitem', { name: 'Image', exact: true }));
  109 |   await expect(menu).not.toBeVisible();
  110 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('image');
  111 |   await tap(page, info, trigger);
  112 |   await outside(page, info);
  113 |   await expect(menu).not.toBeVisible();
  114 |   const actions = page.getByRole('button', { name: 'Session actions', exact: true });
  115 |   await tap(page, info, actions);
  116 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  117 |   const sub = page.getByRole('menu').filter({ has: page.getByRole('menuitem', { name: 'Codex', exact: true }) });
  118 |   await expect(sub).toBeVisible();
  119 |   const subBox = await sub.boundingBox();
  120 |   expect(subBox.x).toBeGreaterThanOrEqual(0);
  121 |   expect(subBox.x + subBox.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  122 |   await page.keyboard.press('Escape');
  123 |   await tap(page, info, page.getByRole('menuitem', { name: 'Edit details', exact: true }));
  124 |   const dialog = page.getByRole('dialog', { name: 'Edit details', exact: true });
  125 |   await expect(dialog).toBeVisible();
  126 |   await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  127 |   await page.keyboard.press('Escape');
  128 |   await expect(actions).toBeFocused();
  129 |   await attach(info, 'pointer-menu', { input: info.project.use.hasTouch ? 'touch' : 'mouse', outside: true, menuBounds: box, submenuBounds: subBox, dialogReturn: true });
  130 | });
  131 | 
  132 | test('select supports arrows, Enter, clear, empty, disabled and empty-string account values', async ({ page }, info) => {
  133 |   const select = page.getByRole('combobox', { name: 'Expires', exact: true });
  134 |   await select.focus();
  135 |   await page.keyboard.press('ArrowDown');
  136 |   await page.keyboard.press('ArrowDown');
  137 |   await page.keyboard.press('Enter');
  138 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('7');
  139 |   await expect(select).toBeFocused();
  140 |   await select.click();
  141 |   await expect(page.getByRole('option', { name: '7 days', exact: true })).toHaveAttribute('aria-selected', 'true');
  142 |   await expect(page.getByRole('option', { name: '30 days', exact: true })).toHaveAttribute('aria-disabled', 'true');
  143 |   await page.keyboard.press('Escape');
  144 |   await page.getByRole('button', { name: 'Clear selection' }).first().click();
  145 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('null');
  146 |   await expect(select).toBeFocused();
  147 |   await expect(page.getByRole('combobox', { name: 'Disabled select', exact: true })).toBeDisabled();
  148 |   await expect(page.getByRole('combobox', { name: 'Disabled search', exact: true })).toBeDisabled();
  149 |   await page.getByRole('combobox', { name: 'Empty select', exact: true }).click();
  150 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  151 |   await page.keyboard.press('Escape');
  152 |   const automatic = page.getByRole('combobox', { name: 'Automatic account', exact: true });
  153 |   await expect(automatic).toContainText('Automatic');
  154 |   await automatic.click();
  155 |   await expect(page.getByRole('option', { name: /Automatic/ })).toHaveAttribute('aria-selected', 'true');
  156 |   await outside(page, info);
  157 |   await expect(automatic).toHaveAttribute('aria-expanded', 'false');
  158 |   await attach(info, 'select', { selected: '7', cleared: true, disabled: true, empty: true, emptyStringIsSelection: true });
  159 | });
  160 | 
  161 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  162 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  163 |   await input.click();
  164 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  165 |   await input.fill('docs');
  166 |   await expect(page.getByRole('option')).toHaveCount(1);
  167 |   await page.keyboard.press('Enter');
  168 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('docs');
  169 |   await expect(input).toBeFocused();
  170 |   await input.fill('missing');
  171 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  172 |   await page.keyboard.press('Escape');
  173 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('docs');
  174 |   await input.click();
  175 |   await input.dispatchEvent('compositionstart');
  176 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  177 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  178 |   await expect(input).toHaveAttribute('aria-expanded', 'true');
> 179 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('docs');
      |                                                                                    ^ Error: expect(locator).toHaveText(expected) failed
  180 |   await input.dispatchEvent('compositionend', { data: '文档' });
  181 |   await input.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  182 |   await input.fill('文档');
  183 |   await expect(page.getByRole('option')).toHaveCount(1);
  184 |   await page.keyboard.press('Enter');
  185 |   await page.getByRole('button', { name: 'Clear selection' }).nth(1).click();
  186 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  187 |   await expect(input).toBeFocused();
  188 |   await attach(info, 'search', { grouping: true, chinese: true, syntheticCompositionIgnored: true, escapePreservesValue: true, explicitClear: true });
  189 | });
  190 | 
  191 | test('remote search accepts server labels and resets an action picker without local filtering', async ({ page }, info) => {
  192 |   let release;
  193 |   const gate = new Promise((resolve) => { release = resolve; });
  194 |   await page.route('**/__choices-search?*', async (route) => {
  195 |     await gate;
  196 |     await route.fulfill({ json: [{ value: 'task-1', label: 'Server ranked result' }] });
  197 |   });
  198 |   const input = page.getByRole('combobox', { name: 'Add prerequisite', exact: true });
  199 |   await input.fill('query');
  200 |   await expect(input).toHaveAttribute('aria-busy', 'true');
  201 |   release();
  202 |   const option = page.getByRole('option', { name: 'Server ranked result', exact: true });
  203 |   await expect(option).toBeVisible();
  204 |   await option.click();
  205 |   await expect(page.getByRole('status', { name: 'Prerequisite', exact: true })).toHaveText('task-1');
  206 |   await expect(input).toHaveValue('');
  207 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  208 |   await attach(info, 'remote-search', { loadingExposed: true, filterDisabled: true, valueNullResetsQuery: true });
  209 | });
  210 | 
  211 | for (const legacy of [false, true]) test(`${legacy ? 'legacy Modal' : 'Dialog'} owns choices, top-layer Escape, Tab and theme`, async ({ page }, info) => {
  212 |   const trigger = page.getByRole('button', { name: legacy ? 'Open legacy Modal' : 'Open Dialog', exact: true });
  213 |   await tap(page, info, trigger);
  214 |   const dialog = page.getByRole('dialog', { name: legacy ? 'Legacy share' : 'Share workspace', exact: true });
  215 |   await settle(dialog);
  216 |   const input = dialog.getByRole('combobox', { name: 'Workspace', exact: true });
  217 |   await tap(page, info, input);
  218 |   const list = page.getByRole('listbox');
  219 |   await expect(list).toBeVisible();
  220 |   expect(await list.evaluate((el) => !!el.closest('[role="dialog"]'))).toBe(true);
  221 |   await page.keyboard.press('Escape');
  222 |   await expect(list).not.toBeVisible();
  223 |   await expect(dialog).toBeVisible();
  224 |   await expect(input).toBeFocused();
  225 |   await tap(page, info, dialog.getByRole('combobox', { name: 'Expires', exact: true }));
  226 |   await page.keyboard.press('Escape');
  227 |   await expect(dialog).toBeVisible();
  228 |   const actions = dialog.getByRole('button', { name: 'Session actions', exact: true });
  229 |   await tap(page, info, actions);
  230 |   await page.keyboard.press('Escape');
  231 |   await expect(dialog).toBeVisible();
  232 |   await expect(actions).toBeFocused();
  233 |   for (const key of ['Tab', 'Shift+Tab']) for (let i = 0; i < 12; i++) {
  234 |     await page.keyboard.press(key);
  235 |     await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  236 |   }
  237 |   expect(await page.evaluate(() => [document.body, document.documentElement].some((el) => /hidden|clip/.test(getComputedStyle(el).overflowY)))).toBe(true);
  238 |   await shot(info, 'choices-in-dialog', dialog);
  239 |   await page.keyboard.press('Escape');
  240 |   await expect(dialog).not.toBeVisible();
  241 |   await expect(trigger).toBeFocused();
  242 |   await attach(info, 'nested-choices', { legacy, topLayerOnly: true, portalInsideOwner: true, tabBothDirections: true, scrollLocked: true, returned: true });
  243 | });
  244 | 
  245 | test('popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover', async ({ page }, info) => {
  246 |   const trigger = page.getByRole('button', { name: 'Open context', exact: true });
  247 |   await tap(page, info, trigger);
  248 |   const popover = page.getByRole('dialog', { name: 'Context', exact: true });
  249 |   await expect(popover).toBeVisible();
  250 |   const select = popover.getByRole('combobox', { name: 'Context expiry', exact: true });
  251 |   await select.click();
  252 |   await page.keyboard.press('Escape');
  253 |   await expect(popover).toBeVisible();
  254 |   await expect(select).toBeFocused();
  255 |   await page.keyboard.press('Escape');
  256 |   await expect(popover).not.toBeVisible();
  257 |   await expect(trigger).toBeFocused();
  258 |   const usage = page.getByRole('button', { name: 'Account usage', exact: true });
  259 |   await usage.focus();
  260 |   const tooltip = page.getByRole('tooltip');
  261 |   await expect(tooltip).toHaveText('Usage from this account');
  262 |   await expect(usage).toHaveAttribute('aria-describedby', /.+/);
  263 |   await page.keyboard.press('Escape');
  264 |   await expect(tooltip).not.toBeVisible();
  265 |   await usage.blur();
  266 |   await usage.hover();
  267 |   await expect(tooltip).toBeVisible();
  268 |   await page.mouse.move(0, 0);
  269 |   await expect(tooltip).not.toBeVisible();
  270 |   await tap(page, info, trigger);
  271 |   await outside(page, info);
  272 |   await expect(popover).not.toBeVisible();
  273 |   await attach(info, 'popover-tooltip', { nestedSelect: true, sequentialEscape: true, focusReturn: true, tooltipFocusHoverEscape: true });
  274 | });
  275 | 
```