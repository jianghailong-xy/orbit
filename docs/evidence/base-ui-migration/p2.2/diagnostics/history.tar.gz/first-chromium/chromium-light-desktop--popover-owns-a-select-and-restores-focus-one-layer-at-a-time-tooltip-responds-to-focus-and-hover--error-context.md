# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover
- Location: ui-migration/choices.browser.mjs:245:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('tooltip')
Expected: "Usage from this account"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" getByRole('tooltip') with timeout 15000ms
  - waiting for getByRole('tooltip')

```

```yaml
- main:
  - status: light
  - button "Switch theme"
  - button "Open Dialog"
  - button "Open legacy Modal"
  - region "Standalone choices":
    - combobox "Expires": Never
    - button "Clear selection"
    - combobox "Workspace"
    - button "Show options"
    - button "Clear selection"
    - combobox "Disabled select" [disabled]: Never
    - combobox "Disabled search" [disabled]
    - button "Show options" [disabled]
    - combobox "Empty select": No accounts
    - combobox "Automatic account": Automatic
    - button "Session actions"
    - button "Add attachment"
    - button "Open context"
    - button "Account usage"
    - button "Unavailable action" [disabled]
    - button "After choices"
    - status "Expiry value": never
    - status "Workspace value": orbit
    - status "Action": none
    - status "Tag": "false"
    - combobox "Add prerequisite"
    - button "Show options"
    - status "Prerequisite": none
- text: Usage from this account
```

# Test source

```ts
  161 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  162 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  163 |   await input.click();
  164 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  165 |   await input.fill('docs');
  166 |   await expect(page.getByRole('option')).toHaveCount(1);
  167 |   await page.keyboard.press('Enter');
  168 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('docs');
  169 |   await expect(input).toBeFocused();
  170 |   await input.fill('missing');
  171 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  172 |   await page.keyboard.press('Escape');
  173 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('docs');
  174 |   await input.click();
  175 |   await input.dispatchEvent('compositionstart');
  176 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  177 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  178 |   await expect(input).toHaveAttribute('aria-expanded', 'true');
  179 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('docs');
  180 |   await input.dispatchEvent('compositionend', { data: '文档' });
  181 |   await input.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  182 |   await input.fill('文档');
  183 |   await expect(page.getByRole('option')).toHaveCount(1);
  184 |   await page.keyboard.press('Enter');
  185 |   await page.getByRole('button', { name: 'Clear selection' }).nth(1).click();
  186 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  187 |   await expect(input).toBeFocused();
  188 |   await attach(info, 'search', { grouping: true, chinese: true, syntheticCompositionIgnored: true, escapePreservesValue: true, explicitClear: true });
  189 | });
  190 | 
  191 | test('remote search accepts server labels and resets an action picker without local filtering', async ({ page }, info) => {
  192 |   let release;
  193 |   const gate = new Promise((resolve) => { release = resolve; });
  194 |   await page.route('**/__choices-search?*', async (route) => {
  195 |     await gate;
  196 |     await route.fulfill({ json: [{ value: 'task-1', label: 'Server ranked result' }] });
  197 |   });
  198 |   const input = page.getByRole('combobox', { name: 'Add prerequisite', exact: true });
  199 |   await input.fill('query');
  200 |   await expect(input).toHaveAttribute('aria-busy', 'true');
  201 |   release();
  202 |   const option = page.getByRole('option', { name: 'Server ranked result', exact: true });
  203 |   await expect(option).toBeVisible();
  204 |   await option.click();
  205 |   await expect(page.getByRole('status', { name: 'Prerequisite', exact: true })).toHaveText('task-1');
  206 |   await expect(input).toHaveValue('');
  207 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  208 |   await attach(info, 'remote-search', { loadingExposed: true, filterDisabled: true, valueNullResetsQuery: true });
  209 | });
  210 | 
  211 | for (const legacy of [false, true]) test(`${legacy ? 'legacy Modal' : 'Dialog'} owns choices, top-layer Escape, Tab and theme`, async ({ page }, info) => {
  212 |   const trigger = page.getByRole('button', { name: legacy ? 'Open legacy Modal' : 'Open Dialog', exact: true });
  213 |   await tap(page, info, trigger);
  214 |   const dialog = page.getByRole('dialog', { name: legacy ? 'Legacy share' : 'Share workspace', exact: true });
  215 |   await settle(dialog);
  216 |   const input = dialog.getByRole('combobox', { name: 'Workspace', exact: true });
  217 |   await tap(page, info, input);
  218 |   const list = page.getByRole('listbox');
  219 |   await expect(list).toBeVisible();
  220 |   expect(await list.evaluate((el) => !!el.closest('[role="dialog"]'))).toBe(true);
  221 |   await page.keyboard.press('Escape');
  222 |   await expect(list).not.toBeVisible();
  223 |   await expect(dialog).toBeVisible();
  224 |   await expect(input).toBeFocused();
  225 |   await tap(page, info, dialog.getByRole('combobox', { name: 'Expires', exact: true }));
  226 |   await page.keyboard.press('Escape');
  227 |   await expect(dialog).toBeVisible();
  228 |   const actions = dialog.getByRole('button', { name: 'Session actions', exact: true });
  229 |   await tap(page, info, actions);
  230 |   await page.keyboard.press('Escape');
  231 |   await expect(dialog).toBeVisible();
  232 |   await expect(actions).toBeFocused();
  233 |   for (const key of ['Tab', 'Shift+Tab']) for (let i = 0; i < 12; i++) {
  234 |     await page.keyboard.press(key);
  235 |     await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  236 |   }
  237 |   expect(await page.evaluate(() => [document.body, document.documentElement].some((el) => /hidden|clip/.test(getComputedStyle(el).overflowY)))).toBe(true);
  238 |   await shot(info, 'choices-in-dialog', dialog);
  239 |   await page.keyboard.press('Escape');
  240 |   await expect(dialog).not.toBeVisible();
  241 |   await expect(trigger).toBeFocused();
  242 |   await attach(info, 'nested-choices', { legacy, topLayerOnly: true, portalInsideOwner: true, tabBothDirections: true, scrollLocked: true, returned: true });
  243 | });
  244 | 
  245 | test('popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover', async ({ page }, info) => {
  246 |   const trigger = page.getByRole('button', { name: 'Open context', exact: true });
  247 |   await tap(page, info, trigger);
  248 |   const popover = page.getByRole('dialog', { name: 'Context', exact: true });
  249 |   await expect(popover).toBeVisible();
  250 |   const select = popover.getByRole('combobox', { name: 'Context expiry', exact: true });
  251 |   await select.click();
  252 |   await page.keyboard.press('Escape');
  253 |   await expect(popover).toBeVisible();
  254 |   await expect(select).toBeFocused();
  255 |   await page.keyboard.press('Escape');
  256 |   await expect(popover).not.toBeVisible();
  257 |   await expect(trigger).toBeFocused();
  258 |   const usage = page.getByRole('button', { name: 'Account usage', exact: true });
  259 |   await usage.focus();
  260 |   const tooltip = page.getByRole('tooltip');
> 261 |   await expect(tooltip).toHaveText('Usage from this account');
      |                         ^ Error: expect(locator).toHaveText(expected) failed
  262 |   await expect(usage).toHaveAttribute('aria-describedby', /.+/);
  263 |   await page.keyboard.press('Escape');
  264 |   await expect(tooltip).not.toBeVisible();
  265 |   await usage.blur();
  266 |   await usage.hover();
  267 |   await expect(tooltip).toBeVisible();
  268 |   await page.mouse.move(0, 0);
  269 |   await expect(tooltip).not.toBeVisible();
  270 |   await tap(page, info, trigger);
  271 |   await outside(page, info);
  272 |   await expect(popover).not.toBeVisible();
  273 |   await attach(info, 'popover-tooltip', { nestedSelect: true, sequentialEscape: true, focusReturn: true, tooltipFocusHoverEscape: true });
  274 | });
  275 | 
```