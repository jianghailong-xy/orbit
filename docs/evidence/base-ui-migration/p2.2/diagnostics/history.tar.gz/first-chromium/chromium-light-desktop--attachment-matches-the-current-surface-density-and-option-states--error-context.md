# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> attachment matches the current surface, density and option states
- Location: ui-migration/choices.browser.mjs:43:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 17
+ Received  + 17

@@ -10,17 +10,17 @@
          "boxShadow": "none",
          "color": "rgb(31, 35, 41)",
          "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
          "fontSize": "14px",
          "fontWeight": "400",
-         "height": 31.577713012695312,
+         "height": 32,
          "label": "File",
          "lineHeight": "22px",
          "padding": "5px 12px",
-         "width": 122.0625,
+         "width": 122,
          "x": 4,
-         "y": 3.9472198486328125,
+         "y": 4,
        },
        Object {
          "backgroundColor": "rgba(0, 0, 0, 0)",
          "borderColor": "rgb(31, 35, 41)",
          "borderRadius": "4px",
@@ -29,17 +29,17 @@
          "boxShadow": "none",
          "color": "rgb(31, 35, 41)",
          "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
          "fontSize": "14px",
          "fontWeight": "400",
-         "height": 31.577728271484375,
+         "height": 32,
          "label": "Image",
          "lineHeight": "22px",
          "padding": "5px 12px",
-         "width": 122.0625,
+         "width": 122,
          "x": 4,
-         "y": 35.524932861328125,
+         "y": 36,
        },
        Object {
          "backgroundColor": "rgba(0, 0, 0, 0)",
          "borderColor": "rgb(31, 35, 41)",
          "borderRadius": "4px",
@@ -48,17 +48,17 @@
          "boxShadow": "none",
          "color": "rgb(31, 35, 41)",
          "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
          "fontSize": "14px",
          "fontWeight": "400",
-         "height": 31.577728271484375,
+         "height": 32,
          "label": "Shell",
          "lineHeight": "22px",
          "padding": "5px 12px",
-         "width": 122.0625,
+         "width": 122,
          "x": 4,
-         "y": 75.98388671875,
+         "y": 77,
        },
        Object {
          "backgroundColor": "rgba(0, 0, 0, 0)",
          "borderColor": "rgba(0, 0, 0, 0.25)",
          "borderRadius": "4px",
@@ -67,17 +67,17 @@
          "boxShadow": "none",
          "color": "rgba(0, 0, 0, 0.25)",
          "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
          "fontSize": "14px",
          "fontWeight": "400",
-         "height": 31.577728271484375,
+         "height": 32,
          "label": "Skill",
          "lineHeight": "22px",
          "padding": "5px 12px",
-         "width": 122.0625,
+         "width": 122,
          "x": 4,
-         "y": 107.56161499023438,
+         "y": 109,
        },
        Object {
          "backgroundColor": "rgba(0, 0, 0, 0)",
          "borderColor": "rgb(31, 35, 41)",
          "borderRadius": "4px",
@@ -86,17 +86,17 @@
          "boxShadow": "none",
          "color": "rgb(31, 35, 41)",
          "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
          "fontSize": "14px",
          "fontWeight": "400",
-         "height": 31.577728271484375,
+         "height": 32,
          "label": "/Command",
          "lineHeight": "22px",
          "padding": "5px 12px",
-         "width": 122.0625,
+         "width": 122,
          "x": 4,
-         "y": 139.13934326171875,
+         "y": 141,
        },
      ],
      "surface": Object {
        "backgroundColor": "rgb(255, 255, 255)",
        "borderColor": "rgb(31, 35, 41)",
@@ -106,14 +106,14 @@
        "boxShadow": "rgba(0, 0, 0, 0.08) 0px 6px 16px 0px, rgba(0, 0, 0, 0.12) 0px 3px 6px -4px, rgba(0, 0, 0, 0.05) 0px 9px 28px 8px",
        "color": "rgb(31, 35, 41)",
        "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
        "fontSize": "14px",
        "fontWeight": "400",
-       "height": 174.664306640625,
+       "height": 177,
        "lineHeight": "22px",
        "padding": "4px",
-       "width": 130.0625,
+       "width": 130,
        "x": 0,
        "y": 0,
      },
    },
  }
```

# Page snapshot

```yaml
- main [ref=f2e4]:
  - status [ref=f2e5]: light
  - button "Switch theme" [ref=f2e6] [cursor=pointer]
  - region "Appearance sample" [ref=f2e8]:
    - generic [ref=f2e9]:
      - button "Add attachment" [expanded] [ref=f2e11] [cursor=pointer]
      - menu "Add attachment" [active] [ref=f2e16]:
        - menuitem "File" [ref=f2e17] [cursor=pointer]
        - menuitem "Image" [ref=f2e23] [cursor=pointer]
        - separator [ref=f2e29]
        - menuitem "Shell" [ref=f2e30] [cursor=pointer]
        - menuitem "Skill" [disabled] [ref=f2e36]
        - menuitem "Command" [ref=f2e42] [cursor=pointer]:
          - generic [ref=f2e44]: /
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | const fixture = '/ui-migration/choices.html';
  4   | const errors = new WeakMap();
  5   | test.beforeEach(async ({ page }, info) => {
  6   |   errors.set(page, []);
  7   |   page.on('pageerror', (error) => errors.get(page).push(error.message));
  8   |   await page.goto(fixture);
  9   |   await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  10  |   await page.evaluate(() => document.fonts.ready);
  11  | });
  12  | test.afterEach(async ({ page }) => { expect(errors.get(page)).toEqual([]); });
  13  | const attach = (info, name, value) => info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  14  | const shot = (info, name, locator) => locator.screenshot({ animations: 'disabled' }).then((body) => info.attach(name, { body, contentType: 'image/png' }));
  15  | async function settle(locator) {
  16  |   await expect(locator).toBeVisible();
  17  |   await locator.evaluate(async (el) => {
  18  |     await Promise.all(el.getAnimations({ subtree: true }).filter((a) => a.effect?.getComputedTiming().iterations !== Infinity).map((a) => a.finished.catch(() => {})));
  19  |     await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  20  |   });
  21  | }
  22  | async function tap(page, info, locator) {
  23  |   if (info.project.use.hasTouch) await locator.tap();
  24  |   else await locator.click();
  25  | }
  26  | async function outside(page, info) {
  27  |   if (info.project.use.hasTouch) await page.touchscreen.tap(3, 60);
  28  |   else await page.mouse.click(3, 60);
  29  | }
  30  | async function measure(locator) {
  31  |   return locator.evaluate((el) => {
  32  |     const root = el.getBoundingClientRect();
  33  |     const metrics = (node) => {
  34  |       const r = node.getBoundingClientRect(), s = getComputedStyle(node);
  35  |       const keys = ['fontFamily', 'fontSize', 'lineHeight', 'fontWeight', 'color', 'backgroundColor', 'borderRadius', 'borderColor', 'borderWidth', 'borderStyle', 'padding', 'boxShadow'];
  36  |       return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, ...Object.fromEntries(keys.map((key) => [key, s[key]])) };
  37  |     };
  38  |     return { surface: metrics(el), rows: [...el.querySelectorAll('[role="menuitem"], [role="option"]')].map((row) => ({ label: row.textContent, ...metrics(row) })) };
  39  |   });
  40  | }
  41  | 
  42  | for (const kind of ['attachment', 'access', 'expiry', 'account', 'search', 'popover', 'tooltip']) {
  43  |   test(`${kind} matches the current surface, density and option states`, async ({ page }, info) => {
  44  |     const measurements = {};
  45  |     for (const system of ['antd', 'orbit']) {
  46  |       await page.goto(`${fixture}?sample=${kind}&system=${system}`);
  47  |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  48  |       const region = page.getByRole('region', { name: 'Appearance sample' });
  49  |       const choice = region.getByRole('combobox');
  50  |       if (['expiry', 'account', 'search'].includes(kind)) {
  51  |         await page.mouse.move(0, 0);
  52  |         await page.getByTestId('neutral').focus();
  53  |         measurements[system] = { control: await measure(page.locator('.sample-choice')) };
  54  |         await shot(info, `${system}-${kind}-closed`, page.locator('.sample-choice'));
  55  |         await choice.click();
  56  |       } else if (kind === 'tooltip') await region.getByRole('button').hover();
  57  |       else await region.getByRole('button').click();
  58  |       const surface = page.locator('.sample-surface:visible');
  59  |       await settle(surface);
  60  |       if (kind !== 'tooltip') await page.mouse.move(0, 0);
  61  |       await settle(surface);
  62  |       measurements[system] = { ...measurements[system], popup: await measure(surface) };
  63  |       await shot(info, `${system}-${kind}-open`, surface);
  64  |     }
  65  |     await attach(info, 'appearance', measurements);
> 66  |     expect(measurements.orbit).toEqual(measurements.antd);
      |                                ^ Error: expect(received).toEqual(expected) // deep equality
  67  |   });
  68  | }
  69  | 
  70  | test('menu arrows, disabled items, submenu, checkbox and focus return work', async ({ page }, info) => {
  71  |   const trigger = page.getByRole('button', { name: 'Session actions', exact: true });
  72  |   await trigger.focus();
  73  |   await page.keyboard.press('ArrowDown');
  74  |   const first = page.getByRole('menuitem', { name: 'Default model', exact: true });
  75  |   await expect(first).toBeFocused();
  76  |   await page.keyboard.press('ArrowDown');
  77  |   const provider = page.getByRole('menuitem', { name: 'Provider', exact: true });
  78  |   await expect(provider).toBeFocused();
  79  |   await page.keyboard.press('ArrowRight');
  80  |   await expect(page.getByRole('menuitem', { name: 'Codex', exact: true })).toBeFocused();
  81  |   await page.keyboard.press('Escape');
  82  |   await expect(provider).toBeFocused();
  83  |   await expect(page.getByRole('menu')).toHaveCount(1);
  84  |   await page.keyboard.press('ArrowRight');
  85  |   await page.keyboard.press('ArrowDown');
  86  |   await page.keyboard.press('Enter');
  87  |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('claude');
  88  |   await expect(trigger).toBeFocused();
  89  |   await trigger.click();
  90  |   const tag = page.getByRole('menuitemcheckbox', { name: 'Important tag' });
  91  |   await tag.click();
  92  |   await expect(tag).toHaveAttribute('aria-checked', 'true');
  93  |   await expect(page.getByRole('status', { name: 'Tag', exact: true })).toHaveText('true');
  94  |   await tag.press('Space');
  95  |   await expect(tag).toHaveAttribute('aria-checked', 'false');
  96  |   await page.keyboard.press('Escape');
  97  |   await expect(trigger).toBeFocused();
  98  |   await attach(info, 'keyboard-menu', { disabledSkipped: true, submenuOnlyEscape: true, selection: 'claude', checkboxStaysOpen: true, focusReturned: true });
  99  | });
  100 | 
  101 | test('touch or pointer menus dismiss outside, fit viewport and open a dialog with stable return focus', async ({ page }, info) => {
  102 |   const trigger = page.getByRole('button', { name: 'Add attachment', exact: true });
  103 |   await tap(page, info, trigger);
  104 |   const menu = page.getByRole('menu');
  105 |   const box = await menu.boundingBox();
  106 |   expect(box.x).toBeGreaterThanOrEqual(0);
  107 |   expect(box.x + box.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  108 |   await tap(page, info, page.getByRole('menuitem', { name: 'Image', exact: true }));
  109 |   await expect(menu).not.toBeVisible();
  110 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('image');
  111 |   await tap(page, info, trigger);
  112 |   await outside(page, info);
  113 |   await expect(menu).not.toBeVisible();
  114 |   const actions = page.getByRole('button', { name: 'Session actions', exact: true });
  115 |   await tap(page, info, actions);
  116 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  117 |   const sub = page.getByRole('menu').filter({ has: page.getByRole('menuitem', { name: 'Codex', exact: true }) });
  118 |   await expect(sub).toBeVisible();
  119 |   const subBox = await sub.boundingBox();
  120 |   expect(subBox.x).toBeGreaterThanOrEqual(0);
  121 |   expect(subBox.x + subBox.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  122 |   await page.keyboard.press('Escape');
  123 |   await tap(page, info, page.getByRole('menuitem', { name: 'Edit details', exact: true }));
  124 |   const dialog = page.getByRole('dialog', { name: 'Edit details', exact: true });
  125 |   await expect(dialog).toBeVisible();
  126 |   await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  127 |   await page.keyboard.press('Escape');
  128 |   await expect(actions).toBeFocused();
  129 |   await attach(info, 'pointer-menu', { input: info.project.use.hasTouch ? 'touch' : 'mouse', outside: true, menuBounds: box, submenuBounds: subBox, dialogReturn: true });
  130 | });
  131 | 
  132 | test('select supports arrows, Enter, clear, empty, disabled and empty-string account values', async ({ page }, info) => {
  133 |   const select = page.getByRole('combobox', { name: 'Expires', exact: true });
  134 |   await select.focus();
  135 |   await page.keyboard.press('ArrowDown');
  136 |   await page.keyboard.press('ArrowDown');
  137 |   await page.keyboard.press('Enter');
  138 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('7');
  139 |   await expect(select).toBeFocused();
  140 |   await select.click();
  141 |   await expect(page.getByRole('option', { name: '7 days', exact: true })).toHaveAttribute('aria-selected', 'true');
  142 |   await expect(page.getByRole('option', { name: '30 days', exact: true })).toHaveAttribute('aria-disabled', 'true');
  143 |   await page.keyboard.press('Escape');
  144 |   await page.getByRole('button', { name: 'Clear selection' }).first().click();
  145 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('null');
  146 |   await expect(select).toBeFocused();
  147 |   await expect(page.getByRole('combobox', { name: 'Disabled select', exact: true })).toBeDisabled();
  148 |   await expect(page.getByRole('combobox', { name: 'Disabled search', exact: true })).toBeDisabled();
  149 |   await page.getByRole('combobox', { name: 'Empty select', exact: true }).click();
  150 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  151 |   await page.keyboard.press('Escape');
  152 |   const automatic = page.getByRole('combobox', { name: 'Automatic account', exact: true });
  153 |   await expect(automatic).toContainText('Automatic');
  154 |   await automatic.click();
  155 |   await expect(page.getByRole('option', { name: /Automatic/ })).toHaveAttribute('aria-selected', 'true');
  156 |   await outside(page, info);
  157 |   await expect(automatic).toHaveAttribute('aria-expanded', 'false');
  158 |   await attach(info, 'select', { selected: '7', cleared: true, disabled: true, empty: true, emptyStringIsSelection: true });
  159 | });
  160 | 
  161 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  162 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  163 |   await input.click();
  164 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  165 |   await input.fill('docs');
  166 |   await expect(page.getByRole('option')).toHaveCount(1);
```