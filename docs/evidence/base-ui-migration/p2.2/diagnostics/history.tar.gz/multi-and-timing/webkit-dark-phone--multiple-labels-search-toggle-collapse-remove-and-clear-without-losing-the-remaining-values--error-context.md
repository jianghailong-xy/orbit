# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> multiple labels search, toggle, collapse, remove and clear without losing the remaining values
- Location: ui-migration/choices.browser.mjs:511:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  getByRole('region', { name: 'Multiple choices', exact: true }).locator('output[aria-label="Labels value"]')
Expected: "[\"bug\",\"docs\",\"ops\"]"
Received: "[\"bug\",\"docs\"]"
Timeout:  15000ms

Call log:
  - Expect "toHaveText" getByRole('region', { name: 'Multiple choices', exact: true }).locator('output[aria-label="Labels value"]') with timeout 15000ms
  - waiting for getByRole('region', { name: 'Multiple choices', exact: true }).locator('output[aria-label="Labels value"]')
    34 × locator resolved to <output aria-hidden="true" aria-label="Labels value">["bug","docs"]</output>
       - unexpected value "["bug","docs"]"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main [ref=e4]:
    - status [aria-hidden] [ref=e5]: dark
    - button [aria-hidden] [ref=e6] [cursor=pointer]:
      - generic [ref=e7]: Switch theme
    - button [aria-hidden] [ref=e8] [cursor=pointer]:
      - generic [ref=e9]: Open Dialog
    - button [aria-hidden] [ref=e10] [cursor=pointer]:
      - generic [ref=e11]: Open legacy Modal
    - region [aria-hidden] [ref=e12]:
      - generic [ref=e13]:
        - generic [ref=e14]:
          - combobox [ref=e15] [cursor=pointer]:
            - generic [ref=e16]: Never
          - button [ref=e20] [cursor=pointer]
        - textbox [aria-hidden] [ref=e24]: never
        - generic [ref=e25]:
          - generic: Orbit workspace
          - combobox [ref=e26]
          - button [ref=e27] [cursor=pointer]
          - button [ref=e31] [cursor=pointer]
        - textbox [aria-hidden] [ref=e35]: orbit
        - combobox [disabled] [ref=e37]:
          - generic [ref=e38]: Never
        - textbox [disabled] [aria-hidden] [ref=e42]: never
        - generic [ref=e43]:
          - generic: Never
          - combobox [disabled] [ref=e44]
          - button [disabled] [ref=e45] [cursor=pointer]
        - textbox [disabled] [aria-hidden] [ref=e49]: never
        - combobox [ref=e51] [cursor=pointer]:
          - generic [ref=e52]: No accounts
        - textbox [aria-hidden] [ref=e56]
        - combobox [ref=e58] [cursor=pointer]:
          - generic [ref=e59]: Automatic
        - textbox [aria-hidden] [ref=e63]
        - button [ref=e64] [cursor=pointer]:
          - generic [ref=e65]: Session actions
        - button [ref=e66] [cursor=pointer]:
          - generic [ref=e67]: Add attachment
        - button [ref=e68] [cursor=pointer]:
          - generic [ref=e69]: Open context
        - button [ref=e70] [cursor=pointer]:
          - generic [ref=e71]: Account usage
        - button [disabled] [ref=e73]:
          - generic [ref=e74]: Unavailable action
        - button [ref=e75] [cursor=pointer]:
          - generic [ref=e76]: After choices
        - status [ref=e77]: never
        - status [ref=e78]: orbit
        - status [ref=e79]: none
        - status [ref=e80]: "false"
      - generic [ref=e81]:
        - combobox [ref=e82]
        - button [ref=e83] [cursor=pointer]
      - textbox [aria-hidden] [ref=e87]
      - status [ref=e88]: none
    - region "Multiple choices" [ref=e89]:
      - generic [ref=e90]:
        - generic [ref=e91]:
          - toolbar [ref=e92]:
            - generic [aria-hidden] [ref=e93]:
              - generic [ref=e94]: Bug
              - button [ref=e95] [cursor=pointer]
            - generic [ref=e99]:
              - generic [ref=e100]: Docs
              - button "Remove Docs" [ref=e101] [cursor=pointer]
            - generic [ref=e105]:
              - button "Dismiss" [ref=e106]
              - combobox "Labels" [expanded] [active] [ref=e107]
          - button [expanded] [aria-hidden] [ref=e108] [cursor=pointer]
          - button [aria-hidden] [ref=e112] [cursor=pointer]
        - textbox [aria-hidden] [ref=e116]
        - generic [aria-hidden] [ref=e117]:
          - toolbar [ref=e118]:
            - generic [ref=e119]: Bug
            - combobox [disabled] [ref=e122]
          - button [disabled] [ref=e123] [cursor=pointer]
        - textbox [disabled] [aria-hidden] [ref=e127]
        - generic [aria-hidden] [ref=e128]:
          - toolbar [ref=e129]:
            - generic [ref=e130]:
              - generic [ref=e131]: owner@orbit.test
              - button [ref=e132] [cursor=pointer]
            - combobox [ref=e137]
          - button [ref=e138] [cursor=pointer]
          - button [ref=e142] [cursor=pointer]
        - textbox [aria-hidden] [ref=e146]
        - button [aria-hidden] [ref=e147] [cursor=pointer]:
          - generic [ref=e148]: After tags
        - status [aria-hidden] [ref=e149]: "[\"bug\",\"docs\"]"
        - status [aria-hidden] [ref=e150]: "[\"owner@orbit.test\"]"
      - button [aria-hidden] [ref=e151] [cursor=pointer]:
        - generic [ref=e152]: Open multi Dialog
      - group [aria-hidden] [ref=e153]:
        - button [ref=e154] [cursor=pointer]:
          - generic [ref=e155]: Open row
        - button [ref=e156] [cursor=pointer]:
          - generic [ref=e157]: Row actions
      - status [aria-hidden] [ref=e158]: "0"
      - status [aria-hidden] [ref=e159]: "0"
  - generic:
    - generic [ref=e160]:
      - status
      - listbox [ref=e161]:
        - option "Bug" [selected] [ref=e162] [cursor=pointer]
        - option "Docs" [selected] [ref=e168] [cursor=pointer]
        - option "Ops" [ref=e174] [cursor=pointer]
        - option "Archived" [disabled] [ref=e176]
    - button "Dismiss" [ref=e178]
```

# Test source

```ts
  422 |   await page.mouse.move(0, 0);
  423 |   await expect(tooltip).not.toBeVisible();
  424 |   await tap(page, info, trigger);
  425 |   await outside(page, info);
  426 |   await expect(popover).not.toBeVisible();
  427 |   await attach(info, 'popover-tooltip', { nestedSelect: true, sequentialEscape: true, focusReturn: true, tooltipFocusHoverEscape: true });
  428 | });
  429 | 
  430 | 
  431 | test('open choices follow the live system theme without losing selection', async ({ page }, info) => {
  432 |   const select = page.getByRole('combobox', { name: 'Expires', exact: true });
  433 |   await select.click();
  434 |   const popup = page.getByRole('listbox');
  435 |   await expect(popup).toBeVisible();
  436 |   const colors = {};
  437 |   for (const theme of [info.project.use.colorScheme === 'dark' ? 'light' : 'dark', info.project.use.colorScheme]) {
  438 |     await page.emulateMedia({ colorScheme: theme });
  439 |     await expect(page.getByTestId('theme')).toHaveText(theme);
  440 |     await expect(popup).toBeVisible();
  441 |     const option = page.getByRole('option', { name: 'Never', exact: true });
  442 |     await expect(option).toHaveAttribute('aria-selected', 'true');
  443 |     colors[theme] = await option.evaluate((el) => ({ foreground: getComputedStyle(el).color, background: getComputedStyle(el).backgroundColor }));
  444 |     expect(colors[theme].background).toBe(theme === 'dark' ? 'rgb(34, 61, 126)' : 'rgb(214, 232, 255)');
  445 |   }
  446 |   await attach(info, 'live-theme', colors);
  447 | });
  448 | 
  449 | test('Dialog keeps composition, outside dismissal, submenu Escape and keyboard clear within its owner', async ({ page }, info) => {
  450 |   await tap(page, info, page.getByRole('button', { name: 'Open Dialog', exact: true }));
  451 |   const dialog = page.getByRole('dialog', { name: 'Share workspace', exact: true });
  452 |   const input = dialog.getByRole('combobox', { name: 'Workspace', exact: true });
  453 |   await tap(page, info, input);
  454 |   await expect(page.getByRole('listbox')).toBeVisible();
  455 |   await input.dispatchEvent('compositionstart');
  456 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  457 |   await expect(page.getByRole('listbox')).toBeVisible();
  458 |   await expect(dialog).toBeVisible();
  459 |   await input.dispatchEvent('compositionend');
  460 |   await tap(page, info, page.getByRole('heading', { name: 'Share workspace', includeHidden: true }));
  461 |   await expect(page.getByRole('listbox')).not.toBeVisible();
  462 |   await expect(dialog).toBeVisible();
  463 |   const actions = dialog.getByRole('button', { name: 'Session actions', exact: true });
  464 |   await tap(page, info, actions);
  465 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  466 |   await expect(page.getByRole('menu')).toHaveCount(2);
  467 |   await page.keyboard.press('Escape');
  468 |   await expect(page.getByRole('menu')).toHaveCount(1);
  469 |   await expect(dialog).toBeVisible();
  470 |   await page.keyboard.press('Escape');
  471 |   await expect(actions).toBeFocused();
  472 |   await input.focus();
  473 |   await page.keyboard.press('Tab');
  474 |   const clear = dialog.getByRole('button', { name: 'Clear selection' }).nth(1);
  475 |   await expect(clear).toBeFocused();
  476 |   await page.keyboard.press('Enter');
  477 |   await expect(dialog.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  478 |   await expect(input).toBeFocused();
  479 |   await attach(info, 'dialog-boundaries', { compositionIgnored: true, outsideClosesChild: true, submenuEscapesOneLayer: true, keyboardClear: true });
  480 | });
  481 | 
  482 | for (const kind of ['multiple', 'tags']) test(`${kind} chip appearance matches current labels and email fields`, async ({ page }, info) => {
  483 |   const all = {};
  484 |   for (const state of ['default', 'disabled']) {
  485 |     const values = {};
  486 |     for (const system of ['antd', 'orbit']) {
  487 |       await page.goto(`${fixture}?sample=${kind}&system=${system}&state=${state}`);
  488 |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  489 |       const control = page.locator('.sample-choice');
  490 |       await page.mouse.move(0, 0);
  491 |       await page.getByTestId('neutral').focus();
  492 |       await settle(control);
  493 |       values[system] = { control: await measure(control, true) };
  494 |       await shot(info, `${system}-${kind}-${state}`, control);
  495 |       if (state === 'disabled') await expect(control.getByRole('combobox')).toBeDisabled();
  496 |       if (state === 'default' && kind === 'multiple') {
  497 |         await control.getByRole('combobox').click();
  498 |         const surface = page.locator('.sample-surface:visible');
  499 |         await settle(surface);
  500 |         await page.mouse.move(0, 0);
  501 |         values[system].popup = await measure(surface);
  502 |         await shot(info, `${system}-multiple-options`, surface);
  503 |       }
  504 |     }
  505 |     all[state] = values;
  506 |   }
  507 |   await attach(info, 'multi-appearance', all);
  508 |   for (const values of Object.values(all)) expect(values.orbit).toEqual(values.antd);
  509 | });
  510 | 
  511 | test('multiple labels search, toggle, collapse, remove and clear without losing the remaining values', async ({ page }, info) => {
  512 |   const region = page.getByRole('region', { name: 'Multiple choices', exact: true });
  513 |   const input = region.getByRole('combobox', { name: 'Labels', exact: true });
  514 |   const value = region.locator('output[aria-label="Labels value"]');
  515 |   await input.fill('docs');
  516 |   await expect(page.getByRole('option', { name: 'Docs', exact: true })).toBeVisible();
  517 |   await page.keyboard.press('Enter');
  518 |   await expect(value).toHaveText('["bug","docs"]');
  519 |   await expect(page.getByRole('listbox')).toBeVisible();
  520 |   await expect(page.getByRole('option', { name: 'Docs', exact: true })).toHaveAttribute('aria-selected', 'true');
  521 |   await tap(page, info, page.getByRole('option', { name: 'Ops', exact: true }));
> 522 |   await expect(value).toHaveText('["bug","docs","ops"]');
      |                       ^ Error: expect(locator).toHaveText(expected) failed
  523 |   await expect(region.getByLabel('1 more selected', { exact: true })).toBeVisible();
  524 |   await expect(page.getByRole('option', { name: 'Archived', exact: true })).toHaveAttribute('aria-disabled', 'true');
  525 |   await input.focus();
  526 |   await page.keyboard.press('Backspace');
  527 |   await expect(value).toHaveText('["bug","docs"]');
  528 |   await page.keyboard.press('Escape');
  529 |   await expect(input).toBeFocused();
  530 |   await region.getByRole('button', { name: 'Remove Bug', exact: true }).click();
  531 |   await expect(value).toHaveText('["docs"]');
  532 |   await expect(input).toBeFocused();
  533 |   await input.click();
  534 |   await page.getByRole('option', { name: 'Docs', exact: true }).click();
  535 |   await expect(value).toHaveText('[]');
  536 |   await page.getByRole('option', { name: 'Bug', exact: true }).click();
  537 |   await page.keyboard.press('Escape');
  538 |   await input.focus();
  539 |   await page.keyboard.press('Tab');
  540 |   await expect(region.getByRole('button', { name: 'Clear selection' }).first()).toBeFocused();
  541 |   await page.keyboard.press('Enter');
  542 |   await expect(value).toHaveText('[]');
  543 |   await expect(input).toBeFocused();
  544 |   await expect(region.getByRole('combobox', { name: 'Disabled labels', exact: true })).toBeDisabled();
  545 |   await attach(info, 'multiple-labels', { search: true, toggle: true, staysOpen: true, collapsedCount: true, removesHiddenLastValue: true, removeFocus: true, keyboardClear: true });
  546 | });
  547 | 
  548 | test('email tags support controlled typing, separators, composition, Enter, blur and deletion', async ({ page }, info) => {
  549 |   const region = page.getByRole('region', { name: 'Multiple choices', exact: true });
  550 |   const input = region.getByRole('combobox', { name: 'People to add', exact: true });
  551 |   const value = region.getByRole('status', { name: 'People value', exact: true });
  552 |   const query = region.getByRole('status', { name: 'People query', exact: true });
  553 |   await input.fill('first@orbit.test, second@orbit.test ');
  554 |   await expect(value).toHaveText('["owner@orbit.test","first@orbit.test","second@orbit.test"]');
  555 |   await expect(query).toHaveText('');
  556 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  557 |   await input.fill('draft@orbit.test');
  558 |   await expect(query).toHaveText('draft@orbit.test');
  559 |   await page.keyboard.press('Enter');
  560 |   await expect(value).toContainText('draft@orbit.test');
  561 |   await input.dispatchEvent('compositionstart');
  562 |   await input.fill('中文@orbit.test');
  563 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  564 |   await expect(value).not.toContainText('中文@orbit.test');
  565 |   await input.dispatchEvent('compositionend');
  566 |   await page.keyboard.press('Enter');
  567 |   await expect(value).toContainText('中文@orbit.test');
  568 |   await input.fill('blur@orbit.test');
  569 |   await region.getByRole('button', { name: 'After tags' }).click();
  570 |   await expect(value).toContainText('blur@orbit.test');
  571 |   await expect(query).toHaveText('');
  572 |   await input.focus();
  573 |   await page.keyboard.press('Backspace');
  574 |   await expect(value).not.toContainText('blur@orbit.test');
  575 |   await region.getByRole('button', { name: 'Remove first@orbit.test', exact: true }).click();
  576 |   await expect(value).not.toContainText('first@orbit.test');
  577 |   await expect(input).toBeFocused();
  578 |   await input.fill('owner@orbit.test ');
  579 |   const emails = JSON.parse(await value.textContent());
  580 |   expect(emails.filter((email) => email === 'owner@orbit.test')).toHaveLength(1);
  581 |   await input.focus();
  582 |   await page.keyboard.press('Tab');
  583 |   await page.keyboard.press('Enter');
  584 |   await expect(value).toHaveText('[]');
  585 |   await attach(info, 'email-tags', { controlledQuery: true, commaSpace: true, enter: true, blurCommits: true, syntheticComposition: true, backspace: true, remove: true, deduplicated: true, keyboardClear: true });
  586 | });
  587 | 
  588 | test('multiple choices in Dialog keep their owner and menus do not activate a clickable row', async ({ page }, info) => {
  589 |   const trigger = page.getByRole('button', { name: 'Open multi Dialog', exact: true });
  590 |   await tap(page, info, trigger);
  591 |   const dialog = page.getByRole('dialog', { name: 'Multiple choices', exact: true });
  592 |   const input = dialog.getByRole('combobox', { name: 'Labels', exact: true });
  593 |   await tap(page, info, input);
  594 |   const list = page.getByRole('listbox');
  595 |   await expect(list).toBeVisible();
  596 |   expect(await list.evaluate((el) => !!el.closest('[role="dialog"]'))).toBe(true);
  597 |   await tap(page, info, page.getByRole('option', { name: 'Docs', exact: true }));
  598 |   await expect(dialog).toBeVisible();
  599 |   await page.keyboard.press('Escape');
  600 |   await expect(list).not.toBeVisible();
  601 |   await expect(input).toBeFocused();
  602 |   const tags = dialog.getByRole('combobox', { name: 'People to add', exact: true });
  603 |   await tags.focus();
  604 |   await tags.dispatchEvent('compositionstart');
  605 |   await tags.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  606 |   await expect(dialog).toBeVisible();
  607 |   await tags.dispatchEvent('compositionend');
  608 |   await tags.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  609 |   await page.keyboard.press('Escape');
  610 |   await expect(trigger).toBeFocused();
  611 |   const menu = page.getByRole('button', { name: 'Row actions', exact: true });
  612 |   await tap(page, info, menu);
  613 |   await tap(page, info, page.getByRole('menuitem', { name: 'Run action', exact: true }));
  614 |   await expect(page.getByRole('status', { name: 'Row actions', exact: true })).toHaveText('1');
  615 |   await expect(page.getByRole('status', { name: 'Row clicks', exact: true })).toHaveText('0');
  616 |   await menu.focus();
  617 |   await page.keyboard.press('ArrowDown');
  618 |   await page.keyboard.press('Enter');
  619 |   await expect(page.getByRole('status', { name: 'Row actions', exact: true })).toHaveText('2');
  620 |   await expect(page.getByRole('status', { name: 'Row clicks', exact: true })).toHaveText('0');
  621 |   await page.getByRole('button', { name: 'Open row', exact: true }).click();
  622 |   await expect(page.getByRole('status', { name: 'Row clicks', exact: true })).toHaveText('1');
```