# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> multiple chip appearance matches current labels and email fields
- Location: ui-migration/choices.browser.mjs:482:42

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 5
+ Received  + 5

@@ -82,11 +82,11 @@
    "popup": Object {
      "rows": Array [
        Object {
          "backgroundColor": "rgb(214, 232, 255)",
          "borderColor": "rgb(31, 35, 41)",
-         "borderRadius": "4px 4px 0px 0px",
+         "borderRadius": "4px",
          "borderStyle": "none",
          "borderWidth": "0px",
          "boxShadow": "none",
          "color": "rgb(31, 35, 41)",
          "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
@@ -99,13 +99,13 @@
          "width": 242,
          "x": 4,
          "y": 4,
        },
        Object {
-         "backgroundColor": "rgb(240, 247, 255)",
+         "backgroundColor": "rgb(214, 232, 255)",
          "borderColor": "rgb(31, 35, 41)",
-         "borderRadius": "0px",
+         "borderRadius": "4px",
          "borderStyle": "none",
          "borderWidth": "0px",
          "boxShadow": "none",
          "color": "rgb(31, 35, 41)",
          "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
@@ -118,13 +118,13 @@
          "width": 242,
          "x": 4,
          "y": 36,
        },
        Object {
-         "backgroundColor": "rgb(240, 247, 255)",
+         "backgroundColor": "rgb(214, 232, 255)",
          "borderColor": "rgb(31, 35, 41)",
-         "borderRadius": "0px 0px 4px 4px",
+         "borderRadius": "4px",
          "borderStyle": "none",
          "borderWidth": "0px",
          "boxShadow": "none",
          "color": "rgb(31, 35, 41)",
          "fontFamily": "-apple-system, BlinkMacSystemFont, \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif",
```

# Page snapshot

```yaml
- main [ref=f4e4]:
  - status [ref=f4e5]: light
  - button "Switch theme" [ref=f4e6] [cursor=pointer]
  - region "Appearance sample" [ref=f4e8]:
    - generic [active] [ref=f4e9]:
      - generic [ref=f4e10]:
        - toolbar [ref=f4e11]:
          - generic [ref=f4e12]: Bug
          - generic [ref=f4e14]: Docs
          - generic "1 more selected" [ref=f4e16]: + 1 ...
          - combobox "Sample choice" [disabled] [ref=f4e19]
        - button "Show options" [disabled] [ref=f4e20] [cursor=pointer]
      - textbox [disabled] [aria-hidden] [ref=f4e24]
```

# Test source

```ts
  408 |   await expect(popover).not.toBeVisible();
  409 |   await expect(trigger).toBeFocused();
  410 |   await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  411 |   const usage = page.getByRole('button', { name: 'Account usage', exact: true });
  412 |   await page.keyboard.press('Tab');
  413 |   await usage.focus();
  414 |   const tooltip = page.getByRole('tooltip');
  415 |   await expect(tooltip).toHaveText('Usage from this account');
  416 |   await expect(usage).toHaveAttribute('aria-describedby', /.+/);
  417 |   await page.keyboard.press('Escape');
  418 |   await expect(tooltip).not.toBeVisible();
  419 |   await usage.blur();
  420 |   await usage.hover();
  421 |   await expect(tooltip).toBeVisible();
  422 |   await page.mouse.move(0, 0);
  423 |   await expect(tooltip).not.toBeVisible();
  424 |   await tap(page, info, trigger);
  425 |   await outside(page, info);
  426 |   await expect(popover).not.toBeVisible();
  427 |   await attach(info, 'popover-tooltip', { nestedSelect: true, sequentialEscape: true, focusReturn: true, tooltipFocusHoverEscape: true });
  428 | });
  429 | 
  430 | 
  431 | test('open choices follow the live system theme without losing selection', async ({ page }, info) => {
  432 |   const select = page.getByRole('combobox', { name: 'Expires', exact: true });
  433 |   await select.click();
  434 |   const popup = page.getByRole('listbox');
  435 |   await expect(popup).toBeVisible();
  436 |   const colors = {};
  437 |   for (const theme of [info.project.use.colorScheme === 'dark' ? 'light' : 'dark', info.project.use.colorScheme]) {
  438 |     await page.emulateMedia({ colorScheme: theme });
  439 |     await expect(page.getByTestId('theme')).toHaveText(theme);
  440 |     await expect(popup).toBeVisible();
  441 |     const option = page.getByRole('option', { name: 'Never', exact: true });
  442 |     await expect(option).toHaveAttribute('aria-selected', 'true');
  443 |     colors[theme] = await option.evaluate((el) => ({ foreground: getComputedStyle(el).color, background: getComputedStyle(el).backgroundColor }));
  444 |     expect(colors[theme].background).toBe(theme === 'dark' ? 'rgb(34, 61, 126)' : 'rgb(214, 232, 255)');
  445 |   }
  446 |   await attach(info, 'live-theme', colors);
  447 | });
  448 | 
  449 | test('Dialog keeps composition, outside dismissal, submenu Escape and keyboard clear within its owner', async ({ page }, info) => {
  450 |   await tap(page, info, page.getByRole('button', { name: 'Open Dialog', exact: true }));
  451 |   const dialog = page.getByRole('dialog', { name: 'Share workspace', exact: true });
  452 |   const input = dialog.getByRole('combobox', { name: 'Workspace', exact: true });
  453 |   await tap(page, info, input);
  454 |   await expect(page.getByRole('listbox')).toBeVisible();
  455 |   await input.dispatchEvent('compositionstart');
  456 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  457 |   await expect(page.getByRole('listbox')).toBeVisible();
  458 |   await expect(dialog).toBeVisible();
  459 |   await input.dispatchEvent('compositionend');
  460 |   await tap(page, info, page.getByRole('heading', { name: 'Share workspace', includeHidden: true }));
  461 |   await expect(page.getByRole('listbox')).not.toBeVisible();
  462 |   await expect(dialog).toBeVisible();
  463 |   const actions = dialog.getByRole('button', { name: 'Session actions', exact: true });
  464 |   await tap(page, info, actions);
  465 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  466 |   await expect(page.getByRole('menu')).toHaveCount(2);
  467 |   await page.keyboard.press('Escape');
  468 |   await expect(page.getByRole('menu')).toHaveCount(1);
  469 |   await expect(dialog).toBeVisible();
  470 |   await page.keyboard.press('Escape');
  471 |   await expect(actions).toBeFocused();
  472 |   await input.focus();
  473 |   await page.keyboard.press('Tab');
  474 |   const clear = dialog.getByRole('button', { name: 'Clear selection' }).nth(1);
  475 |   await expect(clear).toBeFocused();
  476 |   await page.keyboard.press('Enter');
  477 |   await expect(dialog.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  478 |   await expect(input).toBeFocused();
  479 |   await attach(info, 'dialog-boundaries', { compositionIgnored: true, outsideClosesChild: true, submenuEscapesOneLayer: true, keyboardClear: true });
  480 | });
  481 | 
  482 | for (const kind of ['multiple', 'tags']) test(`${kind} chip appearance matches current labels and email fields`, async ({ page }, info) => {
  483 |   const all = {};
  484 |   for (const state of ['default', 'disabled']) {
  485 |     const values = {};
  486 |     for (const system of ['antd', 'orbit']) {
  487 |       await page.goto(`${fixture}?sample=${kind}&system=${system}&state=${state}`);
  488 |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  489 |       const control = page.locator('.sample-choice');
  490 |       await page.mouse.move(0, 0);
  491 |       await page.getByTestId('neutral').focus();
  492 |       await settle(control);
  493 |       values[system] = { control: await measure(control, true) };
  494 |       await shot(info, `${system}-${kind}-${state}`, control);
  495 |       if (state === 'disabled') await expect(control.getByRole('combobox')).toBeDisabled();
  496 |       if (state === 'default' && kind === 'multiple') {
  497 |         await control.getByRole('combobox').click();
  498 |         const surface = page.locator('.sample-surface:visible');
  499 |         await settle(surface);
  500 |         await page.mouse.move(0, 0);
  501 |         values[system].popup = await measure(surface);
  502 |         await shot(info, `${system}-multiple-options`, surface);
  503 |       }
  504 |     }
  505 |     all[state] = values;
  506 |   }
  507 |   await attach(info, 'multi-appearance', all);
> 508 |   for (const values of Object.values(all)) expect(values.orbit).toEqual(values.antd);
      |                                                                 ^ Error: expect(received).toEqual(expected) // deep equality
  509 | });
  510 | 
  511 | test('multiple labels search, toggle, collapse, remove and clear without losing the remaining values', async ({ page }, info) => {
  512 |   const region = page.getByRole('region', { name: 'Multiple choices', exact: true });
  513 |   const input = region.getByRole('combobox', { name: 'Labels', exact: true });
  514 |   const value = region.getByRole('status', { name: 'Labels value', exact: true });
  515 |   await input.fill('docs');
  516 |   await expect(page.getByRole('option', { name: 'Docs', exact: true })).toBeVisible();
  517 |   await page.keyboard.press('Enter');
  518 |   await expect(value).toHaveText('["bug","docs"]');
  519 |   await expect(page.getByRole('listbox')).toBeVisible();
  520 |   await expect(page.getByRole('option', { name: 'Docs', exact: true })).toHaveAttribute('aria-selected', 'true');
  521 |   await tap(page, info, page.getByRole('option', { name: 'Ops', exact: true }));
  522 |   await expect(value).toHaveText('["bug","docs","ops"]');
  523 |   await expect(region.getByLabel('1 more selected', { exact: true })).toBeVisible();
  524 |   await expect(page.getByRole('option', { name: 'Archived', exact: true })).toHaveAttribute('aria-disabled', 'true');
  525 |   await input.focus();
  526 |   await page.keyboard.press('Backspace');
  527 |   await expect(value).toHaveText('["bug","docs"]');
  528 |   await page.keyboard.press('Escape');
  529 |   await expect(input).toBeFocused();
  530 |   await region.getByRole('button', { name: 'Remove Bug', exact: true }).click();
  531 |   await expect(value).toHaveText('["docs"]');
  532 |   await expect(input).toBeFocused();
  533 |   await input.click();
  534 |   await page.getByRole('option', { name: 'Docs', exact: true }).click();
  535 |   await expect(value).toHaveText('[]');
  536 |   await page.getByRole('option', { name: 'Bug', exact: true }).click();
  537 |   await page.keyboard.press('Escape');
  538 |   await input.focus();
  539 |   await page.keyboard.press('Tab');
  540 |   await expect(region.getByRole('button', { name: 'Clear selection' }).first()).toBeFocused();
  541 |   await page.keyboard.press('Enter');
  542 |   await expect(value).toHaveText('[]');
  543 |   await expect(input).toBeFocused();
  544 |   await expect(region.getByRole('combobox', { name: 'Disabled labels', exact: true })).toBeDisabled();
  545 |   await attach(info, 'multiple-labels', { search: true, toggle: true, staysOpen: true, collapsedCount: true, removesHiddenLastValue: true, removeFocus: true, keyboardClear: true });
  546 | });
  547 | 
  548 | test('email tags support controlled typing, separators, composition, Enter, blur and deletion', async ({ page }, info) => {
  549 |   const region = page.getByRole('region', { name: 'Multiple choices', exact: true });
  550 |   const input = region.getByRole('combobox', { name: 'People to add', exact: true });
  551 |   const value = region.getByRole('status', { name: 'People value', exact: true });
  552 |   const query = region.getByRole('status', { name: 'People query', exact: true });
  553 |   await input.fill('first@orbit.test, second@orbit.test ');
  554 |   await expect(value).toHaveText('["owner@orbit.test","first@orbit.test","second@orbit.test"]');
  555 |   await expect(query).toHaveText('');
  556 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  557 |   await input.fill('draft@orbit.test');
  558 |   await expect(query).toHaveText('draft@orbit.test');
  559 |   await page.keyboard.press('Enter');
  560 |   await expect(value).toContainText('draft@orbit.test');
  561 |   await input.dispatchEvent('compositionstart');
  562 |   await input.fill('中文@orbit.test');
  563 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  564 |   await expect(value).not.toContainText('中文@orbit.test');
  565 |   await input.dispatchEvent('compositionend');
  566 |   await page.keyboard.press('Enter');
  567 |   await expect(value).toContainText('中文@orbit.test');
  568 |   await input.fill('blur@orbit.test');
  569 |   await region.getByRole('button', { name: 'After tags' }).click();
  570 |   await expect(value).toContainText('blur@orbit.test');
  571 |   await expect(query).toHaveText('');
  572 |   await input.focus();
  573 |   await page.keyboard.press('Backspace');
  574 |   await expect(value).not.toContainText('blur@orbit.test');
  575 |   await region.getByRole('button', { name: 'Remove first@orbit.test', exact: true }).click();
  576 |   await expect(value).not.toContainText('first@orbit.test');
  577 |   await expect(input).toBeFocused();
  578 |   await input.fill('owner@orbit.test ');
  579 |   const emails = JSON.parse(await value.textContent());
  580 |   expect(emails.filter((email) => email === 'owner@orbit.test')).toHaveLength(1);
  581 |   await input.focus();
  582 |   await page.keyboard.press('Tab');
  583 |   await page.keyboard.press('Enter');
  584 |   await expect(value).toHaveText('[]');
  585 |   await attach(info, 'email-tags', { controlledQuery: true, commaSpace: true, enter: true, blurCommits: true, syntheticComposition: true, backspace: true, remove: true, deduplicated: true, keyboardClear: true });
  586 | });
  587 | 
  588 | test('multiple choices in Dialog keep their owner and menus do not activate a clickable row', async ({ page }, info) => {
  589 |   const trigger = page.getByRole('button', { name: 'Open multi Dialog', exact: true });
  590 |   await tap(page, info, trigger);
  591 |   const dialog = page.getByRole('dialog', { name: 'Multiple choices', exact: true });
  592 |   const input = dialog.getByRole('combobox', { name: 'Labels', exact: true });
  593 |   await tap(page, info, input);
  594 |   const list = page.getByRole('listbox');
  595 |   await expect(list).toBeVisible();
  596 |   expect(await list.evaluate((el) => !!el.closest('[role="dialog"]'))).toBe(true);
  597 |   await tap(page, info, page.getByRole('option', { name: 'Docs', exact: true }));
  598 |   await expect(dialog).toBeVisible();
  599 |   await page.keyboard.press('Escape');
  600 |   await expect(list).not.toBeVisible();
  601 |   await expect(input).toBeFocused();
  602 |   const tags = dialog.getByRole('combobox', { name: 'People to add', exact: true });
  603 |   await tags.focus();
  604 |   await tags.dispatchEvent('compositionstart');
  605 |   await tags.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  606 |   await expect(dialog).toBeVisible();
  607 |   await tags.dispatchEvent('compositionend');
  608 |   await tags.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
```