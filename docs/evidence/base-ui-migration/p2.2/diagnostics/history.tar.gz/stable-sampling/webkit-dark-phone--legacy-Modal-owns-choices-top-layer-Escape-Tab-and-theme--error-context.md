# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> legacy Modal owns choices, top-layer Escape, Tab and theme
- Location: ui-migration/choices.browser.mjs:227:37

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main [ref=e4]:
    - status [ref=e5]: dark
    - button "Switch theme" [ref=e6] [cursor=pointer]
    - button "Open Dialog" [ref=e8] [cursor=pointer]
    - button "Open legacy Modal" [ref=e10] [cursor=pointer]
    - region "Standalone choices" [ref=e12]:
      - generic [ref=e13]:
        - generic [ref=e14]:
          - combobox "Expires" [ref=e15] [cursor=pointer]:
            - generic [ref=e16]: Never
          - button "Clear selection" [ref=e20] [cursor=pointer]
        - textbox [aria-hidden] [ref=e24]: never
        - generic [ref=e25]:
          - generic [aria-hidden]: Orbit workspace
          - combobox "Workspace" [ref=e26]
          - button "Show options" [ref=e27] [cursor=pointer]
          - button "Clear selection" [ref=e31] [cursor=pointer]
        - textbox [aria-hidden] [ref=e35]: orbit
        - combobox "Disabled select" [disabled] [ref=e37]:
          - generic [ref=e38]: Never
        - textbox [disabled] [aria-hidden] [ref=e42]: never
        - generic [ref=e43]:
          - generic [aria-hidden]: Never
          - combobox "Disabled search" [disabled] [ref=e44]
          - button "Show options" [disabled] [ref=e45] [cursor=pointer]
        - textbox [disabled] [aria-hidden] [ref=e49]: never
        - combobox "Empty select" [ref=e51] [cursor=pointer]:
          - generic [ref=e52]: No accounts
        - textbox [aria-hidden] [ref=e56]
        - combobox "Automatic account" [ref=e58] [cursor=pointer]:
          - generic [ref=e59]: Automatic
        - textbox [aria-hidden] [ref=e63]
        - button "Session actions" [ref=e64] [cursor=pointer]
        - button "Add attachment" [ref=e66] [cursor=pointer]
        - button "Open context" [ref=e68] [cursor=pointer]
        - button "Account usage" [ref=e70] [cursor=pointer]
        - button "Unavailable action" [disabled] [ref=e73]
        - button "After choices" [ref=e75] [cursor=pointer]
        - status "Expiry value" [ref=e77]: never
        - status "Workspace value" [ref=e78]: orbit
        - status "Action" [ref=e79]: none
        - status "Tag" [ref=e80]: "false"
      - generic [ref=e81]:
        - combobox "Add prerequisite" [ref=e82]
        - button "Show options" [ref=e83] [cursor=pointer]
      - textbox [aria-hidden] [ref=e87]
      - status "Prerequisite" [ref=e88]: none
  - generic [ref=e89]:
    - dialog "Legacy share":
      - generic [ref=e90]:
        - button "Close" [ref=e91] [cursor=pointer]:
          - generic "Close" [ref=e92]:
            - img "close" [ref=e93]
        - generic [ref=e96]: Legacy share
        - generic [ref=e100]:
          - generic [ref=e101]:
            - combobox "Expires" [ref=e102] [cursor=pointer]:
              - generic [ref=e103]: Never
            - button "Clear selection" [ref=e107] [cursor=pointer]
          - textbox [aria-hidden] [ref=e111]: never
          - generic [ref=e112]:
            - generic [aria-hidden]: Orbit workspace
            - combobox "Workspace" [ref=e113]
            - button "Show options" [ref=e114] [cursor=pointer]
            - button "Clear selection" [ref=e118] [cursor=pointer]
          - textbox [aria-hidden] [ref=e122]: orbit
          - combobox "Disabled select" [disabled] [ref=e124]:
            - generic [ref=e125]: Never
          - textbox [disabled] [aria-hidden] [ref=e129]: never
          - generic [ref=e130]:
            - generic [aria-hidden]: Never
            - combobox "Disabled search" [disabled] [ref=e131]
            - button "Show options" [disabled] [ref=e132] [cursor=pointer]
          - textbox [disabled] [aria-hidden] [ref=e136]: never
          - combobox "Empty select" [ref=e138] [cursor=pointer]:
            - generic [ref=e139]: No accounts
          - textbox [aria-hidden] [ref=e143]
          - combobox "Automatic account" [ref=e145] [cursor=pointer]:
            - generic [ref=e146]: Automatic
          - textbox [aria-hidden] [ref=e150]
          - button "Session actions" [ref=e151] [cursor=pointer]
          - button "Add attachment" [ref=e153] [cursor=pointer]
          - button "Open context" [ref=e155] [cursor=pointer]
          - button "Account usage" [ref=e157] [cursor=pointer]
          - button "Unavailable action" [disabled] [ref=e160]
          - button "After choices" [ref=e162] [cursor=pointer]
          - status "Expiry value" [ref=e164]: never
          - status "Workspace value" [ref=e165]: orbit
          - status "Action" [ref=e166]: none
          - status "Tag" [ref=e167]: "false"
```

# Test source

```ts
  155 |   await expect(select).toBeFocused();
  156 |   await select.click();
  157 |   await expect(page.getByRole('option', { name: '7 days', exact: true })).toHaveAttribute('aria-selected', 'true');
  158 |   await expect(page.getByRole('option', { name: '30 days', exact: true })).toHaveAttribute('aria-disabled', 'true');
  159 |   await page.keyboard.press('Escape');
  160 |   await page.getByRole('button', { name: 'Clear selection' }).first().click();
  161 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('null');
  162 |   await expect(select).toBeFocused();
  163 |   await expect(page.getByRole('combobox', { name: 'Disabled select', exact: true })).toBeDisabled();
  164 |   await expect(page.getByRole('combobox', { name: 'Disabled search', exact: true })).toBeDisabled();
  165 |   await page.getByRole('combobox', { name: 'Empty select', exact: true }).click();
  166 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  167 |   await page.keyboard.press('Escape');
  168 |   const automatic = page.getByRole('combobox', { name: 'Automatic account', exact: true });
  169 |   await expect(automatic).toContainText('Automatic');
  170 |   await automatic.click();
  171 |   await expect(page.getByRole('option', { name: /Automatic/ })).toHaveAttribute('aria-selected', 'true');
  172 |   await outside(page, info);
  173 |   await expect(automatic).toHaveAttribute('aria-expanded', 'false');
  174 |   await attach(info, 'select', { selected: '7', cleared: true, disabled: true, empty: true, emptyStringIsSelection: true });
  175 | });
  176 | 
  177 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  178 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  179 |   await input.click();
  180 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  181 |   await input.fill('docs');
  182 |   await expect(page.getByRole('option')).toHaveCount(1);
  183 |   await page.keyboard.press('Enter');
  184 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  185 |   await expect(input).toBeFocused();
  186 |   await input.fill('missing');
  187 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  188 |   await page.keyboard.press('Escape');
  189 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  190 |   await input.click();
  191 |   await input.dispatchEvent('compositionstart');
  192 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  193 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  194 |   await expect(input).toHaveAttribute('aria-expanded', 'true');
  195 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  196 |   await input.dispatchEvent('compositionend', { data: '文档' });
  197 |   await input.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  198 |   await input.fill('文档');
  199 |   await expect(page.getByRole('option')).toHaveCount(1);
  200 |   await page.keyboard.press('Enter');
  201 |   await page.getByRole('button', { name: 'Clear selection' }).nth(1).click();
  202 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  203 |   await expect(input).toBeFocused();
  204 |   await attach(info, 'search', { grouping: true, chinese: true, syntheticCompositionIgnored: true, escapePreservesValue: true, explicitClear: true });
  205 | });
  206 | 
  207 | test('remote search accepts server labels and resets an action picker without local filtering', async ({ page }, info) => {
  208 |   let release;
  209 |   const gate = new Promise((resolve) => { release = resolve; });
  210 |   await page.route('**/__choices-search?*', async (route) => {
  211 |     await gate;
  212 |     await route.fulfill({ json: [{ value: 'task-1', label: 'Server ranked result' }] });
  213 |   });
  214 |   const input = page.getByRole('combobox', { name: 'Add prerequisite', exact: true });
  215 |   await input.fill('query');
  216 |   await expect(input).toHaveAttribute('aria-busy', 'true');
  217 |   release();
  218 |   const option = page.getByRole('option', { name: 'Server ranked result', exact: true });
  219 |   await expect(option).toBeVisible();
  220 |   await option.click();
  221 |   await expect(page.getByRole('status', { name: 'Prerequisite', exact: true })).toHaveText('task-1');
  222 |   await expect(input).toHaveValue('');
  223 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  224 |   await attach(info, 'remote-search', { loadingExposed: true, filterDisabled: true, valueNullResetsQuery: true });
  225 | });
  226 | 
  227 | for (const legacy of [false, true]) test(`${legacy ? 'legacy Modal' : 'Dialog'} owns choices, top-layer Escape, Tab and theme`, async ({ page }, info) => {
  228 |   const trigger = page.getByRole('button', { name: legacy ? 'Open legacy Modal' : 'Open Dialog', exact: true });
  229 |   await tap(page, info, trigger);
  230 |   const dialog = page.getByRole('dialog', { name: legacy ? 'Legacy share' : 'Share workspace', exact: true });
  231 |   await settle(dialog);
  232 |   const input = dialog.getByRole('combobox', { name: 'Workspace', exact: true });
  233 |   await tap(page, info, input);
  234 |   const list = page.getByRole('listbox');
  235 |   await expect(list).toBeVisible();
  236 |   expect(await list.evaluate((el) => !!el.closest('[role="dialog"]'))).toBe(true);
  237 |   await page.keyboard.press('Escape');
  238 |   await expect(list).not.toBeVisible();
  239 |   await expect(dialog).toBeVisible();
  240 |   await expect(input).toBeFocused();
  241 |   await tap(page, info, dialog.getByRole('combobox', { name: 'Expires', exact: true }));
  242 |   await expect(list).toBeVisible();
  243 |   await page.keyboard.press('Escape');
  244 |   await expect(list).not.toBeVisible();
  245 |   await expect(dialog).toBeVisible();
  246 |   const actions = dialog.getByRole('button', { name: 'Session actions', exact: true });
  247 |   await tap(page, info, actions);
  248 |   await expect(page.getByRole('menu')).toBeVisible();
  249 |   await page.keyboard.press('Escape');
  250 |   await expect(dialog).toBeVisible();
  251 |   await expect(actions).toBeFocused();
  252 |   for (const key of ['Tab', 'Shift+Tab']) for (let i = 0; i < 12; i++) {
  253 |     await page.keyboard.press(key);
  254 |     const focusOwner = legacy ? page.locator('.legacy-choices-owner') : dialog;
> 255 |     await expect.poll(() => focusOwner.evaluate((el) => el.contains(document.activeElement))).toBe(true);
      |                                                                                               ^ Error: expect(received).toBe(expected) // Object.is equality
  256 |   }
  257 |   expect(await page.evaluate(() => [document.body, document.documentElement].some((el) => /hidden|clip/.test(getComputedStyle(el).overflowY)))).toBe(true);
  258 |   await shot(info, 'choices-in-dialog', dialog);
  259 |   await page.keyboard.press('Escape');
  260 |   await expect(dialog).not.toBeVisible();
  261 |   await expect(trigger).toBeFocused();
  262 |   await attach(info, 'nested-choices', { legacy, topLayerOnly: true, portalInsideOwner: true, tabBothDirections: true, scrollLocked: true, returned: true });
  263 | });
  264 | 
  265 | test('popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover', async ({ page }, info) => {
  266 |   const trigger = page.getByRole('button', { name: 'Open context', exact: true });
  267 |   await tap(page, info, trigger);
  268 |   const popover = page.getByRole('dialog', { name: 'Context', exact: true });
  269 |   await expect(popover).toBeVisible();
  270 |   const select = popover.getByRole('combobox', { name: 'Context expiry', exact: true });
  271 |   await select.click();
  272 |   await expect(page.getByRole('listbox')).toBeVisible();
  273 |   await page.keyboard.press('Escape');
  274 |   await expect(popover).toBeVisible();
  275 |   await expect(select).toBeFocused();
  276 |   await page.keyboard.press('Escape');
  277 |   await expect(popover).not.toBeVisible();
  278 |   await expect(trigger).toBeFocused();
  279 |   await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  280 |   const usage = page.getByRole('button', { name: 'Account usage', exact: true });
  281 |   await page.keyboard.press('Tab');
  282 |   await usage.focus();
  283 |   const tooltip = page.getByRole('tooltip');
  284 |   await expect(tooltip).toHaveText('Usage from this account');
  285 |   await expect(usage).toHaveAttribute('aria-describedby', /.+/);
  286 |   await page.keyboard.press('Escape');
  287 |   await expect(tooltip).not.toBeVisible();
  288 |   await usage.blur();
  289 |   await usage.hover();
  290 |   await expect(tooltip).toBeVisible();
  291 |   await page.mouse.move(0, 0);
  292 |   await expect(tooltip).not.toBeVisible();
  293 |   await tap(page, info, trigger);
  294 |   await outside(page, info);
  295 |   await expect(popover).not.toBeVisible();
  296 |   await attach(info, 'popover-tooltip', { nestedSelect: true, sequentialEscape: true, focusReturn: true, tooltipFocusHoverEscape: true });
  297 | });
  298 | 
```