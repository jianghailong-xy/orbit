# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover
- Location: ui-migration/choices.browser.mjs:265:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: getByRole('tooltip')
Expected: "Usage from this account"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" getByRole('tooltip') with timeout 15000ms
  - waiting for getByRole('tooltip')

```

```yaml
- main:
  - status: light
  - button "Switch theme"
  - button "Open Dialog"
  - button "Open legacy Modal"
  - region "Standalone choices":
    - combobox "Expires": Never
    - button "Clear selection"
    - combobox "Workspace"
    - button "Show options"
    - button "Clear selection"
    - combobox "Disabled select" [disabled]: Never
    - combobox "Disabled search" [disabled]
    - button "Show options" [disabled]
    - combobox "Empty select": No accounts
    - combobox "Automatic account": Automatic
    - button "Session actions"
    - button "Add attachment"
    - button "Open context"
    - button "Account usage"
    - button "Unavailable action" [disabled]
    - button "After choices"
    - status "Expiry value": never
    - status "Workspace value": orbit
    - status "Action": none
    - status "Tag": "false"
    - combobox "Add prerequisite"
    - button "Show options"
    - status "Prerequisite": none
- text: Usage from this account
```

# Test source

```ts
  184 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  185 |   await expect(input).toBeFocused();
  186 |   await input.fill('missing');
  187 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  188 |   await page.keyboard.press('Escape');
  189 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  190 |   await input.click();
  191 |   await input.dispatchEvent('compositionstart');
  192 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  193 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  194 |   await expect(input).toHaveAttribute('aria-expanded', 'true');
  195 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  196 |   await input.dispatchEvent('compositionend', { data: '文档' });
  197 |   await input.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  198 |   await input.fill('文档');
  199 |   await expect(page.getByRole('option')).toHaveCount(1);
  200 |   await page.keyboard.press('Enter');
  201 |   await page.getByRole('button', { name: 'Clear selection' }).nth(1).click();
  202 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  203 |   await expect(input).toBeFocused();
  204 |   await attach(info, 'search', { grouping: true, chinese: true, syntheticCompositionIgnored: true, escapePreservesValue: true, explicitClear: true });
  205 | });
  206 | 
  207 | test('remote search accepts server labels and resets an action picker without local filtering', async ({ page }, info) => {
  208 |   let release;
  209 |   const gate = new Promise((resolve) => { release = resolve; });
  210 |   await page.route('**/__choices-search?*', async (route) => {
  211 |     await gate;
  212 |     await route.fulfill({ json: [{ value: 'task-1', label: 'Server ranked result' }] });
  213 |   });
  214 |   const input = page.getByRole('combobox', { name: 'Add prerequisite', exact: true });
  215 |   await input.fill('query');
  216 |   await expect(input).toHaveAttribute('aria-busy', 'true');
  217 |   release();
  218 |   const option = page.getByRole('option', { name: 'Server ranked result', exact: true });
  219 |   await expect(option).toBeVisible();
  220 |   await option.click();
  221 |   await expect(page.getByRole('status', { name: 'Prerequisite', exact: true })).toHaveText('task-1');
  222 |   await expect(input).toHaveValue('');
  223 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  224 |   await attach(info, 'remote-search', { loadingExposed: true, filterDisabled: true, valueNullResetsQuery: true });
  225 | });
  226 | 
  227 | for (const legacy of [false, true]) test(`${legacy ? 'legacy Modal' : 'Dialog'} owns choices, top-layer Escape, Tab and theme`, async ({ page }, info) => {
  228 |   const trigger = page.getByRole('button', { name: legacy ? 'Open legacy Modal' : 'Open Dialog', exact: true });
  229 |   await tap(page, info, trigger);
  230 |   const dialog = page.getByRole('dialog', { name: legacy ? 'Legacy share' : 'Share workspace', exact: true });
  231 |   await settle(dialog);
  232 |   const input = dialog.getByRole('combobox', { name: 'Workspace', exact: true });
  233 |   await tap(page, info, input);
  234 |   const list = page.getByRole('listbox');
  235 |   await expect(list).toBeVisible();
  236 |   expect(await list.evaluate((el) => !!el.closest('[role="dialog"]'))).toBe(true);
  237 |   await page.keyboard.press('Escape');
  238 |   await expect(list).not.toBeVisible();
  239 |   await expect(dialog).toBeVisible();
  240 |   await expect(input).toBeFocused();
  241 |   await tap(page, info, dialog.getByRole('combobox', { name: 'Expires', exact: true }));
  242 |   await expect(list).toBeVisible();
  243 |   await page.keyboard.press('Escape');
  244 |   await expect(list).not.toBeVisible();
  245 |   await expect(dialog).toBeVisible();
  246 |   const actions = dialog.getByRole('button', { name: 'Session actions', exact: true });
  247 |   await tap(page, info, actions);
  248 |   await expect(page.getByRole('menu')).toBeVisible();
  249 |   await page.keyboard.press('Escape');
  250 |   await expect(dialog).toBeVisible();
  251 |   await expect(actions).toBeFocused();
  252 |   for (const key of ['Tab', 'Shift+Tab']) for (let i = 0; i < 12; i++) {
  253 |     await page.keyboard.press(key);
  254 |     const focusOwner = legacy ? page.locator('.legacy-choices-owner') : dialog;
  255 |     await expect.poll(() => focusOwner.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  256 |   }
  257 |   expect(await page.evaluate(() => [document.body, document.documentElement].some((el) => /hidden|clip/.test(getComputedStyle(el).overflowY)))).toBe(true);
  258 |   await shot(info, 'choices-in-dialog', dialog);
  259 |   await page.keyboard.press('Escape');
  260 |   await expect(dialog).not.toBeVisible();
  261 |   await expect(trigger).toBeFocused();
  262 |   await attach(info, 'nested-choices', { legacy, topLayerOnly: true, portalInsideOwner: true, tabBothDirections: true, scrollLocked: true, returned: true });
  263 | });
  264 | 
  265 | test('popover owns a select and restores focus one layer at a time; tooltip responds to focus and hover', async ({ page }, info) => {
  266 |   const trigger = page.getByRole('button', { name: 'Open context', exact: true });
  267 |   await tap(page, info, trigger);
  268 |   const popover = page.getByRole('dialog', { name: 'Context', exact: true });
  269 |   await expect(popover).toBeVisible();
  270 |   const select = popover.getByRole('combobox', { name: 'Context expiry', exact: true });
  271 |   await select.click();
  272 |   await expect(page.getByRole('listbox')).toBeVisible();
  273 |   await page.keyboard.press('Escape');
  274 |   await expect(popover).toBeVisible();
  275 |   await expect(select).toBeFocused();
  276 |   await page.keyboard.press('Escape');
  277 |   await expect(popover).not.toBeVisible();
  278 |   await expect(trigger).toBeFocused();
  279 |   await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  280 |   const usage = page.getByRole('button', { name: 'Account usage', exact: true });
  281 |   await page.keyboard.press('Tab');
  282 |   await usage.focus();
  283 |   const tooltip = page.getByRole('tooltip');
> 284 |   await expect(tooltip).toHaveText('Usage from this account');
      |                         ^ Error: expect(locator).toHaveText(expected) failed
  285 |   await expect(usage).toHaveAttribute('aria-describedby', /.+/);
  286 |   await page.keyboard.press('Escape');
  287 |   await expect(tooltip).not.toBeVisible();
  288 |   await usage.blur();
  289 |   await usage.hover();
  290 |   await expect(tooltip).toBeVisible();
  291 |   await page.mouse.move(0, 0);
  292 |   await expect(tooltip).not.toBeVisible();
  293 |   await tap(page, info, trigger);
  294 |   await outside(page, info);
  295 |   await expect(popover).not.toBeVisible();
  296 |   await attach(info, 'popover-tooltip', { nestedSelect: true, sequentialEscape: true, focusReturn: true, tooltipFocusHoverEscape: true });
  297 | });
  298 | 
```