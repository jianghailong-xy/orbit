# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> tooltip matches the current surface, density and option states
- Location: ui-migration/choices.browser.mjs:74:3

# Error details

```
Error: locator.screenshot: Node has 0 width.
Call log:
  - taking element screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - attempting scroll into view action
    - waiting for element to be stable

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - main [ref=f1e4]:
    - status [ref=f1e5]: light
    - button "Switch theme" [ref=f1e6] [cursor=pointer]
    - region "Appearance sample" [ref=f1e8]:
      - button "Usage" [ref=f1e10] [cursor=pointer]
  - tooltip "Usage from this account" [ref=f1e13]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | const fixture = '/ui-migration/choices.html';
  4   | const errors = new WeakMap();
  5   | test.beforeEach(async ({ page }, info) => {
  6   |   errors.set(page, []);
  7   |   page.on('pageerror', (error) => errors.get(page).push(error.message));
  8   |   await page.goto(fixture);
  9   |   await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  10  |   await page.evaluate(() => document.fonts.ready);
  11  | });
  12  | test.afterEach(async ({ page }) => { expect(errors.get(page)).toEqual([]); });
  13  | const attach = (info, name, value) => info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  14  | const shot = (info, name, locator) => locator.screenshot({ animations: 'disabled' }).then((body) => info.attach(name, { body, contentType: 'image/png' }));
  15  | async function settle(locator) {
  16  |   await expect(locator).toBeVisible();
  17  |   // Playwright waits for stable geometry and finishes finite CSS motion before
  18  |   // capture. AntD can schedule its enter animation after the first render frame.
> 19  |   await locator.screenshot({ animations: 'disabled' });
      |                 ^ Error: locator.screenshot: Node has 0 width.
  20  |   await locator.evaluate(async (el) => {
  21  |     const animations = new Set(el.getAnimations({ subtree: true }));
  22  |     for (let node = el.parentElement; node; node = node.parentElement) for (const animation of node.getAnimations()) animations.add(animation);
  23  |     await Promise.all([...animations].filter((a) => a.effect?.getComputedTiming().iterations !== Infinity).map((a) => a.finished.catch(() => {})));
  24  |     await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
  25  |   });
  26  | }
  27  | async function tap(page, info, locator) {
  28  |   if (info.project.use.hasTouch) await locator.tap();
  29  |   else await locator.click();
  30  | }
  31  | async function outside(page, info) {
  32  |   if (info.project.use.hasTouch) await page.touchscreen.tap(3, 60);
  33  |   else await page.mouse.click(3, 60);
  34  | }
  35  | async function measure(locator, contents = false) {
  36  |   return locator.evaluate((el, contents) => {
  37  |     const root = el.getBoundingClientRect();
  38  |     const metrics = (node) => {
  39  |       const r = node.getBoundingClientRect(), s = getComputedStyle(node);
  40  |       const keys = ['fontFamily', 'fontSize', 'lineHeight', 'fontWeight', 'color', 'backgroundColor', 'borderRadius', 'borderColor', 'borderWidth', 'borderStyle', 'padding', 'boxShadow'];
  41  |       return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, ...Object.fromEntries(keys.map((key) => [key, s[key]])) };
  42  |     };
  43  |     const visible = (node) => {
  44  |       for (let parent = node; parent; parent = parent.parentElement) {
  45  |         const style = getComputedStyle(parent);
  46  |         if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
  47  |       }
  48  |       return node.getBoundingClientRect().width > 0;
  49  |     };
  50  |     const result = { surface: metrics(el), rows: [...el.querySelectorAll('[role="menuitem"], [role="option"]')].map((row) => ({ label: row.textContent, ...metrics(row) })) };
  51  |     if (contents) {
  52  |       result.origin = { x: root.x, y: root.y };
  53  |       result.texts = [];
  54  |       const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  55  |       while (walker.nextNode()) {
  56  |         const node = walker.currentNode;
  57  |         if (!node.textContent.trim() || !visible(node.parentElement)) continue;
  58  |         const range = document.createRange(); range.selectNode(node);
  59  |         const r = range.getBoundingClientRect(), s = getComputedStyle(node.parentElement);
  60  |         if (!r.width || !r.height) continue;
  61  |         result.texts.push({ text: node.textContent, x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height,
  62  |           color: s.color, fontSize: s.fontSize, fontWeight: s.fontWeight });
  63  |       }
  64  |       result.icons = [...el.querySelectorAll('svg')].filter(visible).map((svg) => {
  65  |         const r = svg.getBoundingClientRect();
  66  |         return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, color: getComputedStyle(svg).color };
  67  |       });
  68  |     }
  69  |     return result;
  70  |   }, contents);
  71  | }
  72  | 
  73  | for (const kind of ['attachment', 'access', 'expiry', 'account', 'search', 'popover', 'tooltip']) {
  74  |   test(`${kind} matches the current surface, density and option states`, async ({ page }, info) => {
  75  |     const measurements = {};
  76  |     const glyphs = {};
  77  |     for (const system of ['antd', 'orbit']) {
  78  |       await page.goto(`${fixture}?sample=${kind}&system=${system}`);
  79  |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  80  |       const region = page.getByRole('region', { name: 'Appearance sample' });
  81  |       const choice = region.getByRole('combobox');
  82  |       if (['expiry', 'account', 'search'].includes(kind)) {
  83  |         await page.mouse.move(0, 0);
  84  |         await page.getByTestId('neutral').focus();
  85  |         await settle(page.locator('.sample-choice'));
  86  |         measurements[system] = { control: await measure(page.locator('.sample-choice'), true) };
  87  |         await shot(info, `${system}-${kind}-closed`, page.locator('.sample-choice'));
  88  |         await choice.click();
  89  |       } else if (kind === 'tooltip') {
  90  |         await region.getByRole('button').hover();
  91  |         await settle(region.getByRole('button'));
  92  |       }
  93  |       else await region.getByRole('button').click();
  94  |       const surface = page.locator('.sample-surface:visible');
  95  |       await settle(surface);
  96  |       if (kind !== 'tooltip') await page.mouse.move(0, 0);
  97  |       await settle(surface);
  98  |       measurements[system] = { ...measurements[system], popup: await measure(surface) };
  99  |       await shot(info, `${system}-${kind}-open`, surface);
  100 |       if (['attachment', 'access'].includes(kind)) {
  101 |         glyphs[system] = await surface.evaluate((el) => {
  102 |           const root = el.getBoundingClientRect();
  103 |           return [...el.querySelectorAll('svg')].map((svg) => {
  104 |             const r = svg.getBoundingClientRect();
  105 |             return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, color: getComputedStyle(svg).color };
  106 |           });
  107 |         });
  108 |         if (kind === 'attachment' && system === 'orbit' && info.project.use.hasTouch) {
  109 |           expect(await surface.locator('.orbit-menu-label').first().evaluate((el) => el.getBoundingClientRect().x - el.closest('.orbit-menu').getBoundingClientRect().x)).toBe(66);
  110 |         }
  111 |       }
  112 |       if (['popover', 'tooltip'].includes(kind)) {
  113 |         const arrow = page.locator(system === 'antd' ? '.sample-arrow:visible' : '.orbit-floating-arrow:visible');
  114 |         const box = await surface.boundingBox();
  115 |         const arrowBox = await arrow.boundingBox();
  116 |         measurements[system].callout = {
  117 |           arrow: { x: arrowBox.x - box.x, y: arrowBox.y - box.y, width: arrowBox.width, height: arrowBox.height },
  118 |           shape: await arrow.evaluate((el) => ({ fill: getComputedStyle(el, '::before').backgroundColor, clipPath: getComputedStyle(el, '::before').clipPath })),
  119 |           filter: await page.locator(system === 'antd' ? '.sample-floating-root:visible' : '.orbit-callout-positioner:visible').evaluate((el) => getComputedStyle(el).filter),
```