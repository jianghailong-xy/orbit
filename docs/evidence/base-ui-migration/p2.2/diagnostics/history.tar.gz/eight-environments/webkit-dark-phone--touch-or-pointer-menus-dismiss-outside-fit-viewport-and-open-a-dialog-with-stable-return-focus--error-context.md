# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> touch or pointer menus dismiss outside, fit viewport and open a dialog with stable return focus
- Location: ui-migration/choices.browser.mjs:220:1

# Error details

```
Error: expect(locator).not.toBeVisible() failed

Locator:  getByRole('menu')
Expected: not visible
Received: visible
Timeout:  15000ms

Call log:
  - Expect "not toBeVisible" getByRole('menu') with timeout 15000ms
  - waiting for getByRole('menu')
    2 × locator resolved to <div id="_r_t_" role="menu" data-open="" tabindex="-1" data-align="end" data-side="bottom" class="orbit-menu" data-starting-style="" data-rootownerid="_r_s_" data-base-ui-focusable="" data-variant="attachment" aria-labelledby="base-ui-_r_v_">…</div>
      - unexpected value "visible"
    25 × locator resolved to <div id="_r_t_" role="menu" data-open="" tabindex="-1" data-align="end" data-side="bottom" class="orbit-menu" data-rootownerid="_r_s_" data-base-ui-focusable="" data-variant="attachment" aria-labelledby="base-ui-_r_v_">…</div>
       - unexpected value "visible"

```

```yaml
- menu "Add attachment":
  - menuitem "File"
  - menuitem "Image"
  - separator
  - menuitem "Shell"
  - menuitem "Skill" [disabled]
  - menuitem "Command"
```

# Test source

```ts
  132 |     if (kind === 'attachment' && info.project.use.hasTouch) {
  133 |       // P0's original phone sample also measured 14px items: AntD's generated
  134 |       // selector overrides the existing 17px rule. The task explicitly requires
  135 |       // the confirmed 17px/42.4px/26px design. Retain both raw samples; assert the
  136 |       // requested differences exactly, and every other measured property unchanged.
  137 |       const expected = structuredClone(measurements.antd);
  138 |       expected.popup.surface.height = 40 + 5 * 42.390625;
  139 |       expected.popup.rows.forEach((row, i) => Object.assign(row, {
  140 |         fontSize: '17px', borderRadius: '0px', padding: '0px 0px 0px 31px',
  141 |         lineHeight: info.project.use.browserName === 'webkit' ? '26.714285px' : '26.7143px',
  142 |         y: 10 + i * 42.390625 + (i >= 2 ? 20 : 0),
  143 |       }));
  144 |       expect(measurements.orbit).toEqual(expected);
  145 |     } else expect(measurements.orbit).toEqual(measurements.antd);
  146 |   });
  147 | }
  148 | 
  149 | test('empty, disabled, hover and focus choice surfaces match the existing states', async ({ page }, info) => {
  150 |   const measurements = {};
  151 |   for (const kind of ['expiry', 'search']) for (const state of ['disabled', 'empty', 'default']) {
  152 |     const values = {};
  153 |     for (const system of ['antd', 'orbit']) {
  154 |       await page.goto(`${fixture}?sample=${kind}&system=${system}&state=${state}`);
  155 |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  156 |       const control = page.locator('.sample-choice');
  157 |       const input = page.getByRole('combobox', { name: 'Sample choice' });
  158 |       await page.mouse.move(0, 0);
  159 |       await page.getByTestId('neutral').focus();
  160 |       await settle(control);
  161 |       values[system] = { control: await measure(control, true) };
  162 |       if (state === 'disabled') {
  163 |         await expect(input).toBeDisabled();
  164 |         await shot(info, `${system}-${kind}-disabled`, control);
  165 |       } else if (state === 'empty') {
  166 |         await input.click();
  167 |         const surface = page.locator('.sample-surface:visible');
  168 |         await settle(surface);
  169 |         await expect(surface.getByText('No data', { exact: true }).and(surface.locator('div'))).toBeVisible();
  170 |         values[system].popup = await measure(surface);
  171 |         await shot(info, `${system}-${kind}-empty`, surface);
  172 |       } else {
  173 |         await control.hover();
  174 |         await settle(control);
  175 |         values[system].hover = await measure(control, true);
  176 |         await input.focus();
  177 |         await page.mouse.move(0, 0);
  178 |         await settle(control);
  179 |         values[system].focus = await measure(control, true);
  180 |         await shot(info, `${system}-${kind}-focus`, control);
  181 |       }
  182 |     }
  183 |     measurements[`${kind}-${state}`] = values;
  184 |   }
  185 |   await attach(info, 'choice-states', measurements);
  186 |   for (const values of Object.values(measurements)) expect(values.orbit).toEqual(values.antd);
  187 | });
  188 | 
  189 | test('menu arrows, disabled items, submenu, checkbox and focus return work', async ({ page }, info) => {
  190 |   const trigger = page.getByRole('button', { name: 'Session actions', exact: true });
  191 |   await trigger.focus();
  192 |   await page.keyboard.press('ArrowDown');
  193 |   const first = page.getByRole('menuitem', { name: 'Default model', exact: true });
  194 |   await expect(first).toBeFocused();
  195 |   await page.keyboard.press('ArrowDown');
  196 |   const provider = page.getByRole('menuitem', { name: 'Provider', exact: true });
  197 |   await expect(provider).toBeFocused();
  198 |   await page.keyboard.press('ArrowRight');
  199 |   await expect(page.getByRole('menuitem', { name: 'Codex', exact: true })).toBeFocused();
  200 |   await page.keyboard.press('Escape');
  201 |   await expect(provider).toBeFocused();
  202 |   await expect(page.getByRole('menu')).toHaveCount(1);
  203 |   await page.keyboard.press('ArrowRight');
  204 |   await page.keyboard.press('ArrowDown');
  205 |   await page.keyboard.press('Enter');
  206 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('claude');
  207 |   await expect(trigger).toBeFocused();
  208 |   await trigger.click();
  209 |   const tag = page.getByRole('menuitemcheckbox', { name: 'Important tag' });
  210 |   await tag.click();
  211 |   await expect(tag).toHaveAttribute('aria-checked', 'true');
  212 |   await expect(page.getByRole('status', { name: 'Tag', exact: true })).toHaveText('true');
  213 |   await tag.press('Space');
  214 |   await expect(tag).toHaveAttribute('aria-checked', 'false');
  215 |   await page.keyboard.press('Escape');
  216 |   await expect(trigger).toBeFocused();
  217 |   await attach(info, 'keyboard-menu', { disabledSkipped: true, submenuOnlyEscape: true, selection: 'claude', checkboxStaysOpen: true, focusReturned: true });
  218 | });
  219 | 
  220 | test('touch or pointer menus dismiss outside, fit viewport and open a dialog with stable return focus', async ({ page }, info) => {
  221 |   const trigger = page.getByRole('button', { name: 'Add attachment', exact: true });
  222 |   await tap(page, info, trigger);
  223 |   const menu = page.getByRole('menu');
  224 |   const box = await menu.boundingBox();
  225 |   expect(box.x).toBeGreaterThanOrEqual(0);
  226 |   expect(box.x + box.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  227 |   await tap(page, info, page.getByRole('menuitem', { name: 'Image', exact: true }));
  228 |   await expect(menu).not.toBeVisible();
  229 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('image');
  230 |   await tap(page, info, trigger);
  231 |   await outside(page, info);
> 232 |   await expect(menu).not.toBeVisible();
      |                          ^ Error: expect(locator).not.toBeVisible() failed
  233 |   const actions = page.getByRole('button', { name: 'Session actions', exact: true });
  234 |   await tap(page, info, actions);
  235 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  236 |   const sub = page.getByRole('menu').filter({ has: page.getByRole('menuitem', { name: 'Codex', exact: true }) });
  237 |   await expect(sub).toBeVisible();
  238 |   const subBox = await sub.boundingBox();
  239 |   expect(subBox.x).toBeGreaterThanOrEqual(0);
  240 |   expect(subBox.x + subBox.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  241 |   await page.keyboard.press('Escape');
  242 |   await tap(page, info, page.getByRole('menuitem', { name: 'Edit details', exact: true }));
  243 |   const dialog = page.getByRole('dialog', { name: 'Edit details', exact: true });
  244 |   await expect(dialog).toBeVisible();
  245 |   await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  246 |   await page.keyboard.press('Escape');
  247 |   await expect(actions).toBeFocused();
  248 |   await attach(info, 'pointer-menu', { input: info.project.use.hasTouch ? 'touch' : 'mouse', outside: true, menuBounds: box, submenuBounds: subBox, dialogReturn: true });
  249 | });
  250 | 
  251 | test('select supports arrows, Enter, clear, empty, disabled and empty-string account values', async ({ page }, info) => {
  252 |   const select = page.getByRole('combobox', { name: 'Expires', exact: true });
  253 |   await select.focus();
  254 |   await page.keyboard.press('ArrowDown');
  255 |   await page.keyboard.press('ArrowDown');
  256 |   await page.keyboard.press('Enter');
  257 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('7');
  258 |   await expect(select).toBeFocused();
  259 |   await select.click();
  260 |   await expect(page.getByRole('option', { name: '7 days', exact: true })).toHaveAttribute('aria-selected', 'true');
  261 |   await expect(page.getByRole('option', { name: '30 days', exact: true })).toHaveAttribute('aria-disabled', 'true');
  262 |   await page.keyboard.press('Escape');
  263 |   await page.getByRole('button', { name: 'Clear selection' }).first().click();
  264 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('null');
  265 |   await expect(select).toBeFocused();
  266 |   await expect(page.getByRole('combobox', { name: 'Disabled select', exact: true })).toBeDisabled();
  267 |   await expect(page.getByRole('combobox', { name: 'Disabled search', exact: true })).toBeDisabled();
  268 |   await page.getByRole('combobox', { name: 'Empty select', exact: true }).click();
  269 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  270 |   await page.keyboard.press('Escape');
  271 |   const automatic = page.getByRole('combobox', { name: 'Automatic account', exact: true });
  272 |   await expect(automatic).toContainText('Automatic');
  273 |   await automatic.click();
  274 |   await expect(page.getByRole('option', { name: /Automatic/ })).toHaveAttribute('aria-selected', 'true');
  275 |   await outside(page, info);
  276 |   await expect(automatic).toHaveAttribute('aria-expanded', 'false');
  277 |   await attach(info, 'select', { selected: '7', cleared: true, disabled: true, empty: true, emptyStringIsSelection: true });
  278 | });
  279 | 
  280 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  281 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  282 |   await expect(input).toHaveAccessibleDescription('Orbit workspace');
  283 |   await input.click();
  284 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  285 |   await input.fill('docs');
  286 |   await expect(page.getByRole('option')).toHaveCount(1);
  287 |   await page.keyboard.press('Enter');
  288 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  289 |   await expect(input).toBeFocused();
  290 |   await input.fill('missing');
  291 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  292 |   await page.keyboard.press('Escape');
  293 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  294 |   await input.click();
  295 |   await input.dispatchEvent('compositionstart');
  296 |   await input.dispatchEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 229, isComposing: true, bubbles: true });
  297 |   await input.dispatchEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 229, isComposing: true, bubbles: true });
  298 |   await expect(input).toHaveAttribute('aria-expanded', 'true');
  299 |   await expect(page.locator('output[aria-label="Workspace value"]')).toHaveText('docs');
  300 |   await input.dispatchEvent('compositionend', { data: '文档' });
  301 |   await input.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  302 |   await input.fill('文档');
  303 |   await expect(page.getByRole('option')).toHaveCount(1);
  304 |   await page.keyboard.press('Enter');
  305 |   await page.getByRole('button', { name: 'Clear selection' }).nth(1).click();
  306 |   await expect(page.getByRole('status', { name: 'Workspace value', exact: true })).toHaveText('null');
  307 |   await expect(input).toBeFocused();
  308 |   await attach(info, 'search', { grouping: true, chinese: true, syntheticCompositionIgnored: true, escapePreservesValue: true, explicitClear: true });
  309 | });
  310 | 
  311 | test('remote search accepts server labels and resets an action picker without local filtering', async ({ page }, info) => {
  312 |   let release;
  313 |   const gate = new Promise((resolve) => { release = resolve; });
  314 |   await page.route('**/__choices-search?*', async (route) => {
  315 |     await gate;
  316 |     await route.fulfill({ json: [{ value: 'task-1', label: 'Server ranked result' }] });
  317 |   });
  318 |   const input = page.getByRole('combobox', { name: 'Add prerequisite', exact: true });
  319 |   await input.fill('query');
  320 |   await expect(input).toHaveAttribute('aria-busy', 'true');
  321 |   release();
  322 |   const option = page.getByRole('option', { name: 'Server ranked result', exact: true });
  323 |   await expect(option).toBeVisible();
  324 |   await option.click();
  325 |   await expect(page.getByRole('status', { name: 'Prerequisite', exact: true })).toHaveText('task-1');
  326 |   await expect(input).toHaveValue('');
  327 |   await expect(input).toHaveAttribute('aria-expanded', 'false');
  328 |   await attach(info, 'remote-search', { loadingExposed: true, filterDisabled: true, valueNullResetsQuery: true });
  329 | });
  330 | 
  331 | for (const legacy of [false, true]) test(`${legacy ? 'legacy Modal' : 'Dialog'} owns choices, top-layer Escape, Tab and theme`, async ({ page }, info) => {
  332 |   const trigger = page.getByRole('button', { name: legacy ? 'Open legacy Modal' : 'Open Dialog', exact: true });
```