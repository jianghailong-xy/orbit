# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: choices.browser.mjs >> empty, disabled, hover and focus choice surfaces match the existing states
- Location: ui-migration/choices.browser.mjs:98:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

@@ -1,11 +1,11 @@
  Object {
    "control": Object {
      "rows": Array [],
      "surface": Object {
        "backgroundColor": "rgba(255, 255, 255, 0.08)",
-       "borderColor": "rgb(91, 91, 108)",
+       "borderColor": "rgb(66, 66, 70)",
        "borderRadius": "4px",
        "borderStyle": "solid",
        "borderWidth": "1px",
        "boxShadow": "none",
        "color": "rgba(255, 255, 255, 0.25)",
```

# Page snapshot

```yaml
- main [ref=f12e4]:
  - status [ref=f12e5]: dark
  - button "Switch theme" [ref=f12e6] [cursor=pointer]
  - region "Appearance sample" [ref=f12e8]:
    - generic [ref=f12e9]:
      - generic [ref=f12e10]:
        - generic: Never
        - combobox "Sample choice" [active] [ref=f12e11]
        - button "Show options" [ref=f12e12] [cursor=pointer]
        - button "Clear selection" [ref=f12e16] [cursor=pointer]
      - textbox [aria-hidden] [ref=f12e20]: never
```

# Test source

```ts
  35  |     const metrics = (node) => {
  36  |       const r = node.getBoundingClientRect(), s = getComputedStyle(node);
  37  |       const keys = ['fontFamily', 'fontSize', 'lineHeight', 'fontWeight', 'color', 'backgroundColor', 'borderRadius', 'borderColor', 'borderWidth', 'borderStyle', 'padding', 'boxShadow'];
  38  |       return { x: r.x - root.x, y: r.y - root.y, width: r.width, height: r.height, ...Object.fromEntries(keys.map((key) => [key, s[key]])) };
  39  |     };
  40  |     return { surface: metrics(el), rows: [...el.querySelectorAll('[role="menuitem"], [role="option"]')].map((row) => ({ label: row.textContent, ...metrics(row) })) };
  41  |   });
  42  | }
  43  | 
  44  | for (const kind of ['attachment', 'access', 'expiry', 'account', 'search', 'popover', 'tooltip']) {
  45  |   test(`${kind} matches the current surface, density and option states`, async ({ page }, info) => {
  46  |     const measurements = {};
  47  |     for (const system of ['antd', 'orbit']) {
  48  |       await page.goto(`${fixture}?sample=${kind}&system=${system}`);
  49  |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  50  |       const region = page.getByRole('region', { name: 'Appearance sample' });
  51  |       const choice = region.getByRole('combobox');
  52  |       if (['expiry', 'account', 'search'].includes(kind)) {
  53  |         await page.mouse.move(0, 0);
  54  |         await page.getByTestId('neutral').focus();
  55  |         await settle(page.locator('.sample-choice'));
  56  |         measurements[system] = { control: await measure(page.locator('.sample-choice')) };
  57  |         await shot(info, `${system}-${kind}-closed`, page.locator('.sample-choice'));
  58  |         await choice.click();
  59  |       } else if (kind === 'tooltip') await region.getByRole('button').hover();
  60  |       else await region.getByRole('button').click();
  61  |       const surface = page.locator('.sample-surface:visible');
  62  |       await settle(surface);
  63  |       if (kind !== 'tooltip') await page.mouse.move(0, 0);
  64  |       await settle(surface);
  65  |       measurements[system] = { ...measurements[system], popup: await measure(surface) };
  66  |       await shot(info, `${system}-${kind}-open`, surface);
  67  |       if (['popover', 'tooltip'].includes(kind)) {
  68  |         const arrow = page.locator(system === 'antd' ? '.sample-arrow:visible' : '.orbit-floating-arrow:visible');
  69  |         const box = await surface.boundingBox();
  70  |         const arrowBox = await arrow.boundingBox();
  71  |         measurements[system].callout = {
  72  |           arrow: { x: arrowBox.x - box.x, y: arrowBox.y - box.y, width: arrowBox.width, height: arrowBox.height },
  73  |           shape: await arrow.evaluate((el) => ({ fill: getComputedStyle(el, '::before').backgroundColor, clipPath: getComputedStyle(el, '::before').clipPath })),
  74  |           filter: await page.locator(system === 'antd' ? '.sample-floating-root:visible' : '.orbit-callout-positioner:visible').evaluate((el) => getComputedStyle(el).filter),
  75  |         };
  76  |         const x = Math.max(0, box.x - 40), y = Math.max(0, box.y - 40);
  77  |         await info.attach(`${system}-${kind}-context`, { body: await page.screenshot({ animations: 'disabled', clip: { x, y, width: Math.min(box.width + 80, info.project.use.viewport.width - x), height: box.height + 80 } }), contentType: 'image/png' });
  78  |       }
  79  |     }
  80  |     await attach(info, 'appearance', measurements);
  81  |     if (kind === 'attachment' && info.project.use.hasTouch) {
  82  |       // P0's original phone sample also measured 14px items: AntD's generated
  83  |       // selector overrides the existing 17px rule. The task explicitly requires
  84  |       // the confirmed 17px/42.4px/26px design. Retain both raw samples; assert the
  85  |       // requested differences exactly, and every other measured property unchanged.
  86  |       const expected = structuredClone(measurements.antd);
  87  |       expected.popup.surface.height = 40 + 5 * 42.390625;
  88  |       expected.popup.rows.forEach((row, i) => Object.assign(row, {
  89  |         fontSize: '17px', borderRadius: '0px', padding: '0px 0px 0px 31px',
  90  |         lineHeight: info.project.use.browserName === 'webkit' ? '26.714285px' : '26.7143px',
  91  |         y: 10 + i * 42.390625 + (i >= 2 ? 20 : 0),
  92  |       }));
  93  |       expect(measurements.orbit).toEqual(expected);
  94  |     } else expect(measurements.orbit).toEqual(measurements.antd);
  95  |   });
  96  | }
  97  | 
  98  | test('empty, disabled, hover and focus choice surfaces match the existing states', async ({ page }, info) => {
  99  |   const measurements = {};
  100 |   for (const kind of ['expiry', 'search']) for (const state of ['disabled', 'empty', 'default']) {
  101 |     const values = {};
  102 |     for (const system of ['antd', 'orbit']) {
  103 |       await page.goto(`${fixture}?sample=${kind}&system=${system}&state=${state}`);
  104 |       await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  105 |       const control = page.locator('.sample-choice');
  106 |       const input = page.getByRole('combobox', { name: 'Sample choice' });
  107 |       await page.mouse.move(0, 0);
  108 |       await page.getByTestId('neutral').focus();
  109 |       await settle(control);
  110 |       values[system] = { control: await measure(control) };
  111 |       if (state === 'disabled') {
  112 |         await expect(input).toBeDisabled();
  113 |         await shot(info, `${system}-${kind}-disabled`, control);
  114 |       } else if (state === 'empty') {
  115 |         await input.click();
  116 |         const surface = page.locator('.sample-surface:visible');
  117 |         await settle(surface);
  118 |         await expect(surface.getByText('No data', { exact: true }).and(surface.locator('div'))).toBeVisible();
  119 |         values[system].popup = await measure(surface);
  120 |         await shot(info, `${system}-${kind}-empty`, surface);
  121 |       } else {
  122 |         await control.hover();
  123 |         await settle(control);
  124 |         values[system].hover = await measure(control);
  125 |         await input.focus();
  126 |         await page.mouse.move(0, 0);
  127 |         await settle(control);
  128 |         values[system].focus = await measure(control);
  129 |         await shot(info, `${system}-${kind}-focus`, control);
  130 |       }
  131 |     }
  132 |     measurements[`${kind}-${state}`] = values;
  133 |   }
  134 |   await attach(info, 'choice-states', measurements);
> 135 |   for (const values of Object.values(measurements)) expect(values.orbit).toEqual(values.antd);
      |                                                                          ^ Error: expect(received).toEqual(expected) // deep equality
  136 | });
  137 | 
  138 | test('menu arrows, disabled items, submenu, checkbox and focus return work', async ({ page }, info) => {
  139 |   const trigger = page.getByRole('button', { name: 'Session actions', exact: true });
  140 |   await trigger.focus();
  141 |   await page.keyboard.press('ArrowDown');
  142 |   const first = page.getByRole('menuitem', { name: 'Default model', exact: true });
  143 |   await expect(first).toBeFocused();
  144 |   await page.keyboard.press('ArrowDown');
  145 |   const provider = page.getByRole('menuitem', { name: 'Provider', exact: true });
  146 |   await expect(provider).toBeFocused();
  147 |   await page.keyboard.press('ArrowRight');
  148 |   await expect(page.getByRole('menuitem', { name: 'Codex', exact: true })).toBeFocused();
  149 |   await page.keyboard.press('Escape');
  150 |   await expect(provider).toBeFocused();
  151 |   await expect(page.getByRole('menu')).toHaveCount(1);
  152 |   await page.keyboard.press('ArrowRight');
  153 |   await page.keyboard.press('ArrowDown');
  154 |   await page.keyboard.press('Enter');
  155 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('claude');
  156 |   await expect(trigger).toBeFocused();
  157 |   await trigger.click();
  158 |   const tag = page.getByRole('menuitemcheckbox', { name: 'Important tag' });
  159 |   await tag.click();
  160 |   await expect(tag).toHaveAttribute('aria-checked', 'true');
  161 |   await expect(page.getByRole('status', { name: 'Tag', exact: true })).toHaveText('true');
  162 |   await tag.press('Space');
  163 |   await expect(tag).toHaveAttribute('aria-checked', 'false');
  164 |   await page.keyboard.press('Escape');
  165 |   await expect(trigger).toBeFocused();
  166 |   await attach(info, 'keyboard-menu', { disabledSkipped: true, submenuOnlyEscape: true, selection: 'claude', checkboxStaysOpen: true, focusReturned: true });
  167 | });
  168 | 
  169 | test('touch or pointer menus dismiss outside, fit viewport and open a dialog with stable return focus', async ({ page }, info) => {
  170 |   const trigger = page.getByRole('button', { name: 'Add attachment', exact: true });
  171 |   await tap(page, info, trigger);
  172 |   const menu = page.getByRole('menu');
  173 |   const box = await menu.boundingBox();
  174 |   expect(box.x).toBeGreaterThanOrEqual(0);
  175 |   expect(box.x + box.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  176 |   await tap(page, info, page.getByRole('menuitem', { name: 'Image', exact: true }));
  177 |   await expect(menu).not.toBeVisible();
  178 |   await expect(page.getByRole('status', { name: 'Action', exact: true })).toHaveText('image');
  179 |   await tap(page, info, trigger);
  180 |   await outside(page, info);
  181 |   await expect(menu).not.toBeVisible();
  182 |   const actions = page.getByRole('button', { name: 'Session actions', exact: true });
  183 |   await tap(page, info, actions);
  184 |   await tap(page, info, page.getByRole('menuitem', { name: 'Provider', exact: true }));
  185 |   const sub = page.getByRole('menu').filter({ has: page.getByRole('menuitem', { name: 'Codex', exact: true }) });
  186 |   await expect(sub).toBeVisible();
  187 |   const subBox = await sub.boundingBox();
  188 |   expect(subBox.x).toBeGreaterThanOrEqual(0);
  189 |   expect(subBox.x + subBox.width).toBeLessThanOrEqual(info.project.use.viewport.width);
  190 |   await page.keyboard.press('Escape');
  191 |   await tap(page, info, page.getByRole('menuitem', { name: 'Edit details', exact: true }));
  192 |   const dialog = page.getByRole('dialog', { name: 'Edit details', exact: true });
  193 |   await expect(dialog).toBeVisible();
  194 |   await expect.poll(() => dialog.evaluate((el) => el.contains(document.activeElement))).toBe(true);
  195 |   await page.keyboard.press('Escape');
  196 |   await expect(actions).toBeFocused();
  197 |   await attach(info, 'pointer-menu', { input: info.project.use.hasTouch ? 'touch' : 'mouse', outside: true, menuBounds: box, submenuBounds: subBox, dialogReturn: true });
  198 | });
  199 | 
  200 | test('select supports arrows, Enter, clear, empty, disabled and empty-string account values', async ({ page }, info) => {
  201 |   const select = page.getByRole('combobox', { name: 'Expires', exact: true });
  202 |   await select.focus();
  203 |   await page.keyboard.press('ArrowDown');
  204 |   await page.keyboard.press('ArrowDown');
  205 |   await page.keyboard.press('Enter');
  206 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('7');
  207 |   await expect(select).toBeFocused();
  208 |   await select.click();
  209 |   await expect(page.getByRole('option', { name: '7 days', exact: true })).toHaveAttribute('aria-selected', 'true');
  210 |   await expect(page.getByRole('option', { name: '30 days', exact: true })).toHaveAttribute('aria-disabled', 'true');
  211 |   await page.keyboard.press('Escape');
  212 |   await page.getByRole('button', { name: 'Clear selection' }).first().click();
  213 |   await expect(page.getByRole('status', { name: 'Expiry value', exact: true })).toHaveText('null');
  214 |   await expect(select).toBeFocused();
  215 |   await expect(page.getByRole('combobox', { name: 'Disabled select', exact: true })).toBeDisabled();
  216 |   await expect(page.getByRole('combobox', { name: 'Disabled search', exact: true })).toBeDisabled();
  217 |   await page.getByRole('combobox', { name: 'Empty select', exact: true }).click();
  218 |   await expect(page.getByText('No data', { exact: true })).toBeVisible();
  219 |   await page.keyboard.press('Escape');
  220 |   const automatic = page.getByRole('combobox', { name: 'Automatic account', exact: true });
  221 |   await expect(automatic).toContainText('Automatic');
  222 |   await automatic.click();
  223 |   await expect(page.getByRole('option', { name: /Automatic/ })).toHaveAttribute('aria-selected', 'true');
  224 |   await outside(page, info);
  225 |   await expect(automatic).toHaveAttribute('aria-expanded', 'false');
  226 |   await attach(info, 'select', { selected: '7', cleared: true, disabled: true, empty: true, emptyStringIsSelection: true });
  227 | });
  228 | 
  229 | test('search preserves selection, filters groups, handles no results, composition and explicit clear', async ({ page }, info) => {
  230 |   const input = page.getByRole('combobox', { name: 'Workspace', exact: true });
  231 |   await expect(input).toHaveAccessibleDescription('Orbit workspace');
  232 |   await input.click();
  233 |   await expect(page.getByRole('group', { name: 'Local', exact: true })).toBeVisible();
  234 |   await input.fill('docs');
  235 |   await expect(page.getByRole('option')).toHaveCount(1);
```