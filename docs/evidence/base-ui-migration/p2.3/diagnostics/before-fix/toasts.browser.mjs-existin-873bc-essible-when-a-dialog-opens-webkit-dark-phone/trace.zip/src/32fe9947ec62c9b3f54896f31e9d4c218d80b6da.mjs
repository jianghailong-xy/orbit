import { test, expect } from '@playwright/test';

test.beforeEach(async ({ page }, info) => {
  await page.goto('/ui-migration/toasts.html');
  await expect(page.getByTestId('theme')).toHaveText(info.project.use.colorScheme);
  await page.evaluate(() => document.fonts.ready);
});

test('existing notifications remain accessible when a dialog opens', async ({ page }, info) => {
  await page.getByRole('button', { name: 'Error notice', exact: true }).click();
  await page.getByRole('button', { name: 'Open Dialog', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: 'Workspace editor', exact: true });
  await expect(dialog).toBeVisible();
  await info.attach('notification-with-dialog', { body: await page.screenshot(), contentType: 'image/png' });
  await expect(page.getByRole('region', { name: 'Notifications', exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Dismiss', exact: true }).click();
  await expect(dialog).toBeVisible();
});
